import {
  pgTable,
  text,
  serial,
  integer,
  timestamp,
  boolean,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// Embed configuration shape (used by welcome, custom commands, ticket panels)
export type EmbedConfig = {
  title?: string | null;
  description?: string | null;
  color?: number | null;
  imageUrl?: string | null;
  thumbnailUrl?: string | null;
  bannerUrl?: string | null;
  footerText?: string | null;
  footerIconUrl?: string | null;
  authorName?: string | null;
  authorIconUrl?: string | null;
  timestamp?: boolean | null;
};

// Per-guild settings
export const guildSettings = pgTable("guild_settings", {
  guildId: text("guild_id").primaryKey(),
  prefixes: jsonb("prefixes").$type<string[]>().notNull().default(["-", "+", "?", "!", ",", "$"]),
  modLogChannelId: text("mod_log_channel_id"),
  // welcome
  welcomeEnabled: boolean("welcome_enabled").notNull().default(false),
  welcomeChannelId: text("welcome_channel_id"),
  welcomeEmbed: jsonb("welcome_embed").$type<EmbedConfig | null>(),
  welcomeAutoRoleIds: jsonb("welcome_auto_role_ids").$type<string[]>().notNull().default([]),
  welcomeMessageContent: text("welcome_message_content"),
  // leveling
  levelingEnabled: boolean("leveling_enabled").notNull().default(false),
  levelUpChannelId: text("level_up_channel_id"),
  // suggestions
  suggestionsChannelId: text("suggestions_channel_id"),
  // updated
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// Per-user warnings
export const warnings = pgTable(
  "warnings",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    moderatorId: text("moderator_id").notNull(),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    guildUserIdx: index("warnings_guild_user_idx").on(t.guildId, t.userId),
  }),
);

// Ticket panels
export const ticketPanels = pgTable("ticket_panels", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  name: text("name").notNull(),
  channelId: text("channel_id"),
  messageId: text("message_id"),
  embed: jsonb("embed").$type<EmbedConfig>().notNull(),
  layout: text("layout").notNull().default("buttons"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type TicketFormQuestion = {
  id: string;
  label: string;
  style: "short" | "paragraph";
  required: boolean;
  placeholder?: string;
  maxLength?: number;
};

export type TicketButtonStyle = "primary" | "secondary" | "success" | "danger";

export const ticketPanelOptions = pgTable("ticket_panel_options", {
  id: serial("id").primaryKey(),
  panelId: integer("panel_id")
    .notNull()
    .references(() => ticketPanels.id, { onDelete: "cascade" }),
  position: integer("position").notNull().default(0),
  label: text("label").notNull(),
  emoji: text("emoji"),
  style: text("style").$type<TicketButtonStyle>().notNull().default("primary"),
  description: text("description"),
  categoryId: text("category_id").notNull(),
  staffRoleIds: jsonb("staff_role_ids").$type<string[]>().notNull().default([]),
  ticketEmbed: jsonb("ticket_embed").$type<EmbedConfig>().notNull(),
  openingMessage: text("opening_message"),
  formQuestions: jsonb("form_questions").$type<TicketFormQuestion[]>().notNull().default([]),
  closeButtonLabel: text("close_button_label").notNull().default("Close"),
  closeButtonEmoji: text("close_button_emoji").default("🔒"),
  closeButtonStyle: text("close_button_style").$type<TicketButtonStyle>().notNull().default("danger"),
  claimButtonLabel: text("claim_button_label").notNull().default("Claim"),
  claimButtonEmoji: text("claim_button_emoji").default("🙋"),
  claimButtonStyle: text("claim_button_style").$type<TicketButtonStyle>().notNull().default("success"),
});

export type TicketFormAnswer = { question: string; answer: string };

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  panelId: integer("panel_id").references(() => ticketPanels.id, { onDelete: "set null" }),
  optionId: integer("option_id").references(() => ticketPanelOptions.id, { onDelete: "set null" }),
  channelId: text("channel_id").notNull().unique(),
  openerId: text("opener_id").notNull(),
  ticketNumber: integer("ticket_number").notNull(),
  status: text("status").notNull().default("open"),
  claimedBy: text("claimed_by"),
  closedBy: text("closed_by"),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  formAnswers: jsonb("form_answers").$type<TicketFormAnswer[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const ticketCounters = pgTable("ticket_counters", {
  guildId: text("guild_id").primaryKey(),
  lastNumber: integer("last_number").notNull().default(0),
});

// Custom commands
export type CustomButton = {
  id: string;
  label: string;
  emoji?: string;
  style: TicketButtonStyle | "link";
  url?: string;
  responseContent?: string;
  responseEmbed?: EmbedConfig;
  ephemeral?: boolean;
};

export type CustomCommandAction =
  | { type: "message"; content: string }
  | { type: "embed"; embed: EmbedConfig }
  | { type: "url"; url: string }
  | { type: "buttons"; content?: string; embed?: EmbedConfig | null; buttons: CustomButton[] };

export const customCommands = pgTable(
  "custom_commands",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    name: text("name").notNull(),
    action: jsonb("action").$type<CustomCommandAction>().notNull(),
    createdBy: text("created_by").notNull(),
    usageCount: integer("usage_count").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    guildNameIdx: uniqueIndex("custom_commands_guild_name_idx").on(t.guildId, t.name),
  }),
);

// Leveling
export const levelXp = pgTable(
  "level_xp",
  {
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    xp: integer("xp").notNull().default(0),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
  },
  (t) => ({
    guildUserIdx: uniqueIndex("level_xp_guild_user_idx").on(t.guildId, t.userId),
  }),
);

export const levelRoles = pgTable(
  "level_roles",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    level: integer("level").notNull(),
    roleId: text("role_id").notNull(),
  },
  (t) => ({
    guildLevelIdx: uniqueIndex("level_roles_guild_level_idx").on(t.guildId, t.level),
  }),
);

// Giveaways
export const giveaways = pgTable("giveaways", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  channelId: text("channel_id").notNull(),
  messageId: text("message_id").notNull().unique(),
  prize: text("prize").notNull(),
  description: text("description"),
  hostId: text("host_id").notNull(),
  winnersCount: integer("winners_count").notNull().default(1),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  ended: boolean("ended").notNull().default(false),
  entrants: jsonb("entrants").$type<string[]>().notNull().default([]),
  winners: jsonb("winners").$type<string[]>().notNull().default([]),
});

// Reaction roles (one row per emoji+message combination)
export const reactionRoles = pgTable(
  "reaction_roles",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    channelId: text("channel_id").notNull(),
    messageId: text("message_id").notNull(),
    emoji: text("emoji").notNull(),
    roleId: text("role_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    msgEmojiIdx: uniqueIndex("reaction_roles_msg_emoji_idx").on(t.messageId, t.emoji),
  }),
);

// ─────────────────────────────────────────────────────────────────────────────
// Auto Middleman
// ─────────────────────────────────────────────────────────────────────────────

export type AutoMmButtonStyle = "primary" | "secondary" | "success" | "danger" | "link";

export type AutoMmButton = {
  id: string;
  label: string;
  emoji?: string;
  style: AutoMmButtonStyle;
  url?: string;
  responseContent?: string;
  responseEmbed?: EmbedConfig;
  ephemeral?: boolean;
};

/** Per-guild Auto Middleman configuration: branded embed template + buttons + supported methods. */
export const autommConfig = pgTable("automm_config", {
  guildId: text("guild_id").primaryKey(),
  embed: jsonb("embed").$type<EmbedConfig | null>(),
  contentTemplate: text("content_template"),
  buttons: jsonb("buttons").$type<AutoMmButton[]>().notNull().default([]),
  enabledMethods: jsonb("enabled_methods").$type<string[]>().notNull().default(["BTC", "LTC", "ETH", "USDT"]),
  monitorEnabled: boolean("monitor_enabled").notNull().default(true),
  expireMinutes: integer("expire_minutes").notNull().default(60),
  amountTolerancePct: integer("amount_tolerance_pct").notNull().default(2),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Wallet addresses per payment method per guild. */
export const autommAddresses = pgTable(
  "automm_addresses",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    method: text("method").notNull(),
    address: text("address").notNull(),
    network: text("network"),
    label: text("label"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    guildMethodIdx: uniqueIndex("automm_addresses_guild_method_idx").on(t.guildId, t.method),
  }),
);

export type AutoMmStatus = "pending" | "received" | "confirmed" | "cancelled" | "expired";

/**
 * A single in-flight middleman deposit session.
 * The bot only DETECTS deposits to the address — it never moves funds.
 */
export const autommDeposits = pgTable(
  "automm_deposits",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    ticketChannelId: text("ticket_channel_id").notNull(),
    embedMessageId: text("embed_message_id"),
    buyerId: text("buyer_id").notNull(),
    method: text("method").notNull(),
    address: text("address").notNull(),
    network: text("network"),
    expectedAmount: text("expected_amount").notNull(),
    receivedAmount: text("received_amount"),
    txHash: text("tx_hash"),
    status: text("status").$type<AutoMmStatus>().notNull().default("pending"),
    autoMonitor: boolean("auto_monitor").notNull().default(true),
    initialBalance: text("initial_balance"),
    confirmedByUserId: text("confirmed_by_user_id"),
    cancelledByUserId: text("cancelled_by_user_id"),
    lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    statusIdx: index("automm_deposits_status_idx").on(t.status),
    guildStatusIdx: index("automm_deposits_guild_status_idx").on(t.guildId, t.status),
    ticketIdx: index("automm_deposits_ticket_idx").on(t.ticketChannelId),
  }),
);

// Suggestions
export const suggestions = pgTable("suggestions", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  messageId: text("message_id").notNull().unique(),
  channelId: text("channel_id").notNull(),
  authorId: text("author_id").notNull(),
  content: text("content").notNull(),
  upvotes: jsonb("upvotes").$type<string[]>().notNull().default([]),
  downvotes: jsonb("downvotes").$type<string[]>().notNull().default([]),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
