# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/discord-bot run dev` — build + run the Discord bot
- `pnpm --filter @workspace/discord-bot run deploy-commands` — register slash commands with Discord (set `DISCORD_GUILD_ID` for fast guild-scoped registration; otherwise registers globally)

## Discord Bot (Eldorado.gg)

Located at `bots/discord-bot/`. Premium gaming-marketplace community bot — no web dashboard, fully configured via Discord slash/prefix commands. Features: moderation w/ mod log, `/panel` ticket system, `/custom` and `/embed` builders, welcome system, utility, fun, leveling w/ role rewards, giveaways, reaction roles, suggestions. Branded embeds editable via DB.

### Required Discord Setup (manual, one-time)
The bot needs two **privileged gateway intents** enabled in the Discord Developer Portal (Bot tab → Privileged Gateway Intents):
- **Server Members Intent** — welcome system, member events
- **Message Content Intent** — multi-prefix commands (`-`, `+`, `?`, `!`, `,`, `$`). Built-in prefix shortcuts: `help`, `ping`, `say`, `ban`, `kick`, `mute`, `unmute`, `warn`, `clear`, plus ticket-channel shortcuts `add @user` / `claim` / `close`. Any custom command from `/custom create` works with every prefix above.
- **Auto Middleman panel** — `/automm panel send #channel` posts a public panel with one button per enabled payment method; clicking a method asks for the deposit amount and posts the secure deposit address in that channel. Use `/automm panel editor` to edit the embed (same as `/automm embed`) and `/automm panel show` for an ephemeral preview.

Without these the bot fails to log in with `Used disallowed intents`.

### Environment Variables
- `DISCORD_TOKEN` — bot token
- `DISCORD_CLIENT_ID` — application id (for slash command deploy)
- `DISCORD_GUILD_ID` — optional, scope slash commands to one guild for instant updates during development
- `ETHERSCAN_API_KEY` — optional; enables ETH and USDT-ERC20 deposit detection in the Auto Middleman system. Without it, only BTC and LTC are monitored on-chain (others remain manual-confirm).

### Auto Middleman (read-only deposit watcher)
A safety-first deposit-detection layer for in-ticket trades. **The bot never moves, holds, or sends funds.** It only reads public on-chain balances and posts updates; humans (admins) confirm/release goods.

- **Configuration**: `/automm embed` opens a builder identical to `/embed` (basics, visuals, footer, content, save) — defines the branded embed shown when a deposit session starts.
- **Wallet addresses** (one per method, per guild): `/set address method:<BTC|LTC|ETH|USDT|ROBUX|OTHER> address:<value>`. BTC/LTC/ETH/USDT addresses are watched on-chain; ROBUX/OTHER are display-only and confirmed manually.
- **Methods toggle**: `/automm methods` — pick which payment methods are offered to buyers.
- **Start a session** (admins, inside a ticket): `/give automm amount:<USD>` — posts the configured embed with a method picker. Buyer selects method, the bot posts the wallet address + a session embed with `Confirm`, `Cancel`, and `Re-check now` buttons.
- **Detection**: monitor polls every 30s (BTC via blockstream.info, LTC via blockchair, ETH+USDT-ERC20 via etherscan). When the address balance increases by ≥ the requested amount within the session window, the bot edits the embed to `received` and pings the ticket.
- **Status / preview**: `/automm status` shows monitor health and active sessions; `/automm preview` renders the current embed config; `/automm config` shows raw saved config.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
