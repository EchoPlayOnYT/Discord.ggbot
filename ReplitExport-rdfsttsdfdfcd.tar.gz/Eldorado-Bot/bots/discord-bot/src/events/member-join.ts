import { type Client, type GuildMember, type TextChannel } from "discord.js";
import { renderEmbedConfig, applyPlaceholders } from "../embed.js";
import { getGuildSettings } from "../utils/db-helpers.js";
import { logger } from "../logger.js";

export function registerMemberJoinEvent(client: Client): void {
  client.on("guildMemberAdd", async (member: GuildMember) => {
    try {
      const settings = await getGuildSettings(member.guild.id);
      // Auto-roles
      if (settings.welcomeAutoRoleIds.length) {
        try {
          await member.roles.add(settings.welcomeAutoRoleIds, "Welcome auto-role");
        } catch (err) {
          logger.warn({ err }, "auto-role failed");
        }
      }
      if (!settings.welcomeEnabled || !settings.welcomeChannelId) return;
      const ch = member.guild.channels.cache.get(settings.welcomeChannelId) as TextChannel | undefined;
      if (!ch?.isTextBased()) return;
      const cfg = settings.welcomeEmbed ?? {};
      const ctx = {
        user: member.user,
        userMention: member.toString(),
        userTag: member.user.tag,
        serverName: member.guild.name,
        memberCount: member.guild.memberCount,
      };
      const embed = renderEmbedConfig(cfg);
      if (cfg.title) embed.setTitle(applyPlaceholders(cfg.title, ctx));
      if (cfg.description) embed.setDescription(applyPlaceholders(cfg.description, ctx));
      const content = settings.welcomeMessageContent ? applyPlaceholders(settings.welcomeMessageContent, ctx) : undefined;
      await ch.send({ content, embeds: [embed] });
    } catch (err) {
      logger.error({ err }, "guildMemberAdd error");
    }
  });
}
