import { ActivityType, type Client } from "discord.js";
import { logger } from "../logger.js";
import { startGiveawayLoop } from "../handlers/giveaway-handler.js";
import { BRAND } from "../config.js";

export function registerReadyEvent(client: Client): void {
  client.once("ready", () => {
    if (!client.user) return;
    logger.info({ tag: client.user.tag, id: client.user.id, guilds: client.guilds.cache.size }, "Bot ready");
    client.user.setPresence({
      activities: [{ name: `${BRAND.name} • /panel`, type: ActivityType.Watching }],
      status: "online",
    });
    startGiveawayLoop(client);
  });
}
