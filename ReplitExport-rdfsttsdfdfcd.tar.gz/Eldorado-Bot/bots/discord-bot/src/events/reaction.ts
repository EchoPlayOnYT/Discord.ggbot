import { type Client, type MessageReaction, type PartialMessageReaction, type User, type PartialUser } from "discord.js";
import { db, reactionRoles } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { logger } from "../logger.js";

function emojiKey(reaction: MessageReaction | PartialMessageReaction): string {
  return reaction.emoji.id ?? reaction.emoji.name ?? "";
}

async function findRR(messageId: string, key: string) {
  const [r] = await db
    .select()
    .from(reactionRoles)
    .where(and(eq(reactionRoles.messageId, messageId), eq(reactionRoles.emoji, key)))
    .limit(1);
  return r;
}

export function registerReactionEvent(client: Client): void {
  client.on("messageReactionAdd", async (reaction, user) => {
    if (user.bot) return;
    try {
      if (reaction.partial) await reaction.fetch();
      if (!reaction.message.guild) return;
      const r = await findRR(reaction.message.id, emojiKey(reaction));
      if (!r) return;
      const member = await reaction.message.guild.members.fetch(user.id);
      if (!member.roles.cache.has(r.roleId)) await member.roles.add(r.roleId, "Reaction role");
    } catch (err) {
      logger.warn({ err }, "reaction add error");
    }
  });

  client.on("messageReactionRemove", async (reaction, user) => {
    if (user.bot) return;
    try {
      if (reaction.partial) await reaction.fetch();
      if (!reaction.message.guild) return;
      const r = await findRR(reaction.message.id, emojiKey(reaction));
      if (!r) return;
      const member = await reaction.message.guild.members.fetch(user.id);
      if (member.roles.cache.has(r.roleId)) await member.roles.remove(r.roleId, "Reaction role removed");
    } catch (err) {
      logger.warn({ err }, "reaction remove error");
    }
  });
}
