import { type Client, type Interaction, InteractionType } from "discord.js";
import { logger } from "../logger.js";
import { errorEmbed } from "../embed.js";
import type { BotClient } from "../client.js";
import { decodeId } from "../utils/component-ids.js";
import { handleEmbedButton, handleEmbedModal } from "../handlers/embed-builder.js";
import { handleWelcomeButton, handleWelcomeChannelSelect, handleWelcomeModal } from "../handlers/welcome-builder.js";
import { handleCustomButton, handleCustomModal, handleCustomSelect, handleCustomButtonClick } from "../handlers/custom-builder.js";
import { handlePanelInteraction, handlePanelModal } from "../handlers/panel-builder.js";
import { handleTicketInteraction, handleTicketModal } from "../handlers/ticket-actions.js";
import { handleGiveawayButton } from "../handlers/giveaway-handler.js";
import { handleSuggestionButton } from "../handlers/suggestion-handler.js";
import { handleAutommBuilderButton, handleAutommBuilderModal } from "../handlers/automm-builder.js";
import { routeAutommDepositInteraction } from "../handlers/automm-deposit.js";

const AUTOMM_BUILDER_ACTIONS = new Set([
  "edit_basics",
  "edit_visuals",
  "edit_footer",
  "edit_content",
  "save",
  "cancel",
  "modal_basics",
  "modal_visuals",
  "modal_footer",
  "modal_content",
]);

export function registerInteractionEvent(client: Client): void {
  client.on("interactionCreate", async (interaction: Interaction) => {
    const bot = client as BotClient;
    try {
      // Slash commands
      if (interaction.isChatInputCommand()) {
        const cmd = bot.slash.get(interaction.commandName);
        if (!cmd) return;
        await cmd.execute(interaction);
        return;
      }

      // Buttons / select menus / modals — route by namespace
      if (interaction.isButton() || interaction.isAnySelectMenu() || interaction.type === InteractionType.ModalSubmit) {
        const id = interaction.customId;
        const { namespace } = decodeId(id);

        if (namespace === "embed") {
          if (interaction.isButton()) await handleEmbedButton(interaction);
          else if (interaction.isModalSubmit()) await handleEmbedModal(interaction);
          return;
        }
        if (namespace === "welcome") {
          if (interaction.isButton()) await handleWelcomeButton(interaction);
          else if (interaction.isChannelSelectMenu()) await handleWelcomeChannelSelect(interaction);
          else if (interaction.isModalSubmit()) await handleWelcomeModal(interaction);
          return;
        }
        if (namespace === "custom") {
          if (interaction.isButton()) await handleCustomButton(interaction);
          else if (interaction.isStringSelectMenu()) await handleCustomSelect(interaction);
          else if (interaction.isModalSubmit()) await handleCustomModal(interaction);
          return;
        }
        if (namespace === "ccbtn") {
          if (interaction.isButton()) {
            const { args } = decodeId(interaction.customId);
            await handleCustomButtonClick(interaction, args[0]!);
          }
          return;
        }
        if (namespace === "panel" || namespace === "opt") {
          if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isChannelSelectMenu() || interaction.isRoleSelectMenu())
            await handlePanelInteraction(interaction);
          else if (interaction.isModalSubmit()) await handlePanelModal(interaction);
          return;
        }
        if (namespace === "ticket") {
          if (interaction.isButton() || interaction.isStringSelectMenu()) await handleTicketInteraction(interaction);
          else if (interaction.isModalSubmit()) await handleTicketModal(interaction);
          return;
        }
        if (namespace === "giveaway") {
          if (interaction.isButton()) await handleGiveawayButton(interaction);
          return;
        }
        if (namespace === "sugg") {
          if (interaction.isButton()) await handleSuggestionButton(interaction);
          return;
        }
        if (namespace === "automm") {
          const { action } = decodeId(interaction.customId);
          if (AUTOMM_BUILDER_ACTIONS.has(action)) {
            if (interaction.isButton()) await handleAutommBuilderButton(interaction);
            else if (interaction.isModalSubmit()) await handleAutommBuilderModal(interaction);
          } else if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isModalSubmit()) {
            await routeAutommDepositInteraction(interaction);
          }
          return;
        }
      }
    } catch (err) {
      logger.error({ err, customId: "customId" in interaction ? interaction.customId : undefined }, "interaction error");
      try {
        if (interaction.isRepliable()) {
          const payload = { embeds: [errorEmbed("Something went wrong", err instanceof Error ? err.message : "Unknown error")], ephemeral: true } as const;
          if (interaction.replied || interaction.deferred) await interaction.followUp(payload);
          else await interaction.reply(payload);
        }
      } catch {
        // swallow
      }
    }
  });
}
