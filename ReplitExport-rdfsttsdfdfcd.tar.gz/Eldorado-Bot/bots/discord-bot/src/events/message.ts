import { type Client, type Message } from "discord.js";
import { handlePrefixMessage } from "../handlers/prefix-handler.js";
import { handleMessageXp } from "../handlers/level-handler.js";
import { logger } from "../logger.js";

export function registerMessageEvent(client: Client): void {
  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot || !message.inGuild()) return;
    try {
      await handleMessageXp(message);
    } catch (err) {
      logger.warn({ err }, "level xp error");
    }
    try {
      await handlePrefixMessage(message);
    } catch (err) {
      logger.warn({ err }, "prefix handler error");
    }
  });
}
