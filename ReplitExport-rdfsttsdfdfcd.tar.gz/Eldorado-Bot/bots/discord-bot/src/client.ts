import {
  Client,
  Collection,
  GatewayIntentBits,
  Partials,
  type ChatInputCommandInteraction,
  type SlashCommandBuilder,
  type SlashCommandSubcommandsOnlyBuilder,
  type SlashCommandOptionsOnlyBuilder,
  type Message,
} from "discord.js";

export type SlashCommandData =
  | SlashCommandBuilder
  | SlashCommandSubcommandsOnlyBuilder
  | SlashCommandOptionsOnlyBuilder
  | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">;

export type SlashCommand = {
  data: SlashCommandData;
  execute: (interaction: ChatInputCommandInteraction) => Promise<unknown>;
};

export type PrefixCommand = {
  name: string;
  aliases?: string[];
  execute: (message: Message<true>, args: string[]) => Promise<unknown>;
};

export interface BotClient extends Client {
  slash: Collection<string, SlashCommand>;
  prefixCommands: Collection<string, PrefixCommand>;
}

export function createClient(): BotClient {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildModeration,
      GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User],
  }) as BotClient;
  client.slash = new Collection();
  client.prefixCommands = new Collection();
  return client;
}
