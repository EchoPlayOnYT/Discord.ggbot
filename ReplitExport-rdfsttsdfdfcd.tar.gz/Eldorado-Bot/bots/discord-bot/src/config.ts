// Eldorado.gg branded color palette and emoji set used across every embed.
export const BRAND = {
  name: "Eldorado.gg",
  url: "https://eldorado.gg",
  // Eldorado primary purple
  primary: 0x7c3aed,
  // Status colors
  success: 0x22c55e,
  danger: 0xef4444,
  warning: 0xf59e0b,
  info: 0x6366f1,
  neutral: 0x2b2d31,
  // Default banner shown on every embed (can be overridden per-feature)
  defaultBanner: "https://eldorado.gg/_next/image?url=%2Fimages%2Fhomepage%2Fhero-bg.webp&w=1920&q=75",
  // Footer appears on every embed
  footerText: "Eldorado.gg • Premium Marketplace",
  footerIcon: "https://eldorado.gg/favicon.ico",
};

// Default prefixes (per-guild override stored in DB)
export const DEFAULT_PREFIXES = ["-", "+", "?", "!", ",", "$"];

// Curated emoji palette used throughout the bot for a unified look.
export const EMOJI = {
  // status
  success: "✅",
  error: "❌",
  warn: "⚠️",
  info: "ℹ️",
  loading: "⏳",
  // actions
  ban: "🔨",
  kick: "👢",
  mute: "🔇",
  unmute: "🔊",
  warning: "⚠️",
  clear: "🧹",
  unban: "🕊️",
  // tickets
  ticket: "🎫",
  open: "📩",
  close: "🔒",
  claim: "🙋",
  delete: "🗑️",
  add: "➕",
  // utility
  user: "👤",
  server: "🏠",
  bot: "🤖",
  ping: "📡",
  poll: "📊",
  question: "❓",
  // fun
  coin: "🪙",
  dice: "🎲",
  joke: "😂",
  rps: "✊",
  // engagement
  level: "🌟",
  xp: "✨",
  trophy: "🏆",
  giveaway: "🎉",
  star: "⭐",
  reaction: "🎭",
  suggestion: "💡",
  lightbulb: "💡",
  gift: "🎁",
  broom: "🧹",
  upvote: "👍",
  downvote: "👎",
  // navigation
  arrow: "➡️",
  back: "↩️",
  next: "▶️",
  previous: "◀️",
  edit: "✏️",
  save: "💾",
  preview: "👁️",
  cancel: "✖️",
  // brand
  diamond: "💎",
  crown: "👑",
  fire: "🔥",
  sparkle: "✨",
};
