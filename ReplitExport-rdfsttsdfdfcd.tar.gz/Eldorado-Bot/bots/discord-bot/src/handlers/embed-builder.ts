import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type EmbedBuilder,
  type Message,
  type TextChannel,
} from "discord.js";
import type { EmbedConfig } from "@workspace/db";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";

// In-memory editor state (ephemeral; cleared after send/cancel).
const drafts = new Map<string, EmbedConfig>();

export function setEmbedDraft(userId: string, cfg: EmbedConfig): void {
  drafts.set(userId, cfg);
}

export function getEmbedDraft(userId: string): EmbedConfig | undefined {
  return drafts.get(userId);
}

export function clearEmbedDraft(userId: string): void {
  drafts.delete(userId);
}

function parseColor(input: string | null): number | undefined {
  if (!input) return undefined;
  const trimmed = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(trimmed)) return undefined;
  return parseInt(trimmed, 16);
}

function buildPreviewComponents(targetId: string): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("embed", "edit_basics"))
        .setLabel("Edit Title & Description")
        .setEmoji(EMOJI.edit)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(encodeId("embed", "edit_visuals"))
        .setLabel("Edit Visuals")
        .setEmoji(EMOJI.preview)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(encodeId("embed", "edit_footer"))
        .setLabel("Edit Footer & Author")
        .setEmoji(EMOJI.edit)
        .setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("embed", "send", targetId))
        .setLabel("Send")
        .setEmoji(EMOJI.success)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(encodeId("embed", "cancel"))
        .setLabel("Cancel")
        .setEmoji(EMOJI.cancel)
        .setStyle(ButtonStyle.Danger),
    ),
  ];
}

export async function handleEmbedButton(interaction: ButtonInteraction): Promise<void> {
  const { action, args } = decodeId(interaction.customId);

  if (action === "edit_basics") {
    const draft = drafts.get(interaction.user.id) ?? {};
    const modal = new ModalBuilder()
      .setCustomId(encodeId("embed", "modal_basics"))
      .setTitle("Edit Title & Description")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("title")
            .setLabel("Title")
            .setStyle(TextInputStyle.Short)
            .setMaxLength(256)
            .setRequired(false)
            .setValue(draft.title ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("Description")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(4000)
            .setRequired(false)
            .setValue(draft.description ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("color")
            .setLabel("Color (hex like #7c3aed)")
            .setStyle(TextInputStyle.Short)
            .setMaxLength(7)
            .setRequired(false)
            .setValue(draft.color ? "#" + draft.color.toString(16).padStart(6, "0") : ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "edit_visuals") {
    const draft = drafts.get(interaction.user.id) ?? {};
    const modal = new ModalBuilder()
      .setCustomId(encodeId("embed", "modal_visuals"))
      .setTitle("Edit Visuals")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("banner")
            .setLabel("Banner / Image URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft.bannerUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("thumb")
            .setLabel("Thumbnail URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft.thumbnailUrl ?? ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "edit_footer") {
    const draft = drafts.get(interaction.user.id) ?? {};
    const modal = new ModalBuilder()
      .setCustomId(encodeId("embed", "modal_footer"))
      .setTitle("Footer & Author")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("author")
            .setLabel("Author Name")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft.authorName ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("author_icon")
            .setLabel("Author Icon URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft.authorIconUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("footer")
            .setLabel("Footer Text")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft.footerText ?? ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "send") {
    const targetId = args[0]!;
    const draft = drafts.get(interaction.user.id);
    if (!draft) {
      await interaction.reply({ embeds: [errorEmbed("Expired", "Editor session expired. Run `/embed create` again.")], ephemeral: true });
      return;
    }
    const channel = interaction.guild?.channels.cache.get(targetId) as TextChannel | undefined;
    if (!channel?.isTextBased()) {
      await interaction.reply({ embeds: [errorEmbed("Channel Missing", "I can't send to that channel anymore.")], ephemeral: true });
      return;
    }
    await channel.send({ embeds: [renderEmbedConfig(draft)] });
    drafts.delete(interaction.user.id);
    await interaction.update({
      embeds: [successEmbed("Embed Sent", `Posted in ${channel}.`)],
      components: [],
    });
    return;
  }

  if (action === "cancel") {
    drafts.delete(interaction.user.id);
    await interaction.update({
      embeds: [brandedEmbed({ kind: "neutral", title: `${EMOJI.cancel} Editor Closed` })],
      components: [],
    });
    return;
  }
}

export async function handleEmbedModal(interaction: ModalSubmitInteraction): Promise<void> {
  const { action } = decodeId(interaction.customId);
  const draft = drafts.get(interaction.user.id) ?? {};

  if (action === "modal_basics") {
    const title = interaction.fields.getTextInputValue("title").trim();
    const description = interaction.fields.getTextInputValue("description").trim();
    const colorRaw = interaction.fields.getTextInputValue("color").trim();
    draft.title = title || null;
    draft.description = description || null;
    const c = parseColor(colorRaw);
    if (c !== undefined) draft.color = c;
  } else if (action === "modal_visuals") {
    draft.bannerUrl = interaction.fields.getTextInputValue("banner").trim() || null;
    draft.thumbnailUrl = interaction.fields.getTextInputValue("thumb").trim() || null;
  } else if (action === "modal_footer") {
    draft.authorName = interaction.fields.getTextInputValue("author").trim() || null;
    draft.authorIconUrl = interaction.fields.getTextInputValue("author_icon").trim() || null;
    draft.footerText = interaction.fields.getTextInputValue("footer").trim() || null;
  }
  drafts.set(interaction.user.id, draft);

  // Re-render preview
  const message = interaction.message;
  if (!message) {
    await interaction.reply({ embeds: [successEmbed("Saved", "Open the previous editor message to continue.")], ephemeral: true });
    return;
  }
  // Find target id from existing button row
  const messageComponents = message.components as unknown as Array<{ components: Array<{ customId?: string }> }>;
  const sendBtn = messageComponents
    .flatMap((row) => row.components)
    .find((c) => c.customId?.startsWith("embed:send:"));
  const targetId = sendBtn?.customId?.split(":")[2] ?? interaction.channelId!;
  await (interaction as unknown as { update: (p: unknown) => Promise<unknown> }).update({
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.edit} Embed Builder`,
        description: `Live preview below — keep editing or hit **Send**.`,
      }),
      renderEmbedConfig(draft),
    ],
    components: buildPreviewComponents(targetId),
  });
}
