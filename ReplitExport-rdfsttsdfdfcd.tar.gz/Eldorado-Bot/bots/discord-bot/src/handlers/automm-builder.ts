/**
 * Auto Middleman embed builder.
 *
 * Lets admins design the branded embed that the bot posts when a buyer initiates
 * `/give automm`. Persisted per-guild on `autommConfig`. The Confirm/Cancel
 * buttons are added automatically at deposit time (not editable here) so that
 * the action surface is always safe.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type ModalSubmitInteraction,
} from "discord.js";
import { eq } from "drizzle-orm";
import { db, autommConfig, type EmbedConfig } from "@workspace/db";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";

type Draft = { embed: EmbedConfig; contentTemplate: string };
const drafts = new Map<string, Draft>();

const PLACEHOLDER_HINT =
  "Available placeholders: `{amount}` `{method}` `{address}` `{network}` `{buyer}` `{ticket}`";

function defaultDraft(existing: { embed: EmbedConfig | null; contentTemplate: string | null }): Draft {
  return {
    embed:
      existing.embed ??
      ({
        title: "💎 Auto Middleman — Deposit",
        description:
          "Hello {buyer}, please send **{amount} {method}** to the wallet below.\n\n" +
          "**Network:** {network}\n**Address:** `{address}`\n\n" +
          "Once the deposit is detected, the bot will notify everyone in this ticket. " +
          "**A human middleman releases the goods — the bot never moves funds.**",
        color: 0x7c3aed,
      } satisfies EmbedConfig),
    contentTemplate: existing.contentTemplate ?? "",
  };
}

function parseColor(input: string | null): number | undefined {
  if (!input) return undefined;
  const t = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(t)) return undefined;
  return parseInt(t, 16);
}

function buildEditorComponents(): ActionRowBuilder<ButtonBuilder>[] {
  const editRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "edit_basics"))
      .setLabel("Edit Basics")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "edit_visuals"))
      .setLabel("Visuals")
      .setEmoji("🎨")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "edit_footer"))
      .setLabel("Footer / Author")
      .setEmoji("📝")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "edit_content"))
      .setLabel("Message Above")
      .setEmoji("💬")
      .setStyle(ButtonStyle.Secondary),
  );
  const saveRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "save"))
      .setLabel("Save")
      .setEmoji(EMOJI.save)
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "cancel"))
      .setLabel("Cancel")
      .setEmoji(EMOJI.cancel)
      .setStyle(ButtonStyle.Danger),
  );
  return [editRow, saveRow];
}

async function ensureConfigRow(guildId: string): Promise<typeof autommConfig.$inferSelect> {
  const [row] = await db.select().from(autommConfig).where(eq(autommConfig.guildId, guildId)).limit(1);
  if (row) return row;
  const [created] = await db.insert(autommConfig).values({ guildId }).returning();
  return created!;
}

export async function openAutommBuilder(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const cfg = await ensureConfigRow(interaction.guildId);
  const draft = defaultDraft(cfg);
  drafts.set(interaction.user.id, draft);
  await interaction.reply({
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.diamond} Auto Middleman — Embed Builder`,
        description:
          `${PLACEHOLDER_HINT}\n\n` +
          `Live preview below. Confirm/Cancel buttons are added automatically when posted to a ticket.`,
      }),
      renderEmbedConfig(draft.embed, "Deposit"),
    ],
    components: buildEditorComponents(),
    ephemeral: true,
  });
}

async function refresh(interaction: ButtonInteraction | ModalSubmitInteraction): Promise<void> {
  const draft = drafts.get(interaction.user.id);
  if (!draft) return;
  const payload = {
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.diamond} Auto Middleman — Embed Builder`,
        description:
          `${PLACEHOLDER_HINT}\n\n` +
          (draft.contentTemplate ? `**Message above embed:**\n${draft.contentTemplate}\n\n` : "") +
          "Edit and **Save** to persist.",
      }),
      renderEmbedConfig(draft.embed, "Deposit"),
    ],
    components: buildEditorComponents(),
  };
  if (interaction.deferred || interaction.replied) await interaction.editReply(payload);
  else await (interaction as unknown as { update: (p: typeof payload) => Promise<unknown> }).update(payload);
}

export async function handleAutommBuilderButton(interaction: ButtonInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const { action } = decodeId(interaction.customId);
  const draft = drafts.get(interaction.user.id);
  if (!draft && action !== "cancel") {
    return interaction.reply({
      embeds: [errorEmbed("Editor Expired", "Run `/automm embed` again.")],
      ephemeral: true,
    });
  }

  if (action === "edit_basics") {
    const modal = new ModalBuilder()
      .setCustomId(encodeId("automm", "modal_basics"))
      .setTitle("Edit Basics")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("title")
            .setLabel("Title")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(256)
            .setValue(draft!.embed.title ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("Description")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(4000)
            .setValue(draft!.embed.description ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("color")
            .setLabel("Color (hex, e.g. 7C3AED)")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(7)
            .setValue(draft!.embed.color ? draft!.embed.color.toString(16).padStart(6, "0") : ""),
        ),
      );
    return interaction.showModal(modal);
  }

  if (action === "edit_visuals") {
    const modal = new ModalBuilder()
      .setCustomId(encodeId("automm", "modal_visuals"))
      .setTitle("Edit Visuals")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("banner")
            .setLabel("Banner / Image URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft!.embed.bannerUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("thumb")
            .setLabel("Thumbnail URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft!.embed.thumbnailUrl ?? ""),
        ),
      );
    return interaction.showModal(modal);
  }

  if (action === "edit_footer") {
    const modal = new ModalBuilder()
      .setCustomId(encodeId("automm", "modal_footer"))
      .setTitle("Footer & Author")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("author")
            .setLabel("Author Name")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft!.embed.authorName ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("author_icon")
            .setLabel("Author Icon URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft!.embed.authorIconUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("footer")
            .setLabel("Footer Text")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(draft!.embed.footerText ?? ""),
        ),
      );
    return interaction.showModal(modal);
  }

  if (action === "edit_content") {
    const modal = new ModalBuilder()
      .setCustomId(encodeId("automm", "modal_content"))
      .setTitle("Message Above Embed")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("content")
            .setLabel("Message text (optional)")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(2000)
            .setValue(draft!.contentTemplate),
        ),
      );
    return interaction.showModal(modal);
  }

  if (action === "save") {
    await db
      .update(autommConfig)
      .set({ embed: draft!.embed, contentTemplate: draft!.contentTemplate || null, updatedAt: new Date() })
      .where(eq(autommConfig.guildId, interaction.guildId));
    drafts.delete(interaction.user.id);
    return interaction.update({
      embeds: [successEmbed("Saved", "Auto Middleman embed updated.")],
      components: [],
    });
  }

  if (action === "cancel") {
    drafts.delete(interaction.user.id);
    return interaction.update({
      embeds: [brandedEmbed({ kind: "neutral", title: `${EMOJI.cancel} Builder Closed` })],
      components: [],
    });
  }
}

export async function handleAutommBuilderModal(interaction: ModalSubmitInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const { action } = decodeId(interaction.customId);
  const draft = drafts.get(interaction.user.id);
  if (!draft) {
    return interaction.reply({
      embeds: [errorEmbed("Editor Expired", "Run `/automm embed` again.")],
      ephemeral: true,
    });
  }

  if (action === "modal_basics") {
    draft.embed.title = interaction.fields.getTextInputValue("title").trim() || null;
    draft.embed.description = interaction.fields.getTextInputValue("description").trim() || null;
    const c = parseColor(interaction.fields.getTextInputValue("color"));
    if (c !== undefined) draft.embed.color = c;
  } else if (action === "modal_visuals") {
    draft.embed.bannerUrl = interaction.fields.getTextInputValue("banner").trim() || null;
    draft.embed.thumbnailUrl = interaction.fields.getTextInputValue("thumb").trim() || null;
  } else if (action === "modal_footer") {
    draft.embed.authorName = interaction.fields.getTextInputValue("author").trim() || null;
    draft.embed.authorIconUrl = interaction.fields.getTextInputValue("author_icon").trim() || null;
    draft.embed.footerText = interaction.fields.getTextInputValue("footer").trim() || null;
  } else if (action === "modal_content") {
    draft.contentTemplate = interaction.fields.getTextInputValue("content").trim();
  }
  drafts.set(interaction.user.id, draft);
  await refresh(interaction);
}
