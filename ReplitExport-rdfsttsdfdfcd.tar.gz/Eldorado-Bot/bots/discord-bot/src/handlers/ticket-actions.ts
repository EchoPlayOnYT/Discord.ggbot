import {
  type ButtonInteraction,
  type StringSelectMenuInteraction,
  type ModalSubmitInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits,
  type CategoryChannel,
  type TextChannel,
  OverwriteType,
  type APIEmbed,
  type Guild,
  type GuildMember,
  type MessageCreateOptions,
} from "discord.js";
import { db, ticketPanels, ticketPanelOptions, tickets, ticketCounters, type TicketButtonStyle } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { brandedEmbed, errorEmbed, renderEmbedConfig, applyPlaceholders, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";

function styleEnum(s: TicketButtonStyle): ButtonStyle {
  switch (s) {
    case "primary":
      return ButtonStyle.Primary;
    case "secondary":
      return ButtonStyle.Secondary;
    case "success":
      return ButtonStyle.Success;
    case "danger":
      return ButtonStyle.Danger;
  }
}

export async function buildPanelMessage(panel: typeof ticketPanels.$inferSelect, options: (typeof ticketPanelOptions.$inferSelect)[]): Promise<MessageCreateOptions> {
  const embed = renderEmbedConfig(panel.embed);
  if (panel.layout === "dropdown") {
    const select = new StringSelectMenuBuilder()
      .setCustomId(encodeId("ticket", "open_select", String(panel.id)))
      .setPlaceholder("Choose a ticket category…")
      .addOptions(
        options.slice(0, 25).map((o) => ({
          label: o.label.slice(0, 100),
          description: o.description?.slice(0, 100) ?? undefined,
          value: String(o.id),
          emoji: o.emoji ?? undefined,
        })),
      );
    return { embeds: [embed], components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)] };
  }
  // buttons layout (max 5)
  const row = new ActionRowBuilder<ButtonBuilder>();
  for (const o of options.slice(0, 5)) {
    const btn = new ButtonBuilder()
      .setCustomId(encodeId("ticket", "open_btn", String(o.id)))
      .setLabel(o.label.slice(0, 80))
      .setStyle(styleEnum(o.style));
    if (o.emoji) btn.setEmoji(o.emoji);
    row.addComponents(btn);
  }
  return { embeds: [embed], components: [row] };
}

async function nextTicketNumber(guildId: string): Promise<number> {
  const result = await db
    .insert(ticketCounters)
    .values({ guildId, lastNumber: 1 })
    .onConflictDoUpdate({
      target: ticketCounters.guildId,
      set: { lastNumber: sql`${ticketCounters.lastNumber} + 1` },
    })
    .returning({ n: ticketCounters.lastNumber });
  return result[0]!.n;
}

async function createTicketChannel(
  guild: Guild,
  member: GuildMember,
  option: typeof ticketPanelOptions.$inferSelect,
): Promise<{ channel: TextChannel; number: number }> {
  const number = await nextTicketNumber(guild.id);
  const safeName = member.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 20) || "ticket";
  const name = `ticket-${String(number).padStart(4, "0")}-${safeName}`;
  const category = guild.channels.cache.get(option.categoryId) as CategoryChannel | undefined;
  if (!category || category.type !== ChannelType.GuildCategory) {
    throw new Error("Configured category no longer exists. Ask an admin to fix the panel option.");
  }
  const channel = await guild.channels.create({
    name,
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `Ticket #${number} — opened by ${member.user.tag} (${member.id})`,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        type: OverwriteType.Role,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: member.id,
        type: OverwriteType.Member,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
          PermissionFlagsBits.EmbedLinks,
        ],
      },
      {
        id: guild.client.user.id,
        type: OverwriteType.Member,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageMessages,
          PermissionFlagsBits.ManageChannels,
        ],
      },
      ...option.staffRoleIds.map((roleId) => ({
        id: roleId,
        type: OverwriteType.Role,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
          PermissionFlagsBits.EmbedLinks,
        ],
      })),
    ],
  });
  return { channel, number };
}

async function postTicketWelcome(
  channel: TextChannel,
  option: typeof ticketPanelOptions.$inferSelect,
  member: GuildMember,
  ticketId: number,
  formAnswers?: { question: string; answer: string }[],
): Promise<void> {
  const ctx = {
    user: member.user,
    userMention: member.toString(),
    userTag: member.user.tag,
    serverName: channel.guild.name,
    memberCount: channel.guild.memberCount,
  };
  const embed = renderEmbedConfig(option.ticketEmbed);
  if (option.ticketEmbed.title) embed.setTitle(applyPlaceholders(option.ticketEmbed.title, ctx));
  if (option.ticketEmbed.description) embed.setDescription(applyPlaceholders(option.ticketEmbed.description, ctx));
  if (formAnswers?.length) {
    embed.addFields(formAnswers.map((f) => ({ name: f.question.slice(0, 256), value: f.answer.slice(0, 1024) || "_(empty)_" })));
  }
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("ticket", "claim", String(ticketId)))
      .setLabel(option.claimButtonLabel)
      .setEmoji(option.claimButtonEmoji ?? EMOJI.claim)
      .setStyle(styleEnum(option.claimButtonStyle)),
    new ButtonBuilder()
      .setCustomId(encodeId("ticket", "close", String(ticketId)))
      .setLabel(option.closeButtonLabel)
      .setEmoji(option.closeButtonEmoji ?? EMOJI.close)
      .setStyle(styleEnum(option.closeButtonStyle)),
  );
  const mention = [member.toString(), ...option.staffRoleIds.map((r) => `<@&${r}>`)].join(" ");
  await channel.send({ content: mention, embeds: [embed], components: [row] });
}

export async function handleTicketInteraction(interaction: ButtonInteraction | StringSelectMenuInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const { action, args } = decodeId(interaction.customId);

  if (action === "open_btn" || (action === "open_select" && interaction.isStringSelectMenu())) {
    const optionId = action === "open_btn" ? Number(args[0]) : Number((interaction as StringSelectMenuInteraction).values[0]);
    const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
    if (!option) {
      await interaction.reply({ embeds: [errorEmbed("Option Missing", "This ticket option no longer exists.")], ephemeral: true });
      return;
    }
    // Already-open ticket?
    const existing = await db
      .select()
      .from(tickets)
      .where(and(eq(tickets.guildId, interaction.guildId), eq(tickets.openerId, interaction.user.id), eq(tickets.optionId, optionId), eq(tickets.status, "open")))
      .limit(1);
    if (existing[0]) {
      await interaction.reply({
        embeds: [errorEmbed("Ticket Already Open", `You already have an open ticket: <#${existing[0].channelId}>.`)],
        ephemeral: true,
      });
      return;
    }
    if (option.formQuestions.length > 0) {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("ticket", "form_submit", String(optionId)))
        .setTitle(`Open Ticket — ${option.label}`.slice(0, 45));
      for (const q of option.formQuestions.slice(0, 5)) {
        const input = new TextInputBuilder()
          .setCustomId(q.id)
          .setLabel(q.label.slice(0, 45))
          .setStyle(q.style === "paragraph" ? TextInputStyle.Paragraph : TextInputStyle.Short)
          .setRequired(q.required);
        if (q.placeholder) input.setPlaceholder(q.placeholder.slice(0, 100));
        if (q.maxLength) input.setMaxLength(q.maxLength);
        modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
      }
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    await openNewTicket(interaction, optionId);
    return;
  }

  if (action === "claim") {
    const ticketId = Number(args[0]);
    const [t] = await db.select().from(tickets).where(eq(tickets.id, ticketId)).limit(1);
    if (!t) return interaction.reply({ embeds: [errorEmbed("Missing", "Ticket not found.")], ephemeral: true });
    const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, t.optionId!)).limit(1);
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const isStaff = option ? option.staffRoleIds.some((r) => member.roles.cache.has(r)) : false;
    if (!isStaff && !member.permissions.has(PermissionFlagsBits.ManageChannels))
      return interaction.reply({ embeds: [errorEmbed("Not Allowed", "Only staff can claim tickets.")], ephemeral: true });
    if (t.claimedBy)
      return interaction.reply({
        embeds: [errorEmbed("Already Claimed", `Already claimed by <@${t.claimedBy}>.`)],
        ephemeral: true,
      });
    await db.update(tickets).set({ claimedBy: interaction.user.id }).where(eq(tickets.id, ticketId));
    await interaction.reply({
      embeds: [successEmbed(`${EMOJI.claim} Ticket Claimed`, `${interaction.user} is now handling this ticket.`)],
    });
    return;
  }

  if (action === "close") {
    const ticketId = Number(args[0]);
    const [t] = await db.select().from(tickets).where(eq(tickets.id, ticketId)).limit(1);
    if (!t) return interaction.reply({ embeds: [errorEmbed("Missing", "Ticket not found.")], ephemeral: true });
    const confirm = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("ticket", "close_confirm", String(ticketId)))
        .setLabel("Confirm Close")
        .setEmoji(EMOJI.close)
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(encodeId("ticket", "close_cancel", String(ticketId)))
        .setLabel("Cancel")
        .setEmoji(EMOJI.cancel)
        .setStyle(ButtonStyle.Secondary),
    );
    await interaction.reply({
      embeds: [brandedEmbed({ kind: "warning", title: `${EMOJI.warn} Confirm Close`, description: `Closing this ticket will archive and delete the channel in 10 seconds.` })],
      components: [confirm],
    });
    return;
  }

  if (action === "close_cancel") {
    await (interaction as ButtonInteraction).update({ embeds: [brandedEmbed({ kind: "neutral", title: "Close Cancelled" })], components: [] });
    return;
  }

  if (action === "close_confirm") {
    const ticketId = Number(args[0]);
    const [t] = await db.select().from(tickets).where(eq(tickets.id, ticketId)).limit(1);
    if (!t) return;
    await db.update(tickets).set({ status: "closed", closedAt: new Date(), closedBy: interaction.user.id }).where(eq(tickets.id, ticketId));
    await (interaction as ButtonInteraction).update({
      embeds: [
        brandedEmbed({
          kind: "danger",
          title: `${EMOJI.close} Ticket Closed`,
          description: `Closed by ${interaction.user}. Channel will be deleted in 10 seconds.`,
        }),
      ],
      components: [],
    });
    setTimeout(() => {
      interaction.channel?.delete().catch(() => undefined);
    }, 10_000);
    return;
  }
}

async function openNewTicket(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction,
  optionId: number,
  formAnswers?: { question: string; answer: string }[],
): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
  if (!option) return;
  const member = await interaction.guild.members.fetch(interaction.user.id);
  await interaction.deferReply({ ephemeral: true });
  try {
    const { channel, number } = await createTicketChannel(interaction.guild, member, option);
    const [created] = await db
      .insert(tickets)
      .values({
        guildId: interaction.guildId,
        panelId: option.panelId,
        optionId: option.id,
        channelId: channel.id,
        openerId: interaction.user.id,
        ticketNumber: number,
        formAnswers: formAnswers ?? [],
      })
      .returning();
    await postTicketWelcome(channel, option, member, created!.id, formAnswers);
    await interaction.editReply({ embeds: [successEmbed("Ticket Opened", `Your ticket is ready: ${channel}`)] });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    await interaction.editReply({ embeds: [errorEmbed("Couldn't Create Ticket", msg)] });
  }
}

export async function handleTicketModal(interaction: ModalSubmitInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const { action, args } = decodeId(interaction.customId);
  if (action !== "form_submit") return;
  const optionId = Number(args[0]);
  const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
  if (!option) return;
  const answers: { question: string; answer: string }[] = [];
  for (const q of option.formQuestions) {
    let val = "";
    try {
      val = interaction.fields.getTextInputValue(q.id);
    } catch {
      val = "";
    }
    answers.push({ question: q.label, answer: val });
  }
  await openNewTicket(interaction, optionId, answers);
}
