import {
  type Message,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  ChannelType,
  OverwriteType,
} from "discord.js";
import { db, customCommands, tickets, ticketPanelOptions } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import ms from "ms";
import { brandedEmbed, errorEmbed, moderationEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { encodeId } from "../utils/component-ids.js";
import { getGuildSettings, sendModLog } from "../utils/db-helpers.js";
import { outranks } from "../utils/permissions.js";
import { parseDuration } from "../utils/duration.js";
import { warnings } from "@workspace/db";

function buttonStyleFromString(s: string): ButtonStyle {
  switch (s) {
    case "primary":
      return ButtonStyle.Primary;
    case "secondary":
      return ButtonStyle.Secondary;
    case "success":
      return ButtonStyle.Success;
    case "danger":
      return ButtonStyle.Danger;
    case "link":
      return ButtonStyle.Link;
    default:
      return ButtonStyle.Secondary;
  }
}

export async function handlePrefixMessage(message: Message): Promise<unknown> {
  if (!message.inGuild() || message.author.bot) return;
  const settings = await getGuildSettings(message.guildId);
  const prefix = settings.prefixes.find((p) => message.content.startsWith(p));
  if (!prefix) return;
  const body = message.content.slice(prefix.length).trim();
  if (!body) return;
  const [name, ...rest] = body.split(/\s+/);
  if (!name) return;
  const lower = name.toLowerCase();

  // Built-in moderation/utility shortcuts
  if (lower === "ping") {
    await message.reply({ embeds: [brandedEmbed({ kind: "primary", title: `${EMOJI.ping} Pong`, description: `Latency: \`${Math.round(message.client.ws.ping)}ms\`` })] });
    return;
  }
  if (lower === "help" || lower === "commands" || lower === "h") {
    const prefixList = settings.prefixes.map((p) => `\`${p}\``).join(" ");
    const slashCount = message.client.application?.commands.cache.size ?? 0;
    const help = brandedEmbed({
      kind: "primary",
      title: `📖 ${message.client.user.username} Help`,
      description: [
        `**Prefixes for this server:** ${prefixList}`,
        `Use any of those before a command name (e.g. \`${prefix}ping\`).`,
        `Slash commands (\`/\`) work everywhere — there are **${slashCount}** registered.`,
      ].join("\n"),
      fields: [
        {
          name: "🛠️ Moderation (prefix)",
          value: "`ban` `kick` `mute <time>` `unmute` `warn` `clear <n>` — all need the matching permission.",
        },
        {
          name: "🧰 Utility (prefix)",
          value: "`ping` `say <text>` `help`",
        },
        {
          name: "💬 Custom commands",
          value: "Any command created with `/custom create` works with every prefix above.",
        },
        {
          name: "🎫 Tickets, giveaways, levels, suggestions, auto-middleman & more",
          value: "Use the slash commands: `/panel` `/giveaway` `/rank` `/suggest` `/automm` `/give` `/set` `/welcome` `/embed` `/custom` `/help` and more — type `/` in chat to browse.",
        },
      ],
    });
    await message.reply({ embeds: [help] });
    return;
  }
  if (lower === "say") {
    if (!message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return;
    const text = rest.join(" ");
    if (!text) return;
    await message.delete().catch(() => undefined);
    await message.channel.send({ content: text });
    return;
  }
  if (lower === "ban" || lower === "kick") {
    if (!message.member) return;
    const target = message.mentions.users.first();
    if (!target) return;
    const targetMember = await message.guild.members.fetch(target.id).catch(() => null);
    if (!targetMember) return message.reply({ embeds: [errorEmbed("Not Found", "User isn't in this server.")] });
    const need = lower === "ban" ? PermissionFlagsBits.BanMembers : PermissionFlagsBits.KickMembers;
    if (!message.member.permissions.has(need))
      return message.reply({ embeds: [errorEmbed("Missing Permission", "You don't have permission for that.")] });
    if (!outranks(message.member, targetMember))
      return message.reply({ embeds: [errorEmbed("Hierarchy", "You can't moderate someone with an equal or higher role.")] });
    const reasonRaw = rest.slice(1).join(" ") || "No reason provided";
    if (lower === "ban") {
      await message.guild.members.ban(target.id, { reason: reasonRaw, deleteMessageSeconds: 0 });
      const e = moderationEmbed({
        action: "Member Banned",
        emoji: EMOJI.ban,
        target,
        moderator: message.author,
        reason: reasonRaw,
        kind: "danger",
      });
      await message.reply({ embeds: [e] });
      await sendModLog(message.guild, e);
    } else {
      await targetMember.kick(reasonRaw);
      const e = moderationEmbed({
        action: "Member Kicked",
        emoji: EMOJI.kick,
        target,
        moderator: message.author,
        reason: reasonRaw,
        kind: "warning",
      });
      await message.reply({ embeds: [e] });
      await sendModLog(message.guild, e);
    }
    return;
  }
  if (lower === "mute" || lower === "timeout") {
    if (!message.member?.permissions.has(PermissionFlagsBits.ModerateMembers)) return;
    const target = message.mentions.users.first();
    if (!target) return;
    const targetMember = await message.guild.members.fetch(target.id).catch(() => null);
    if (!targetMember) return;
    if (!outranks(message.member, targetMember)) return;
    const dur = parseDuration(rest[1] ?? "10m") ?? 600_000;
    const reason = rest.slice(2).join(" ") || "No reason provided";
    await targetMember.timeout(dur, reason);
    const e = moderationEmbed({
      action: "Member Muted",
      emoji: EMOJI.mute,
      target,
      moderator: message.author,
      reason,
      extra: [{ name: "Duration", value: `\`${ms(dur, { long: true })}\``, inline: true }],
      kind: "warning",
    });
    await message.reply({ embeds: [e] });
    await sendModLog(message.guild, e);
    return;
  }
  if (lower === "unmute") {
    if (!message.member?.permissions.has(PermissionFlagsBits.ModerateMembers)) return;
    const target = message.mentions.users.first();
    if (!target) return;
    const tm = await message.guild.members.fetch(target.id).catch(() => null);
    if (!tm) return;
    await tm.timeout(null, "Unmute via prefix command");
    const e = moderationEmbed({
      action: "Member Unmuted",
      emoji: EMOJI.unmute,
      target,
      moderator: message.author,
      reason: "Timeout removed",
      kind: "success",
    });
    await message.reply({ embeds: [e] });
    await sendModLog(message.guild, e);
    return;
  }
  if (lower === "warn") {
    if (!message.member?.permissions.has(PermissionFlagsBits.ModerateMembers)) return;
    const target = message.mentions.users.first();
    if (!target) return;
    const reason = rest.slice(1).join(" ") || "No reason provided";
    await db.insert(warnings).values({
      guildId: message.guildId,
      userId: target.id,
      moderatorId: message.author.id,
      reason,
    });
    const e = moderationEmbed({
      action: "Member Warned",
      emoji: EMOJI.warning,
      target,
      moderator: message.author,
      reason,
      kind: "warning",
    });
    await message.reply({ embeds: [e] });
    await sendModLog(message.guild, e);
    return;
  }
  if (lower === "clear" || lower === "purge") {
    if (!message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return;
    const n = parseInt(rest[0] ?? "10", 10);
    if (!Number.isFinite(n) || n < 1 || n > 100)
      return message.reply({ embeds: [errorEmbed("Invalid Count", "Use 1-100.")] });
    if (!message.channel.isTextBased() || !("bulkDelete" in message.channel)) return;
    const deleted = await message.channel.bulkDelete(n + 1, true);
    const r = await message.channel.send({
      embeds: [successEmbed(`${EMOJI.broom} Cleared`, `Deleted **${deleted.size - 1}** messages.`)],
    });
    setTimeout(() => r.delete().catch(() => undefined), 5000);
    return;
  }

  // ─── Ticket-channel prefix shortcuts: $add @user, $claim, $close ──────
  if (lower === "add" || lower === "claim" || lower === "close") {
    if (message.channel.type !== ChannelType.GuildText) return;
    const [ticket] = await db.select().from(tickets).where(eq(tickets.channelId, message.channelId)).limit(1);
    if (!ticket || ticket.guildId !== message.guildId) {
      return message.reply({
        embeds: [errorEmbed("Not a Ticket", "Run this inside a ticket channel.")],
      });
    }
    const [option] = ticket.optionId
      ? await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, ticket.optionId)).limit(1)
      : [undefined];
    if (!message.member) return;
    const isStaff = option ? option.staffRoleIds.some((r) => message.member!.roles.cache.has(r)) : false;
    const canManage = isStaff || message.member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (lower === "add") {
      if (!canManage) {
        return message.reply({ embeds: [errorEmbed("Not Allowed", "Only staff can add users to a ticket.")] });
      }
      const target = message.mentions.users.first();
      if (!target) {
        return message.reply({ embeds: [errorEmbed("Missing User", "Mention a user, e.g. `add @someone`.")] });
      }
      const channel = message.channel;
      try {
        await channel.permissionOverwrites.edit(
          target.id,
          {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true,
            AttachFiles: true,
            EmbedLinks: true,
          },
          { type: OverwriteType.Member, reason: `Added by ${message.author.tag} via $add` },
        );
      } catch {
        return message.reply({ embeds: [errorEmbed("Failed", "I couldn't update channel permissions. Check my role permissions.")] });
      }
      return message.reply({
        embeds: [successEmbed(`${EMOJI.add} User Added`, `${target} has been added to this ticket by ${message.author}.`)],
      });
    }

    if (lower === "claim") {
      if (!canManage) {
        return message.reply({ embeds: [errorEmbed("Not Allowed", "Only staff can claim tickets.")] });
      }
      if (ticket.claimedBy) {
        return message.reply({ embeds: [errorEmbed("Already Claimed", `Already claimed by <@${ticket.claimedBy}>.`)] });
      }
      await db.update(tickets).set({ claimedBy: message.author.id }).where(eq(tickets.id, ticket.id));
      return message.reply({
        embeds: [successEmbed(`${EMOJI.claim} Ticket Claimed`, `${message.author} is now handling this ticket.`)],
      });
    }

    if (lower === "close") {
      if (!canManage && message.author.id !== ticket.openerId) {
        return message.reply({ embeds: [errorEmbed("Not Allowed", "Only the ticket opener or staff can close it.")] });
      }
      const confirm = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(encodeId("ticket", "close_confirm", String(ticket.id)))
          .setLabel("Confirm Close")
          .setEmoji(EMOJI.close)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(encodeId("ticket", "close_cancel", String(ticket.id)))
          .setLabel("Cancel")
          .setEmoji(EMOJI.cancel ?? "✖️")
          .setStyle(ButtonStyle.Secondary),
      );
      return message.reply({
        embeds: [
          brandedEmbed({
            kind: "warning",
            title: `${EMOJI.warn} Confirm Close`,
            description: `Closing this ticket will archive and delete the channel in 10 seconds.`,
          }),
        ],
        components: [confirm],
      });
    }
  }

  // Custom commands
  const [cmd] = await db
    .select()
    .from(customCommands)
    .where(and(eq(customCommands.guildId, message.guildId), eq(customCommands.name, lower)))
    .limit(1);
  if (!cmd) return;
  await db.update(customCommands).set({ usageCount: cmd.usageCount + 1 }).where(eq(customCommands.id, cmd.id));
  const action = cmd.action;
  if (action.type === "message") {
    await message.channel.send({ content: action.content });
  } else if (action.type === "url") {
    await message.channel.send({
      embeds: [brandedEmbed({ kind: "primary", title: `${EMOJI.arrow} ${cmd.name}`, description: action.url, url: action.url } as Parameters<typeof brandedEmbed>[0])],
    });
  } else if (action.type === "embed") {
    await message.channel.send({ embeds: [renderEmbedConfig(action.embed)] });
  } else if (action.type === "buttons") {
    const row = new ActionRowBuilder<ButtonBuilder>();
    for (const b of action.buttons.slice(0, 5)) {
      const btn = new ButtonBuilder().setLabel(b.label).setStyle(buttonStyleFromString(b.style));
      if (b.emoji) btn.setEmoji(b.emoji);
      if (b.style === "link" && b.url) btn.setURL(b.url);
      else btn.setCustomId(encodeId("ccbtn", b.id));
      row.addComponents(btn);
    }
    await message.channel.send({
      content: action.content || undefined,
      embeds: action.embed ? [renderEmbedConfig(action.embed)] : [],
      components: action.buttons.length ? [row] : [],
    });
  }
}
