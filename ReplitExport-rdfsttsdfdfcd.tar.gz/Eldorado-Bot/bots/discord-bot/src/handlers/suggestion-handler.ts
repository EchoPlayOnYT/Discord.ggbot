import { type ButtonInteraction } from "discord.js";
import { db, suggestions } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { decodeId } from "../utils/component-ids.js";
import { errorEmbed } from "../embed.js";
import { EMOJI } from "../config.js";

export async function handleSuggestionButton(interaction: ButtonInteraction): Promise<unknown> {
  if (!interaction.guildId) return;
  const { action } = decodeId(interaction.customId);
  if (action !== "up" && action !== "down") return;
  const [s] = await db
    .select()
    .from(suggestions)
    .where(and(eq(suggestions.guildId, interaction.guildId), eq(suggestions.messageId, interaction.message.id)))
    .limit(1);
  if (!s) return interaction.reply({ embeds: [errorEmbed("Missing", "Suggestion is no longer tracked.")], ephemeral: true });

  const upvotes = new Set(s.upvotes);
  const downvotes = new Set(s.downvotes);
  if (action === "up") {
    if (upvotes.has(interaction.user.id)) upvotes.delete(interaction.user.id);
    else {
      upvotes.add(interaction.user.id);
      downvotes.delete(interaction.user.id);
    }
  } else {
    if (downvotes.has(interaction.user.id)) downvotes.delete(interaction.user.id);
    else {
      downvotes.add(interaction.user.id);
      upvotes.delete(interaction.user.id);
    }
  }
  const upArr = [...upvotes];
  const downArr = [...downvotes];
  await db.update(suggestions).set({ upvotes: upArr, downvotes: downArr }).where(eq(suggestions.id, s.id));

  // Update the buttons with new counts
  type RawComp = { data: { custom_id?: string; label?: string; emoji?: { name?: string }; style?: number; type: number } };
  type RawRow = { components: RawComp[] };
  const rawRows = interaction.message.components as unknown as RawRow[];
  const components = rawRows.map((row) => ({
    type: 1,
    components: row.components.map((c) => {
      const data = c.data;
      if (data.custom_id?.endsWith(":up")) return { ...data, label: String(upArr.length) };
      if (data.custom_id?.endsWith(":down")) return { ...data, label: String(downArr.length) };
      return data;
    }),
  }));
  await interaction.update({ components: components as never });
}
