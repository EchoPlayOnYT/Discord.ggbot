import {
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type ChannelSelectMenuInteraction,
  type RoleSelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelType,
} from "discord.js";
import { db, ticketPanels, ticketPanelOptions, type EmbedConfig, type TicketButtonStyle, type TicketFormQuestion } from "@workspace/db";
import { eq, asc, and } from "drizzle-orm";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";
import { randomUUID } from "node:crypto";

// Map userId → current panel being edited, plus selected option
type EditorState = { panelId: number; optionId?: number };
const editors = new Map<string, EditorState>();

export function setPanelDraft(userId: string, panelId: number, optionId?: number): void {
  editors.set(userId, { panelId, optionId });
}
export function getPanelDraft(userId: string): EditorState | undefined {
  return editors.get(userId);
}

function parseColor(input: string | null): number | undefined {
  if (!input) return undefined;
  const t = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(t)) return undefined;
  return parseInt(t, 16);
}

function styleEnum(s: TicketButtonStyle): ButtonStyle {
  switch (s) {
    case "primary":
      return ButtonStyle.Primary;
    case "secondary":
      return ButtonStyle.Secondary;
    case "success":
      return ButtonStyle.Success;
    case "danger":
      return ButtonStyle.Danger;
  }
}

export async function openPanelEditor(
  interaction: ChatInputCommandInteraction | ButtonInteraction | ModalSubmitInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction,
  panelId: number,
): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const [panel] = await db
    .select()
    .from(ticketPanels)
    .where(and(eq(ticketPanels.id, panelId), eq(ticketPanels.guildId, interaction.guildId)))
    .limit(1);
  if (!panel) {
    const payload = { embeds: [errorEmbed("Panel Missing", "Panel was deleted.")], components: [], ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.editReply(payload);
    else if (interaction.isChatInputCommand()) await interaction.reply(payload);
    else await (interaction as unknown as { update: (p: typeof payload) => Promise<unknown> }).update(payload);
    return;
  }
  const options = await db
    .select()
    .from(ticketPanelOptions)
    .where(eq(ticketPanelOptions.panelId, panelId))
    .orderBy(asc(ticketPanelOptions.position));

  const optionLines = options.length
    ? options
        .map(
          (o, i) =>
            `**${i + 1}.** ${o.emoji ?? ""} **${o.label}** — \`${o.style}\` → <#${o.categoryId}> ${o.staffRoleIds.length ? `(staff: ${o.staffRoleIds.map((r) => `<@&${r}>`).join(" ")})` : ""}`,
        )
        .join("\n")
    : "_No ticket options yet — click **Add Ticket Option** below._";

  const embeds = [
    brandedEmbed({
      kind: "info",
      title: `${EMOJI.ticket} Panel Editor — \`#${panel.id}\` ${panel.name}`,
      description: [
        `Use the buttons below to edit the panel embed and manage ticket options.`,
        ``,
        `**Posted in:** ${panel.channelId ? `<#${panel.channelId}>` : "_not posted yet — use \`/panel send\` after saving_"}`,
        ``,
        `**Ticket Options:**`,
        optionLines,
      ].join("\n"),
    }),
    renderEmbedConfig(panel.embed),
  ];

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("panel", "edit_basics", String(panelId)))
      .setLabel("Edit Embed Title & Text")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("panel", "edit_visuals", String(panelId)))
      .setLabel("Edit Banner & Color")
      .setEmoji(EMOJI.preview)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("panel", "rename", String(panelId)))
      .setLabel("Rename Panel")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Secondary),
  );
  const totalForms = options.reduce((n, o) => n + o.formQuestions.length, 0);
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("panel", "add_option", String(panelId)))
      .setLabel("Add Ticket Option")
      .setEmoji(EMOJI.add)
      .setStyle(ButtonStyle.Success)
      .setDisabled(options.length >= 5),
    new ButtonBuilder()
      .setCustomId(encodeId("panel", "manage_forms", String(panelId)))
      .setLabel(totalForms > 0 ? `Manage Forms (${totalForms})` : "Add Forms")
      .setEmoji(EMOJI.question)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(options.length === 0),
  );
  if (options.length) {
    const optionSelect = new StringSelectMenuBuilder()
      .setCustomId(encodeId("panel", "select_option", String(panelId)))
      .setPlaceholder("Edit a ticket option…")
      .addOptions(
        options.map((o) => ({
          label: o.label.slice(0, 100),
          value: String(o.id),
          description: `→ ${o.style}`,
          emoji: o.emoji ?? undefined,
        })),
      );
    return await sendOrUpdate(interaction, {
      embeds,
      components: [
        row1,
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(optionSelect),
        row2,
      ],
    });
  }
  await sendOrUpdate(interaction, { embeds, components: [row1, row2] });
}

async function sendOrUpdate(
  interaction: ChatInputCommandInteraction | ButtonInteraction | ModalSubmitInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction,
  payload: { embeds: any[]; components: any[] },
): Promise<void> {
  if (interaction.isChatInputCommand()) {
    await interaction.reply({ ...payload, ephemeral: true });
  } else if (interaction.deferred || interaction.replied) {
    await interaction.editReply(payload);
  } else {
    await (interaction as unknown as { update: (p: typeof payload) => Promise<unknown> }).update(payload);
  }
}

async function renderFormEditor(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction,
  optionId: number,
): Promise<void> {
  const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
  if (!option) return;
  const list = option.formQuestions.length
    ? option.formQuestions
        .map((q, i) => {
          const meta = [q.style, q.required ? "required" : "optional", q.maxLength ? `max ${q.maxLength}` : null]
            .filter(Boolean)
            .join(" · ");
          const ph = q.placeholder ? `\n   _placeholder:_ ${q.placeholder}` : "";
          return `**${i + 1}.** ${q.label}\n   \`${meta}\`${ph}`;
        })
        .join("\n\n")
    : "_No form questions yet — when a user clicks the ticket button they'll open a ticket immediately. Add up to 5 questions and a modal will pop up first; the answers will appear as fields in the ticket embed._";
  const components: ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] = [];
  if (option.formQuestions.length) {
    const removeSelect = new StringSelectMenuBuilder()
      .setCustomId(encodeId("opt", "form_remove", String(optionId)))
      .setPlaceholder("Remove a question…")
      .addOptions(
        option.formQuestions.map((q, i) => ({
          label: `${i + 1}. ${q.label}`.slice(0, 100),
          value: q.id,
          description: `${q.style}${q.required ? " · required" : ""}`.slice(0, 100),
        })),
      );
    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(removeSelect));
  }
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "form_add", String(optionId)))
      .setLabel("Add Question")
      .setEmoji(EMOJI.add)
      .setStyle(ButtonStyle.Success)
      .setDisabled(option.formQuestions.length >= 5),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "form_clear", String(optionId)))
      .setLabel("Clear All")
      .setEmoji(EMOJI.delete)
      .setStyle(ButtonStyle.Danger)
      .setDisabled(option.formQuestions.length === 0),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "back_option", String(optionId)))
      .setLabel("Back to Option")
      .setEmoji(EMOJI.back)
      .setStyle(ButtonStyle.Secondary),
  );
  components.push(row);
  await sendOrUpdate(interaction, {
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.question} Form Questions — ${option.label}`,
        description: list,
      }),
    ],
    components,
  });
}

async function openOptionEditor(
  interaction: ButtonInteraction | ModalSubmitInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction,
  optionId: number,
): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
  if (!option) {
    await sendOrUpdate(interaction, {
      embeds: [errorEmbed("Option Missing", "This option was deleted.")],
      components: [],
    });
    return;
  }

  const embeds = [
    brandedEmbed({
      kind: "info",
      title: `${EMOJI.ticket} Editing Option — ${option.label}`,
      description: [
        `**Style:** \`${option.style}\` ${option.emoji ?? ""}`,
        `**Category:** <#${option.categoryId}>`,
        `**Staff Roles:** ${option.staffRoleIds.length ? option.staffRoleIds.map((r) => `<@&${r}>`).join(" ") : "_none_"}`,
        `**Form Questions:** ${option.formQuestions.length}`,
        ``,
        `**Inside-ticket buttons:**`,
        `• Close: \`${option.closeButtonStyle}\` ${option.closeButtonEmoji ?? ""} ${option.closeButtonLabel}`,
        `• Claim: \`${option.claimButtonStyle}\` ${option.claimButtonEmoji ?? ""} ${option.claimButtonLabel}`,
      ].join("\n"),
    }),
    renderEmbedConfig(option.ticketEmbed),
  ];
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "edit_button", String(optionId)))
      .setLabel("Edit Button")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "edit_embed", String(optionId)))
      .setLabel("Edit Ticket Embed")
      .setEmoji(EMOJI.preview)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "edit_messages", String(optionId)))
      .setLabel("Edit Greeting & Inside Buttons")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Secondary),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "set_category", String(optionId)))
      .setLabel("Set Category")
      .setEmoji("📁")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "set_roles", String(optionId)))
      .setLabel("Set Staff Roles")
      .setEmoji("🛡️")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "form", String(optionId)))
      .setLabel("Form Questions")
      .setEmoji(EMOJI.question)
      .setStyle(ButtonStyle.Secondary),
  );
  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "back", String(option.panelId)))
      .setLabel("Back to Panel")
      .setEmoji(EMOJI.back)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("opt", "delete", String(optionId), String(option.panelId)))
      .setLabel("Delete Option")
      .setEmoji(EMOJI.delete)
      .setStyle(ButtonStyle.Danger),
  );
  await sendOrUpdate(interaction, { embeds, components: [row1, row2, row3] });
}

export async function handlePanelInteraction(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction,
): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const { namespace, action, args } = decodeId(interaction.customId);

  if (namespace === "panel") {
    const panelId = Number(args[0]);
    if (action === "edit_basics") {
      const [panel] = await db.select().from(ticketPanels).where(eq(ticketPanels.id, panelId)).limit(1);
      if (!panel) return;
      const cfg = panel.embed;
      const modal = new ModalBuilder()
        .setCustomId(encodeId("panel", "modal_basics", String(panelId)))
        .setTitle("Panel Embed — Title & Text")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("title").setLabel("Title").setStyle(TextInputStyle.Short).setMaxLength(256).setRequired(false).setValue(cfg.title ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("description").setLabel("Description").setStyle(TextInputStyle.Paragraph).setMaxLength(4000).setRequired(false).setValue(cfg.description ?? ""),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "edit_visuals") {
      const [panel] = await db.select().from(ticketPanels).where(eq(ticketPanels.id, panelId)).limit(1);
      if (!panel) return;
      const cfg = panel.embed;
      const modal = new ModalBuilder()
        .setCustomId(encodeId("panel", "modal_visuals", String(panelId)))
        .setTitle("Panel Embed — Banner & Color")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("banner").setLabel("Banner / Image URL").setStyle(TextInputStyle.Short).setRequired(false).setValue(cfg.bannerUrl ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("thumb").setLabel("Thumbnail URL").setStyle(TextInputStyle.Short).setRequired(false).setValue(cfg.thumbnailUrl ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("color").setLabel("Color hex").setStyle(TextInputStyle.Short).setRequired(false).setValue(cfg.color ? "#" + cfg.color.toString(16).padStart(6, "0") : ""),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "rename") {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("panel", "modal_rename", String(panelId)))
        .setTitle("Rename Panel")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("name").setLabel("New name").setStyle(TextInputStyle.Short).setMaxLength(80).setRequired(true),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "add_option") {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("panel", "modal_add_option", String(panelId)))
        .setTitle("Add Ticket Option")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("label").setLabel("Button label").setStyle(TextInputStyle.Short).setMaxLength(80).setRequired(true).setValue("Support"),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (optional)").setStyle(TextInputStyle.Short).setRequired(false).setValue(EMOJI.ticket),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("style").setLabel("Style: primary / secondary / success / danger").setStyle(TextInputStyle.Short).setRequired(true).setValue("primary"),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("category_id").setLabel("Category Channel ID (right-click → Copy ID)").setStyle(TextInputStyle.Short).setMaxLength(40).setRequired(true),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("greeting").setLabel("Greeting message inside ticket").setStyle(TextInputStyle.Paragraph).setMaxLength(1500).setRequired(false).setValue(`Thanks for reaching out — a staff member will be with you shortly.`),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "select_option" && interaction.isStringSelectMenu()) {
      const optionId = Number(interaction.values[0]);
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "manage_forms") {
      const options = await db
        .select()
        .from(ticketPanelOptions)
        .where(eq(ticketPanelOptions.panelId, panelId))
        .orderBy(asc(ticketPanelOptions.position));
      if (options.length === 0) {
        await (interaction as ButtonInteraction).reply({
          embeds: [errorEmbed("No Ticket Options", "Add at least one ticket option before managing forms.")],
          ephemeral: true,
        });
        return;
      }
      if (options.length === 1) {
        await renderFormEditor(interaction as ButtonInteraction, options[0]!.id);
        return;
      }
      const lines = options
        .map((o, i) => `**${i + 1}.** ${o.emoji ?? ""} ${o.label} — \`${o.formQuestions.length}\` question${o.formQuestions.length === 1 ? "" : "s"}`)
        .join("\n");
      const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId("panel", "pick_form_option", String(panelId)))
        .setPlaceholder("Pick a ticket option to manage forms for…")
        .addOptions(
          options.map((o) => ({
            label: o.label.slice(0, 100),
            value: String(o.id),
            description: `${o.formQuestions.length} question${o.formQuestions.length === 1 ? "" : "s"}`,
            emoji: o.emoji ?? undefined,
          })),
        );
      const back = new ButtonBuilder()
        .setCustomId(encodeId("panel", "back_panel", String(panelId)))
        .setLabel("Back to Panel")
        .setEmoji(EMOJI.back)
        .setStyle(ButtonStyle.Secondary);
      await (interaction as ButtonInteraction).update({
        embeds: [
          brandedEmbed({
            kind: "info",
            title: `${EMOJI.question} Forms — Pick a Ticket Option`,
            description: [
              "Each ticket option (Support, Buy, Sell, etc.) has its own form. When a user clicks the button, the matching form pops up before the ticket is created.",
              "",
              lines,
            ].join("\n"),
          }),
        ],
        components: [
          new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
          new ActionRowBuilder<ButtonBuilder>().addComponents(back),
        ],
      });
      return;
    }
    if (action === "pick_form_option" && interaction.isStringSelectMenu()) {
      const optionId = Number(interaction.values[0]);
      await renderFormEditor(interaction, optionId);
      return;
    }
    if (action === "back_panel") {
      await openPanelEditor(interaction as ButtonInteraction, panelId);
      return;
    }
  }

  if (namespace === "opt") {
    const optionId = Number(args[0]);
    if (action === "back") {
      const panelId = Number(args[0]);
      await openPanelEditor(interaction as ButtonInteraction, panelId);
      return;
    }
    if (action === "delete") {
      const panelId = Number(args[1]);
      await db.delete(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId));
      await openPanelEditor(interaction as ButtonInteraction, panelId);
      return;
    }
    if (action === "edit_button") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const modal = new ModalBuilder()
        .setCustomId(encodeId("opt", "modal_button", String(optionId)))
        .setTitle("Edit Ticket Button")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("label").setLabel("Label").setStyle(TextInputStyle.Short).setMaxLength(80).setRequired(true).setValue(option.label),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("emoji").setLabel("Emoji").setStyle(TextInputStyle.Short).setRequired(false).setValue(option.emoji ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("style").setLabel("Style").setStyle(TextInputStyle.Short).setRequired(true).setValue(option.style),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("description").setLabel("Description (shown in dropdown layout)").setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(false).setValue(option.description ?? ""),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "edit_embed") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const cfg = option.ticketEmbed;
      const modal = new ModalBuilder()
        .setCustomId(encodeId("opt", "modal_embed", String(optionId)))
        .setTitle("Edit Ticket Embed")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("title").setLabel("Title").setStyle(TextInputStyle.Short).setMaxLength(256).setRequired(false).setValue(cfg.title ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("description").setLabel("Description").setStyle(TextInputStyle.Paragraph).setMaxLength(4000).setRequired(false).setValue(cfg.description ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("banner").setLabel("Banner URL").setStyle(TextInputStyle.Short).setRequired(false).setValue(cfg.bannerUrl ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("color").setLabel("Color hex").setStyle(TextInputStyle.Short).setRequired(false).setValue(cfg.color ? "#" + cfg.color.toString(16).padStart(6, "0") : ""),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "edit_messages") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const modal = new ModalBuilder()
        .setCustomId(encodeId("opt", "modal_messages", String(optionId)))
        .setTitle("Greeting & Inside Buttons")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("greeting").setLabel("Greeting message").setStyle(TextInputStyle.Paragraph).setMaxLength(1500).setRequired(false).setValue(option.openingMessage ?? ""),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("close_label").setLabel("Close button label").setStyle(TextInputStyle.Short).setRequired(true).setValue(option.closeButtonLabel),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("close_emoji").setLabel("Close button emoji").setStyle(TextInputStyle.Short).setRequired(false).setValue(option.closeButtonEmoji ?? EMOJI.close),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("claim_label").setLabel("Claim button label").setStyle(TextInputStyle.Short).setRequired(true).setValue(option.claimButtonLabel),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("claim_emoji").setLabel("Claim button emoji").setStyle(TextInputStyle.Short).setRequired(false).setValue(option.claimButtonEmoji ?? EMOJI.claim),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "set_category") {
      const select = new ChannelSelectMenuBuilder()
        .setCustomId(encodeId("opt", "category_select", String(optionId)))
        .setChannelTypes(ChannelType.GuildCategory)
        .setPlaceholder("Pick a category")
        .setMinValues(1)
        .setMaxValues(1);
      await (interaction as ButtonInteraction).update({
        embeds: [brandedEmbed({ kind: "info", title: "📁 Set Category", description: "Pick the parent category where ticket channels will be created." })],
        components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select)],
      });
      return;
    }
    if (action === "category_select" && interaction.isChannelSelectMenu()) {
      const cat = interaction.values[0]!;
      await db.update(ticketPanelOptions).set({ categoryId: cat }).where(eq(ticketPanelOptions.id, optionId));
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "set_roles") {
      const select = new RoleSelectMenuBuilder()
        .setCustomId(encodeId("opt", "roles_select", String(optionId)))
        .setPlaceholder("Pick staff roles")
        .setMinValues(0)
        .setMaxValues(10);
      await (interaction as ButtonInteraction).update({
        embeds: [brandedEmbed({ kind: "info", title: "🛡️ Staff Roles", description: "These roles will be added to ticket channels and granted moderation buttons." })],
        components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select)],
      });
      return;
    }
    if (action === "roles_select" && interaction.isRoleSelectMenu()) {
      await db.update(ticketPanelOptions).set({ staffRoleIds: interaction.values as string[] }).where(eq(ticketPanelOptions.id, optionId));
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "form") {
      await renderFormEditor(interaction as ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction, optionId);
      return;
    }
    if (action === "form_remove" && interaction.isStringSelectMenu()) {
      const removeId = interaction.values[0]!;
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const next = option.formQuestions.filter((q) => q.id !== removeId);
      await db.update(ticketPanelOptions).set({ formQuestions: next }).where(eq(ticketPanelOptions.id, optionId));
      await renderFormEditor(interaction, optionId);
      return;
    }
    if (action === "back_option") {
      await openOptionEditor(interaction as ButtonInteraction, optionId);
      return;
    }
    if (action === "form_add") {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("opt", "modal_form_add", String(optionId)))
        .setTitle("Add Form Question")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("label").setLabel("Question label").setStyle(TextInputStyle.Short).setMaxLength(45).setRequired(true),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("placeholder").setLabel("Placeholder").setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(false),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("style").setLabel("short or paragraph").setStyle(TextInputStyle.Short).setRequired(true).setValue("short"),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("required").setLabel("required (yes/no)").setStyle(TextInputStyle.Short).setRequired(true).setValue("yes"),
          ),
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder().setCustomId("max_length").setLabel("Max length (optional, 1-1000)").setStyle(TextInputStyle.Short).setRequired(false),
          ),
        );
      await (interaction as ButtonInteraction).showModal(modal);
      return;
    }
    if (action === "form_clear") {
      await db.update(ticketPanelOptions).set({ formQuestions: [] }).where(eq(ticketPanelOptions.id, optionId));
      await renderFormEditor(interaction as ButtonInteraction, optionId);
      return;
    }
  }
}

export async function handlePanelModal(interaction: ModalSubmitInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const { namespace, action, args } = decodeId(interaction.customId);

  if (namespace === "panel") {
    const panelId = Number(args[0]);
    if (action === "modal_basics") {
      const [panel] = await db.select().from(ticketPanels).where(eq(ticketPanels.id, panelId)).limit(1);
      if (!panel) return;
      const cfg = panel.embed;
      cfg.title = interaction.fields.getTextInputValue("title").trim() || null;
      cfg.description = interaction.fields.getTextInputValue("description").trim() || null;
      await db.update(ticketPanels).set({ embed: cfg, updatedAt: new Date() }).where(eq(ticketPanels.id, panelId));
      await openPanelEditor(interaction, panelId);
      return;
    }
    if (action === "modal_visuals") {
      const [panel] = await db.select().from(ticketPanels).where(eq(ticketPanels.id, panelId)).limit(1);
      if (!panel) return;
      const cfg = panel.embed;
      cfg.bannerUrl = interaction.fields.getTextInputValue("banner").trim() || null;
      cfg.thumbnailUrl = interaction.fields.getTextInputValue("thumb").trim() || null;
      const c = parseColor(interaction.fields.getTextInputValue("color"));
      if (c !== undefined) cfg.color = c;
      await db.update(ticketPanels).set({ embed: cfg, updatedAt: new Date() }).where(eq(ticketPanels.id, panelId));
      await openPanelEditor(interaction, panelId);
      return;
    }
    if (action === "modal_rename") {
      const name = interaction.fields.getTextInputValue("name").trim();
      await db.update(ticketPanels).set({ name, updatedAt: new Date() }).where(eq(ticketPanels.id, panelId));
      await openPanelEditor(interaction, panelId);
      return;
    }
    if (action === "modal_add_option") {
      const label = interaction.fields.getTextInputValue("label").trim();
      const emoji = interaction.fields.getTextInputValue("emoji").trim() || null;
      const styleRaw = interaction.fields.getTextInputValue("style").trim().toLowerCase();
      const validStyles: TicketButtonStyle[] = ["primary", "secondary", "success", "danger"];
      if (!validStyles.includes(styleRaw as TicketButtonStyle)) {
        await interaction.reply({ embeds: [errorEmbed("Invalid Style", "Use primary, secondary, success or danger.")], ephemeral: true });
        return;
      }
      const categoryId = interaction.fields.getTextInputValue("category_id").trim();
      const cat = interaction.guild.channels.cache.get(categoryId);
      if (!cat || cat.type !== ChannelType.GuildCategory) {
        await interaction.reply({ embeds: [errorEmbed("Invalid Category", "That ID isn't a category in this server.")], ephemeral: true });
        return;
      }
      const greeting = interaction.fields.getTextInputValue("greeting").trim() || null;
      const positions = await db
        .select()
        .from(ticketPanelOptions)
        .where(eq(ticketPanelOptions.panelId, panelId));
      await db.insert(ticketPanelOptions).values({
        panelId,
        position: positions.length,
        label,
        emoji,
        style: styleRaw as TicketButtonStyle,
        categoryId,
        ticketEmbed: {
          title: `${BRAND.name} Ticket — ${label}`,
          description: greeting ?? `Hello {user}, a staff member will be with you shortly.`,
          color: BRAND.primary,
          bannerUrl: BRAND.defaultBanner,
          footerText: BRAND.footerText,
          footerIconUrl: BRAND.footerIcon,
          timestamp: true,
        },
        openingMessage: greeting,
      });
      await openPanelEditor(interaction, panelId);
      return;
    }
  }

  if (namespace === "opt") {
    const optionId = Number(args[0]);
    if (action === "modal_button") {
      const label = interaction.fields.getTextInputValue("label").trim();
      const emoji = interaction.fields.getTextInputValue("emoji").trim() || null;
      const styleRaw = interaction.fields.getTextInputValue("style").trim().toLowerCase();
      const description = interaction.fields.getTextInputValue("description").trim() || null;
      const validStyles: TicketButtonStyle[] = ["primary", "secondary", "success", "danger"];
      if (!validStyles.includes(styleRaw as TicketButtonStyle)) {
        await interaction.reply({ embeds: [errorEmbed("Invalid Style", "Use primary, secondary, success or danger.")], ephemeral: true });
        return;
      }
      await db
        .update(ticketPanelOptions)
        .set({ label, emoji, style: styleRaw as TicketButtonStyle, description })
        .where(eq(ticketPanelOptions.id, optionId));
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "modal_embed") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const cfg = option.ticketEmbed;
      cfg.title = interaction.fields.getTextInputValue("title").trim() || null;
      cfg.description = interaction.fields.getTextInputValue("description").trim() || null;
      cfg.bannerUrl = interaction.fields.getTextInputValue("banner").trim() || null;
      const c = parseColor(interaction.fields.getTextInputValue("color"));
      if (c !== undefined) cfg.color = c;
      await db.update(ticketPanelOptions).set({ ticketEmbed: cfg }).where(eq(ticketPanelOptions.id, optionId));
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "modal_messages") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const greeting = interaction.fields.getTextInputValue("greeting").trim() || null;
      const close_label = interaction.fields.getTextInputValue("close_label").trim();
      const close_emoji = interaction.fields.getTextInputValue("close_emoji").trim() || null;
      const claim_label = interaction.fields.getTextInputValue("claim_label").trim();
      const claim_emoji = interaction.fields.getTextInputValue("claim_emoji").trim() || null;
      await db
        .update(ticketPanelOptions)
        .set({
          openingMessage: greeting,
          closeButtonLabel: close_label,
          closeButtonEmoji: close_emoji,
          claimButtonLabel: claim_label,
          claimButtonEmoji: claim_emoji,
        })
        .where(eq(ticketPanelOptions.id, optionId));
      await openOptionEditor(interaction, optionId);
      return;
    }
    if (action === "modal_form_add") {
      const [option] = await db.select().from(ticketPanelOptions).where(eq(ticketPanelOptions.id, optionId)).limit(1);
      if (!option) return;
      const label = interaction.fields.getTextInputValue("label").trim();
      const placeholder = interaction.fields.getTextInputValue("placeholder").trim() || undefined;
      const style = interaction.fields.getTextInputValue("style").trim().toLowerCase();
      const required = /^(y|yes|true|1)$/i.test(interaction.fields.getTextInputValue("required").trim());
      const max = parseInt(interaction.fields.getTextInputValue("max_length").trim(), 10);
      if (!["short", "paragraph"].includes(style)) {
        await interaction.reply({ embeds: [errorEmbed("Invalid Style", "Use short or paragraph.")], ephemeral: true });
        return;
      }
      const q: TicketFormQuestion = {
        id: randomUUID(),
        label,
        style: style as "short" | "paragraph",
        required,
        placeholder,
        maxLength: Number.isFinite(max) ? Math.min(Math.max(max, 1), 1000) : undefined,
      };
      const next = [...option.formQuestions, q];
      await db.update(ticketPanelOptions).set({ formQuestions: next }).where(eq(ticketPanelOptions.id, optionId));
      await renderFormEditor(interaction, optionId);
      return;
    }
  }
}
