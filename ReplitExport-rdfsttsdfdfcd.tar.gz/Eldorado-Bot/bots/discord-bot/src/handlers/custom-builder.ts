import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
} from "discord.js";
import { db, customCommands, type CustomCommandAction, type CustomButton, type EmbedConfig } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";
import { randomUUID } from "node:crypto";

type Draft = { name: string; action: CustomCommandAction };
const drafts = new Map<string, Draft>();

export function setCustomDraft(userId: string, draft: Draft): void {
  drafts.set(userId, draft);
}
export function getCustomDraft(userId: string): Draft | undefined {
  return drafts.get(userId);
}

function parseColor(input: string | null): number | undefined {
  if (!input) return undefined;
  const t = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(t)) return undefined;
  return parseInt(t, 16);
}

function buttonStyleFromString(s: string): ButtonStyle {
  switch (s) {
    case "primary":
      return ButtonStyle.Primary;
    case "secondary":
      return ButtonStyle.Secondary;
    case "success":
      return ButtonStyle.Success;
    case "danger":
      return ButtonStyle.Danger;
    case "link":
      return ButtonStyle.Link;
    default:
      return ButtonStyle.Secondary;
  }
}

function buildEditorComponents(name: string, action: CustomCommandAction): ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] {
  const select = new StringSelectMenuBuilder()
    .setCustomId(encodeId("custom", "type"))
    .setPlaceholder("Action type")
    .addOptions(
      { label: "Send Embed", value: "embed", emoji: EMOJI.edit, default: action.type === "embed" },
      { label: "Send Plain Message", value: "message", emoji: "💬", default: action.type === "message" },
      { label: "Redirect to URL", value: "url", emoji: EMOJI.arrow, default: action.type === "url" },
      { label: "Interactive Buttons", value: "buttons", emoji: "🔘", default: action.type === "buttons" },
    );
  const editRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("custom", "edit_payload"))
      .setLabel("Edit Content")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("custom", "manage_buttons"))
      .setLabel("Manage Buttons")
      .setEmoji("🔘")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(action.type !== "buttons"),
    new ButtonBuilder()
      .setCustomId(encodeId("custom", "preview"))
      .setLabel("Preview")
      .setEmoji(EMOJI.preview)
      .setStyle(ButtonStyle.Secondary),
  );
  const saveRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("custom", "save"))
      .setLabel("Save")
      .setEmoji(EMOJI.save)
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(encodeId("custom", "cancel"))
      .setLabel("Cancel")
      .setEmoji(EMOJI.cancel)
      .setStyle(ButtonStyle.Danger),
  );
  return [
    new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
    editRow,
    saveRow,
  ];
}

async function refreshDraft(interaction: ButtonInteraction | ModalSubmitInteraction | StringSelectMenuInteraction): Promise<void> {
  const draft = drafts.get(interaction.user.id);
  if (!draft) return;
  const payload = {
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.diamond} Custom Command Builder — \`${draft.name}\``,
        description: `**Type:** \`${draft.action.type}\`\n\nUse the buttons to edit, then **Save**.`,
      }),
    ],
    components: buildEditorComponents(draft.name, draft.action),
  };
  if (interaction.deferred || interaction.replied) await interaction.editReply(payload);
  else await (interaction as unknown as { update: (p: typeof payload) => Promise<unknown> }).update(payload);
}

export async function handleCustomSelect(interaction: StringSelectMenuInteraction): Promise<void> {
  const draft = drafts.get(interaction.user.id);
  if (!draft) {
    await interaction.reply({ embeds: [errorEmbed("Expired", "Open the builder again with `/custom command create`.")], ephemeral: true });
    return;
  }
  const newType = interaction.values[0]! as "embed" | "message" | "url" | "buttons";
  if (draft.action.type === newType) {
    await refreshDraft(interaction);
    return;
  }
  if (newType === "embed") {
    draft.action = { type: "embed", embed: { title: "Untitled", description: "Edit me.", color: BRAND.primary, bannerUrl: BRAND.defaultBanner, footerText: BRAND.footerText, footerIconUrl: BRAND.footerIcon, timestamp: true } };
  } else if (newType === "message") {
    draft.action = { type: "message", content: "Hello!" };
  } else if (newType === "url") {
    draft.action = { type: "url", url: "https://eldorado.gg" };
  } else {
    draft.action = { type: "buttons", content: "Choose an option:", buttons: [] };
  }
  drafts.set(interaction.user.id, draft);
  await refreshDraft(interaction);
}

export async function handleCustomButton(interaction: ButtonInteraction): Promise<void> {
  const { action: btn, args } = decodeId(interaction.customId);
  const draft = drafts.get(interaction.user.id);
  if (!draft) {
    await interaction.reply({ embeds: [errorEmbed("Expired", "Open the builder again.")], ephemeral: true });
    return;
  }

  if (btn === "edit_payload") {
    if (draft.action.type === "message") {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("custom", "modal_message"))
        .setTitle("Edit Message")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder()
              .setCustomId("content")
              .setLabel("Message content")
              .setStyle(TextInputStyle.Paragraph)
              .setMaxLength(2000)
              .setRequired(true)
              .setValue(draft.action.content),
          ),
        );
      await interaction.showModal(modal);
      return;
    }
    if (draft.action.type === "url") {
      const modal = new ModalBuilder()
        .setCustomId(encodeId("custom", "modal_url"))
        .setTitle("Edit URL")
        .addComponents(
          new ActionRowBuilder<TextInputBuilder>().addComponents(
            new TextInputBuilder()
              .setCustomId("url")
              .setLabel("Destination URL")
              .setStyle(TextInputStyle.Short)
              .setMaxLength(500)
              .setRequired(true)
              .setValue(draft.action.url),
          ),
        );
      await interaction.showModal(modal);
      return;
    }
    // embed and buttons share embed editor
    const embed: EmbedConfig | undefined =
      draft.action.type === "embed" ? draft.action.embed : draft.action.type === "buttons" ? draft.action.embed ?? undefined : undefined;
    const modal = new ModalBuilder()
      .setCustomId(encodeId("custom", "modal_embed"))
      .setTitle("Edit Embed")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("title")
            .setLabel("Title")
            .setStyle(TextInputStyle.Short)
            .setMaxLength(256)
            .setRequired(false)
            .setValue(embed?.title ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("Description")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(4000)
            .setRequired(false)
            .setValue(embed?.description ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("color")
            .setLabel("Color hex")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(embed?.color ? "#" + embed.color.toString(16).padStart(6, "0") : ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("banner")
            .setLabel("Banner / Image URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(embed?.bannerUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("thumb")
            .setLabel("Thumbnail URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(embed?.thumbnailUrl ?? ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (btn === "manage_buttons") {
    if (draft.action.type !== "buttons") return;
    const action = draft.action;
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "btn_add"))
        .setLabel("Add Button")
        .setEmoji(EMOJI.add)
        .setStyle(ButtonStyle.Primary)
        .setDisabled(action.buttons.length >= 5),
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "btn_clear"))
        .setLabel("Clear All Buttons")
        .setEmoji(EMOJI.delete)
        .setStyle(ButtonStyle.Danger)
        .setDisabled(action.buttons.length === 0),
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "back"))
        .setLabel("Back")
        .setEmoji(EMOJI.back)
        .setStyle(ButtonStyle.Secondary),
    );
    const list = action.buttons.length
      ? action.buttons.map((b, i) => `**${i + 1}.** ${b.emoji ?? ""} ${b.label} — \`${b.style}\`${b.url ? ` → ${b.url}` : b.responseContent ? ` → text` : ""}`).join("\n")
      : "_No buttons yet._";
    await interaction.update({
      embeds: [brandedEmbed({ kind: "info", title: "🔘 Manage Buttons", description: list })],
      components: [row],
    });
    return;
  }

  if (btn === "btn_add") {
    if (draft.action.type !== "buttons") return;
    const modal = new ModalBuilder()
      .setCustomId(encodeId("custom", "modal_add_button"))
      .setTitle("Add Button")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("label").setLabel("Label").setStyle(TextInputStyle.Short).setMaxLength(80).setRequired(true),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (optional)").setStyle(TextInputStyle.Short).setRequired(false),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("style")
            .setLabel("Style: primary | secondary | success | danger | link")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setValue("primary"),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("url")
            .setLabel("Link URL (only if style=link)")
            .setStyle(TextInputStyle.Short)
            .setRequired(false),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("response")
            .setLabel("Reply text when clicked (non-link)")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(1500)
            .setRequired(false),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (btn === "btn_clear") {
    if (draft.action.type !== "buttons") return;
    draft.action.buttons = [];
    drafts.set(interaction.user.id, draft);
    await refreshDraft(interaction);
    return;
  }

  if (btn === "back") {
    await refreshDraft(interaction);
    return;
  }

  if (btn === "preview") {
    const action = draft.action;
    if (action.type === "message") {
      await interaction.reply({ content: action.content, ephemeral: true });
    } else if (action.type === "url") {
      await interaction.reply({
        embeds: [brandedEmbed({ kind: "info", title: "🔗 URL Preview", description: action.url })],
        ephemeral: true,
      });
    } else if (action.type === "embed") {
      await interaction.reply({ embeds: [renderEmbedConfig(action.embed)], ephemeral: true });
    } else if (action.type === "buttons") {
      const row = new ActionRowBuilder<ButtonBuilder>();
      for (const b of action.buttons) {
        const btnB = new ButtonBuilder().setLabel(b.label).setStyle(buttonStyleFromString(b.style));
        if (b.emoji) btnB.setEmoji(b.emoji);
        if (b.style === "link" && b.url) btnB.setURL(b.url);
        else btnB.setCustomId(encodeId("ccbtn", b.id));
        row.addComponents(btnB);
      }
      await interaction.reply({
        content: action.content || undefined,
        embeds: action.embed ? [renderEmbedConfig(action.embed)] : [],
        components: action.buttons.length ? [row] : [],
        ephemeral: true,
      });
    }
    return;
  }

  if (btn === "save") {
    const existing = await db
      .select()
      .from(customCommands)
      .where(and(eq(customCommands.guildId, interaction.guildId!), eq(customCommands.name, draft.name)))
      .limit(1);
    if (existing[0]) {
      await db
        .update(customCommands)
        .set({ action: draft.action, updatedAt: new Date() })
        .where(eq(customCommands.id, existing[0].id));
    } else {
      await db.insert(customCommands).values({
        guildId: interaction.guildId!,
        name: draft.name,
        action: draft.action,
        createdBy: interaction.user.id,
      });
    }
    drafts.delete(interaction.user.id);
    await interaction.update({
      embeds: [successEmbed("Command Saved", `\`${draft.name}\` is live. Try it with any prefix.`)],
      components: [],
    });
    return;
  }

  if (btn === "cancel") {
    drafts.delete(interaction.user.id);
    await interaction.update({
      embeds: [brandedEmbed({ kind: "neutral", title: `${EMOJI.cancel} Builder Closed` })],
      components: [],
    });
    return;
  }
}

export async function handleCustomModal(interaction: ModalSubmitInteraction): Promise<void> {
  const { action } = decodeId(interaction.customId);
  const draft = drafts.get(interaction.user.id);
  if (!draft) {
    await interaction.reply({ embeds: [errorEmbed("Expired", "Open the builder again.")], ephemeral: true });
    return;
  }

  if (action === "modal_message" && draft.action.type === "message") {
    draft.action.content = interaction.fields.getTextInputValue("content");
  } else if (action === "modal_url" && draft.action.type === "url") {
    const url = interaction.fields.getTextInputValue("url").trim();
    if (!/^https?:\/\//.test(url)) {
      await interaction.reply({ embeds: [errorEmbed("Invalid URL", "Must start with http:// or https://.")], ephemeral: true });
      return;
    }
    draft.action.url = url;
  } else if (action === "modal_embed") {
    const embed: EmbedConfig = {
      title: interaction.fields.getTextInputValue("title").trim() || null,
      description: interaction.fields.getTextInputValue("description").trim() || null,
      bannerUrl: interaction.fields.getTextInputValue("banner").trim() || null,
      thumbnailUrl: interaction.fields.getTextInputValue("thumb").trim() || null,
      color: parseColor(interaction.fields.getTextInputValue("color")) ?? BRAND.primary,
      footerText: BRAND.footerText,
      footerIconUrl: BRAND.footerIcon,
      timestamp: true,
    };
    if (draft.action.type === "embed") draft.action.embed = embed;
    else if (draft.action.type === "buttons") draft.action.embed = embed;
  } else if (action === "modal_add_button" && draft.action.type === "buttons") {
    const label = interaction.fields.getTextInputValue("label").trim();
    const emoji = interaction.fields.getTextInputValue("emoji").trim() || undefined;
    const style = interaction.fields.getTextInputValue("style").trim().toLowerCase();
    const url = interaction.fields.getTextInputValue("url").trim() || undefined;
    const response = interaction.fields.getTextInputValue("response").trim() || undefined;
    const validStyles = ["primary", "secondary", "success", "danger", "link"];
    if (!validStyles.includes(style)) {
      await interaction.reply({ embeds: [errorEmbed("Invalid Style", "Must be one of: primary, secondary, success, danger, link.")], ephemeral: true });
      return;
    }
    if (style === "link" && !url) {
      await interaction.reply({ embeds: [errorEmbed("Missing URL", "Link buttons require a URL.")], ephemeral: true });
      return;
    }
    const newButton: CustomButton = {
      id: randomUUID(),
      label,
      emoji,
      style: style as CustomButton["style"],
      url,
      responseContent: response,
    };
    draft.action.buttons.push(newButton);
  }

  drafts.set(interaction.user.id, draft);
  await refreshDraft(interaction);
}

/** Handle clicks on the saved buttons of a custom-button command. */
export async function handleCustomButtonClick(interaction: ButtonInteraction, buttonId: string): Promise<void> {
  if (!interaction.guildId) return;
  // Find the originating message's custom command by scanning the message's components and matching IDs
  const components = (interaction.message.components ?? []) as unknown as Array<{ components: Array<{ customId?: string }> }>;
  const matchedRowComponent = components
    .flatMap((row) => row.components)
    .find((c) => c.customId === interaction.customId);
  if (!matchedRowComponent) {
    await interaction.reply({ embeds: [errorEmbed("Unknown Button", "This button is no longer linked to a command.")], ephemeral: true });
    return;
  }
  // We need the response content. Look it up by scanning all custom commands of this guild and matching the button id.
  const all = await db.select().from(customCommands).where(eq(customCommands.guildId, interaction.guildId));
  for (const cmd of all) {
    if (cmd.action.type !== "buttons") continue;
    const found = cmd.action.buttons.find((b) => b.id === buttonId);
    if (found) {
      if (found.responseContent) {
        await interaction.reply({ content: found.responseContent, ephemeral: true });
      } else if (found.responseEmbed) {
        await interaction.reply({ embeds: [renderEmbedConfig(found.responseEmbed)], ephemeral: true });
      } else {
        await interaction.reply({ embeds: [brandedEmbed({ kind: "info", title: "Button clicked", description: `_${found.label}_` })], ephemeral: true });
      }
      return;
    }
  }
  await interaction.reply({ embeds: [errorEmbed("Unknown Button", "Couldn't resolve this button.")], ephemeral: true });
}

export function buttonStyleEnum(s: string): ButtonStyle {
  return buttonStyleFromString(s);
}
