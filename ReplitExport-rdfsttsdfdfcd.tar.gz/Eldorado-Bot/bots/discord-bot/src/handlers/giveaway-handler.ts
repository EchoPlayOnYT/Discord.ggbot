import { type ButtonInteraction, type Client, type TextChannel } from "discord.js";
import { db, giveaways } from "@workspace/db";
import { eq, and, lte } from "drizzle-orm";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { pickRandom } from "../commands/giveaway.js";
import { logger } from "../logger.js";

export async function handleGiveawayButton(interaction: ButtonInteraction): Promise<unknown> {
  if (!interaction.guildId) return;
  const [g] = await db
    .select()
    .from(giveaways)
    .where(and(eq(giveaways.guildId, interaction.guildId), eq(giveaways.messageId, interaction.message.id)))
    .limit(1);
  if (!g) return interaction.reply({ embeds: [errorEmbed("Not Found", "This giveaway is no longer tracked.")], ephemeral: true });
  if (g.ended) return interaction.reply({ embeds: [errorEmbed("Ended", "This giveaway has already ended.")], ephemeral: true });
  if (g.entrants.includes(interaction.user.id)) {
    const next = g.entrants.filter((id) => id !== interaction.user.id);
    await db.update(giveaways).set({ entrants: next }).where(eq(giveaways.id, g.id));
    return interaction.reply({ embeds: [successEmbed("Entry Removed", "You have left the giveaway.")], ephemeral: true });
  }
  const next = [...g.entrants, interaction.user.id];
  await db.update(giveaways).set({ entrants: next }).where(eq(giveaways.id, g.id));
  return interaction.reply({
    embeds: [successEmbed("Entered!", `You're in. Total entries: **${next.length}**.`)],
    ephemeral: true,
  });
}

export function startGiveawayLoop(client: Client): void {
  setInterval(async () => {
    try {
      const due = await db
        .select()
        .from(giveaways)
        .where(and(eq(giveaways.ended, false), lte(giveaways.endsAt, new Date())));
      for (const g of due) {
        await endGiveaway(client, g);
      }
    } catch (err) {
      logger.error({ err }, "giveaway loop error");
    }
  }, 15_000);
}

async function endGiveaway(client: Client, g: typeof giveaways.$inferSelect): Promise<void> {
  await db.update(giveaways).set({ ended: true }).where(eq(giveaways.id, g.id));
  const guild = client.guilds.cache.get(g.guildId);
  if (!guild) return;
  const channel = guild.channels.cache.get(g.channelId) as TextChannel | undefined;
  if (!channel?.isTextBased()) return;
  const winners = pickRandom(g.entrants, g.winnersCount);
  await db.update(giveaways).set({ winners }).where(eq(giveaways.id, g.id));
  const winnerLine = winners.length ? winners.map((w) => `<@${w}>`).join(", ") : "_No valid entries — no winner._";
  const updatedEmbed = renderEmbedConfig({
    title: `${EMOJI.gift} ${g.prize} — Ended`,
    description: [
      g.description ? g.description + "\n" : "",
      `**Winners:** ${winnerLine}`,
      `**Total entries:** ${g.entrants.length}`,
      `**Hosted by:** <@${g.hostId}>`,
    ].join("\n"),
    color: BRAND.primary,
    bannerUrl: BRAND.defaultBanner,
    footerText: BRAND.footerText,
    footerIconUrl: BRAND.footerIcon,
    timestamp: true,
  });
  try {
    const msg = await channel.messages.fetch(g.messageId);
    await msg.edit({ embeds: [updatedEmbed], components: [] });
  } catch {
    // message gone
  }
  await channel.send({
    embeds: [
      brandedEmbed({
        kind: "success",
        title: `${EMOJI.gift} Giveaway Ended — ${g.prize}`,
        description: winners.length ? `Congrats ${winnerLine}! 🎉` : "Nobody entered the giveaway.",
      }),
    ],
  });
}
