import type { Message } from "discord.js";
import { db, levelXp, levelRoles } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { sql } from "drizzle-orm";
import { brandedEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { getGuildSettings } from "../utils/db-helpers.js";
import { levelFromXp } from "../utils/leveling.js";
import { logger } from "../logger.js";

const cooldowns = new Map<string, number>();
const COOLDOWN_MS = 60_000;

export async function handleMessageXp(message: Message): Promise<void> {
  if (!message.inGuild() || message.author.bot) return;
  const settings = await getGuildSettings(message.guildId);
  if (!settings.levelingEnabled) return;
  const key = `${message.guildId}:${message.author.id}`;
  const now = Date.now();
  const last = cooldowns.get(key) ?? 0;
  if (now - last < COOLDOWN_MS) return;
  cooldowns.set(key, now);

  const gain = 15 + Math.floor(Math.random() * 11); // 15-25
  const updated = await db
    .insert(levelXp)
    .values({ guildId: message.guildId, userId: message.author.id, xp: gain, lastMessageAt: new Date() })
    .onConflictDoUpdate({
      target: [levelXp.guildId, levelXp.userId],
      set: { xp: sql`${levelXp.xp} + ${gain}`, lastMessageAt: new Date() },
    })
    .returning();
  const row = updated[0]!;
  const newLevel = levelFromXp(row.xp);
  const oldLevel = levelFromXp(row.xp - gain);
  if (newLevel > oldLevel) {
    // Level-up announcement
    const channel = settings.levelUpChannelId
      ? message.guild.channels.cache.get(settings.levelUpChannelId)
      : message.channel;
    if (channel?.isTextBased() && "send" in channel) {
      try {
        await channel.send({
          embeds: [
            brandedEmbed({
              kind: "success",
              title: `${EMOJI.diamond} Level Up!`,
              description: `${message.author} reached **Level ${newLevel}**! 🎉`,
            }),
          ],
        });
      } catch (err) {
        logger.warn({ err }, "level-up message failed");
      }
    }
    // Role rewards
    try {
      const rewards = await db
        .select()
        .from(levelRoles)
        .where(and(eq(levelRoles.guildId, message.guildId)));
      const due = rewards.filter((r) => r.level <= newLevel);
      if (due.length && message.member) {
        const toAdd = due.map((r) => r.roleId).filter((id) => !message.member!.roles.cache.has(id));
        if (toAdd.length) await message.member.roles.add(toAdd, `Level ${newLevel} reward`);
      }
    } catch (err) {
      logger.warn({ err }, "level role reward failed");
    }
  }
}
