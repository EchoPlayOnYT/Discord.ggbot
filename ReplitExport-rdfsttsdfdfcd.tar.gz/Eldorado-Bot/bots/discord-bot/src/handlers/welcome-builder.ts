import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type ChannelSelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  type TextChannel,
} from "discord.js";
import type { EmbedConfig } from "@workspace/db";
import { brandedEmbed, renderEmbedConfig, errorEmbed, successEmbed, applyPlaceholders } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";
import { getGuildSettings, updateGuildSettings } from "../utils/db-helpers.js";

function parseColor(input: string | null): number | undefined {
  if (!input) return undefined;
  const t = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(t)) return undefined;
  return parseInt(t, 16);
}

async function refreshEditor(interaction: ButtonInteraction | ModalSubmitInteraction | ChannelSelectMenuInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const settings = await getGuildSettings(interaction.guildId);
  const cfg = settings.welcomeEmbed ?? {
    title: `Welcome to {server}!`,
    description: `Hey {user}, you're member **#{memberCount}**.`,
    color: BRAND.primary,
    bannerUrl: BRAND.defaultBanner,
  };
  const ctx = {
    user: interaction.user,
    userMention: interaction.user.toString(),
    userTag: interaction.user.tag,
    serverName: interaction.guild!.name,
    memberCount: interaction.guild!.memberCount,
  };
  const e = renderEmbedConfig(cfg);
  if (cfg.title) e.setTitle(applyPlaceholders(cfg.title, ctx));
  if (cfg.description) e.setDescription(applyPlaceholders(cfg.description, ctx));

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "edit_basics"))
      .setLabel("Edit Title & Description")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "edit_visuals"))
      .setLabel("Edit Visuals")
      .setEmoji(EMOJI.preview)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "edit_message"))
      .setLabel("Plain Message Above Embed")
      .setEmoji(EMOJI.edit)
      .setStyle(ButtonStyle.Secondary),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "set_channel"))
      .setLabel("Set Channel")
      .setEmoji("📺")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "toggle"))
      .setLabel(settings.welcomeEnabled ? "Disable" : "Enable")
      .setEmoji(settings.welcomeEnabled ? EMOJI.cancel : EMOJI.success)
      .setStyle(settings.welcomeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(encodeId("welcome", "test"))
      .setLabel("Send Test")
      .setEmoji(EMOJI.preview)
      .setStyle(ButtonStyle.Secondary),
  );

  const payload = {
    embeds: [
      brandedEmbed({
        kind: "info",
        title: `${EMOJI.sparkle} Welcome System Editor`,
        description: [
          `**Status:** ${settings.welcomeEnabled ? `${EMOJI.success} Enabled` : `${EMOJI.cancel} Disabled`}`,
          `**Channel:** ${settings.welcomeChannelId ? `<#${settings.welcomeChannelId}>` : "_not set_"}`,
          `**Auto-Roles:** ${settings.welcomeAutoRoleIds.length ? settings.welcomeAutoRoleIds.map((r) => `<@&${r}>`).join(" ") : "_none_"}`,
          ``,
          `Placeholders: \`{user}\` \`{user.tag}\` \`{user.name}\` \`{server}\` \`{memberCount}\``,
        ].join("\n"),
      }),
      e,
    ],
    components: [row, row2],
  };

  if (interaction.isModalSubmit() || interaction.isButton() || interaction.isChannelSelectMenu()) {
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(payload);
    } else {
      // ModalSubmitInteraction.update exists at runtime when triggered from a message component
      await (interaction as unknown as { update: (p: typeof payload) => Promise<unknown> }).update(payload);
    }
  }
}

export async function handleWelcomeButton(interaction: ButtonInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const { action } = decodeId(interaction.customId);
  const settings = await getGuildSettings(interaction.guildId);

  if (action === "edit_basics") {
    const cfg = settings.welcomeEmbed ?? {};
    const modal = new ModalBuilder()
      .setCustomId(encodeId("welcome", "modal_basics"))
      .setTitle("Welcome — Title & Description")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("title")
            .setLabel("Title")
            .setStyle(TextInputStyle.Short)
            .setMaxLength(256)
            .setRequired(false)
            .setValue(cfg.title ?? "Welcome to {server}!"),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("Description (placeholders supported)")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(4000)
            .setRequired(false)
            .setValue(cfg.description ?? "Hey {user}, you're member **#{memberCount}**."),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("color")
            .setLabel("Color (hex like #7c3aed)")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(cfg.color ? "#" + cfg.color.toString(16).padStart(6, "0") : ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "edit_visuals") {
    const cfg = settings.welcomeEmbed ?? {};
    const modal = new ModalBuilder()
      .setCustomId(encodeId("welcome", "modal_visuals"))
      .setTitle("Welcome — Visuals")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("banner")
            .setLabel("Banner / Image URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(cfg.bannerUrl ?? ""),
        ),
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("thumb")
            .setLabel("Thumbnail URL")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(cfg.thumbnailUrl ?? ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "edit_message") {
    const modal = new ModalBuilder()
      .setCustomId(encodeId("welcome", "modal_message"))
      .setTitle("Welcome — Plain Message")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("content")
            .setLabel("Plain message above the embed (optional)")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(2000)
            .setRequired(false)
            .setValue(settings.welcomeMessageContent ?? ""),
        ),
      );
    await interaction.showModal(modal);
    return;
  }

  if (action === "set_channel") {
    const select = new ChannelSelectMenuBuilder()
      .setCustomId(encodeId("welcome", "channel_select"))
      .setChannelTypes(ChannelType.GuildText)
      .setPlaceholder("Choose welcome channel")
      .setMaxValues(1)
      .setMinValues(1);
    await interaction.update({
      embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.preview} Pick a Welcome Channel` })],
      components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select)],
    });
    return;
  }

  if (action === "toggle") {
    await updateGuildSettings(interaction.guildId, { welcomeEnabled: !settings.welcomeEnabled });
    await refreshEditor(interaction);
    return;
  }

  if (action === "test") {
    if (!settings.welcomeChannelId || !settings.welcomeEnabled) {
      await interaction.reply({ embeds: [errorEmbed("Not Configured", "Set a channel and enable the system first.")], ephemeral: true });
      return;
    }
    const ch = interaction.guild.channels.cache.get(settings.welcomeChannelId) as TextChannel | undefined;
    if (!ch?.isTextBased()) {
      await interaction.reply({ embeds: [errorEmbed("Channel Missing", "The welcome channel is missing.")], ephemeral: true });
      return;
    }
    const cfg = settings.welcomeEmbed ?? {};
    const ctx = {
      user: interaction.user,
      userMention: interaction.user.toString(),
      userTag: interaction.user.tag,
      serverName: interaction.guild.name,
      memberCount: interaction.guild.memberCount,
    };
    const e = renderEmbedConfig(cfg);
    if (cfg.title) e.setTitle(applyPlaceholders(cfg.title, ctx));
    if (cfg.description) e.setDescription(applyPlaceholders(cfg.description, ctx));
    const content = settings.welcomeMessageContent ? applyPlaceholders(settings.welcomeMessageContent, ctx) : undefined;
    await ch.send({ content, embeds: [e] });
    await interaction.reply({ embeds: [successEmbed("Test Sent", `Posted in ${ch}.`)], ephemeral: true });
  }
}

export async function handleWelcomeChannelSelect(interaction: ChannelSelectMenuInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const id = interaction.values[0]!;
  await updateGuildSettings(interaction.guildId, { welcomeChannelId: id });
  await refreshEditor(interaction);
}

export async function handleWelcomeModal(interaction: ModalSubmitInteraction): Promise<void> {
  if (!interaction.inCachedGuild()) return;
  const { action } = decodeId(interaction.customId);
  const settings = await getGuildSettings(interaction.guildId);
  const cfg: EmbedConfig = settings.welcomeEmbed ?? {};

  if (action === "modal_basics") {
    cfg.title = interaction.fields.getTextInputValue("title").trim() || null;
    cfg.description = interaction.fields.getTextInputValue("description").trim() || null;
    const c = parseColor(interaction.fields.getTextInputValue("color"));
    if (c !== undefined) cfg.color = c;
    cfg.footerText = cfg.footerText ?? BRAND.footerText;
    cfg.footerIconUrl = cfg.footerIconUrl ?? BRAND.footerIcon;
    await updateGuildSettings(interaction.guildId, { welcomeEmbed: cfg });
  } else if (action === "modal_visuals") {
    cfg.bannerUrl = interaction.fields.getTextInputValue("banner").trim() || null;
    cfg.thumbnailUrl = interaction.fields.getTextInputValue("thumb").trim() || null;
    await updateGuildSettings(interaction.guildId, { welcomeEmbed: cfg });
  } else if (action === "modal_message") {
    const content = interaction.fields.getTextInputValue("content").trim();
    await updateGuildSettings(interaction.guildId, { welcomeMessageContent: content || null });
  }
  await refreshEditor(interaction);
}
