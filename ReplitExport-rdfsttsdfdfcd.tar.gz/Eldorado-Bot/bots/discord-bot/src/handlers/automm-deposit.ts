/**
 * Auto Middleman deposit lifecycle handler.
 *
 *   1. Buyer runs `/give automm` inside a ticket.
 *   2. Bot opens an ephemeral method picker (only enabled methods are listed).
 *   3. Buyer picks a method → bot opens an amount modal.
 *   4. On submit, the bot:
 *        - reads the configured wallet address for that method,
 *        - snapshots the current on-chain balance (initialBalance),
 *        - posts the configured branded embed publicly in the ticket with
 *          Confirm / Cancel buttons.
 *   5. The monitor service polls and notifies when funds arrive.
 *   6. Buyer or staff hit Confirm/Cancel — these only update DB state and
 *      send a notification. The bot does NOT release/move funds.
 */

import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type EmbedBuilder,
  type GuildMember,
  type TextChannel,
} from "discord.js";
import { eq, and } from "drizzle-orm";
import {
  db,
  autommConfig,
  autommAddresses,
  autommDeposits,
  tickets,
  type EmbedConfig,
} from "@workspace/db";
import { brandedEmbed, errorEmbed, infoEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { encodeId, decodeId } from "../utils/component-ids.js";
import {
  expireOpenDepositsForChannel,
  setDepositStatus,
} from "../services/automm-monitor.js";
import { safeGetBalance } from "../services/blockchain.js";
import { logger } from "../logger.js";

const METHOD_LABEL: Record<string, { label: string; emoji: string }> = {
  BTC: { label: "Bitcoin", emoji: "🟠" },
  LTC: { label: "Litecoin", emoji: "🪙" },
  ETH: { label: "Ethereum", emoji: "💠" },
  USDT: { label: "Tether (USDT)", emoji: "💵" },
  ROBUX: { label: "Robux (manual)", emoji: "🎮" },
  OTHER: { label: "Other (manual)", emoji: "❔" },
};

const AUTO_METHODS = new Set(["BTC", "LTC", "ETH", "USDT"]);

/** Reusable safety embed appended below the deposit embed. */
function safetyEmbed(): EmbedBuilder {
  return brandedEmbed({
    kind: "warning",
    title: `${EMOJI.warn} Safety Notice`,
    description:
      "• The bot **only watches** the deposit address — it cannot move, send, or release funds.\n" +
      "• A **human middleman** verifies the deposit and releases the goods.\n" +
      "• Never DM your private keys or seed phrase. Staff will never ask for them.",
  });
}

/** Substitute placeholders in a string. */
function substitute(
  template: string,
  ctx: { amount: string; method: string; address: string; network: string | null; buyer: string; ticket: string },
): string {
  return template
    .replaceAll("{amount}", ctx.amount)
    .replaceAll("{method}", ctx.method)
    .replaceAll("{address}", ctx.address)
    .replaceAll("{network}", ctx.network ?? "—")
    .replaceAll("{buyer}", ctx.buyer)
    .replaceAll("{ticket}", ctx.ticket);
}

/** Render a copy of the configured embed with placeholders substituted. */
export function renderDepositPreview(input: {
  embedConfig: EmbedConfig | null;
  contentTemplate: string | null;
  method: string;
  amount: string;
  address: string;
  network: string | null;
  buyerMention: string;
  ticketMention?: string;
}): { content: string | null; embed: EmbedConfig; safetyEmbed: EmbedBuilder } {
  const fallback: EmbedConfig = {
    title: `${EMOJI.diamond} Auto Middleman — Deposit`,
    description:
      "Hello {buyer}, please send **{amount} {method}** to the wallet below.\n\n" +
      "**Network:** {network}\n**Address:** `{address}`\n\n" +
      "The bot will detect the deposit automatically and notify everyone here.",
    color: 0x7c3aed,
  };
  const cfg = input.embedConfig ?? fallback;
  const ctx = {
    amount: input.amount,
    method: input.method,
    address: input.address,
    network: input.network,
    buyer: input.buyerMention,
    ticket: input.ticketMention ?? "this channel",
  };
  const sub = (s: string | null | undefined): string | null => (s ? substitute(s, ctx) : s ?? null);
  const embed: EmbedConfig = {
    ...cfg,
    title: sub(cfg.title) ?? cfg.title ?? null,
    description: sub(cfg.description) ?? cfg.description ?? null,
    footerText: sub(cfg.footerText) ?? cfg.footerText ?? null,
    authorName: sub(cfg.authorName) ?? cfg.authorName ?? null,
  };
  const content = input.contentTemplate ? substitute(input.contentTemplate, ctx) : null;
  return { content, embed, safetyEmbed: safetyEmbed() };
}

// ──────────────────────────────────────────────────────────────────────────
// Panel: post a public Auto Middleman panel with one button per enabled method
// ──────────────────────────────────────────────────────────────────────────

/** Build the message payload for `/automm panel send` and `/automm panel show`. */
export function buildAutommPanelMessage(
  cfg: typeof autommConfig.$inferSelect,
  enabledMethods: string[],
): {
  content?: string;
  embeds: EmbedBuilder[];
  components: ActionRowBuilder<ButtonBuilder>[];
} {
  const fallback: EmbedConfig = {
    title: `${EMOJI.diamond} Auto Middleman — Start a Deposit`,
    description:
      "Pick the payment method you want to use below. " +
      "You'll be asked to enter the deposit amount, then I'll post a secure deposit address in this channel.\n\n" +
      "**A human middleman releases the goods — the bot never moves funds.**",
    color: 0x7c3aed,
  };
  const embed = renderEmbedConfig(cfg.embed ?? fallback, "Deposit");
  const safety = safetyEmbed();

  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  let row = new ActionRowBuilder<ButtonBuilder>();
  for (const m of enabledMethods.slice(0, 25)) {
    if (row.components.length === 5) {
      rows.push(row);
      row = new ActionRowBuilder<ButtonBuilder>();
    }
    const meta = METHOD_LABEL[m] ?? { label: m, emoji: "💎" };
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("automm", "panel_method", m))
        .setLabel(meta.label)
        .setEmoji(meta.emoji)
        .setStyle(ButtonStyle.Primary),
    );
  }
  if (row.components.length) rows.push(row);

  const payload: { content?: string; embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] } = {
    embeds: [embed, safety],
    components: rows,
  };
  if (cfg.contentTemplate) payload.content = cfg.contentTemplate;
  return payload;
}

/** Open the amount modal directly when a user clicks a method button on a posted panel. */
async function handlePanelMethodClick(interaction: ButtonInteraction): Promise<unknown> {
  const { args } = decodeId(interaction.customId);
  const method = (args[0] ?? "").toUpperCase();
  if (!method) return;
  const modal = new ModalBuilder()
    .setCustomId(encodeId("automm", "deposit_modal", method))
    .setTitle(`Deposit — ${METHOD_LABEL[method]?.label ?? method}`)
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("amount")
          .setLabel(`Amount in ${method}`)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("e.g. 0.005"),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("note")
          .setLabel("Note (optional)")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(500),
      ),
    );
  return interaction.showModal(modal);
}

// ──────────────────────────────────────────────────────────────────────────
// Step 1: /give automm — open the method picker
// ──────────────────────────────────────────────────────────────────────────

export async function startAutommDeposit(interaction: ChatInputCommandInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const guildId = interaction.guildId;
  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    return interaction.reply({
      embeds: [errorEmbed("Wrong Channel", "Run `/give automm` inside a ticket text channel.")],
      ephemeral: true,
    });
  }

  // Ticket gating: must be a known ticket channel for this guild.
  const [ticket] = await db.select().from(tickets).where(eq(tickets.channelId, channel.id)).limit(1);
  if (!ticket || ticket.guildId !== guildId) {
    return interaction.reply({
      embeds: [
        errorEmbed(
          "Not a Ticket",
          "Auto Middleman can only be used inside a ticket. Open a ticket from the panel first.",
        ),
      ],
      ephemeral: true,
    });
  }

  const [cfg] = await db.select().from(autommConfig).where(eq(autommConfig.guildId, guildId)).limit(1);
  if (!cfg) {
    return interaction.reply({
      embeds: [errorEmbed("Not Configured", "An admin must run `/automm embed` and `/set address` first.")],
      ephemeral: true,
    });
  }
  const enabled = cfg.enabledMethods ?? [];
  const addresses = await db.select().from(autommAddresses).where(eq(autommAddresses.guildId, guildId));
  const available = enabled.filter((m) => addresses.some((a) => a.method === m && a.isActive));
  if (!available.length) {
    return interaction.reply({
      embeds: [
        errorEmbed(
          "No Payment Methods",
          "An admin needs to enable methods (`/automm methods`) and set wallet addresses (`/set address`).",
        ),
      ],
      ephemeral: true,
    });
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId(encodeId("automm", "method_pick"))
    .setPlaceholder("Select a payment method")
    .addOptions(
      available.map((m) => ({
        label: METHOD_LABEL[m]?.label ?? m,
        value: m,
        emoji: METHOD_LABEL[m]?.emoji ?? "💎",
      })),
    );
  return interaction.reply({
    embeds: [
      infoEmbed(
        "Auto Middleman",
        "Pick a payment method below. You'll be asked to enter the deposit amount next.",
      ),
    ],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
    ephemeral: true,
  });
}

// ──────────────────────────────────────────────────────────────────────────
// Step 2: method picked → open amount modal
// ──────────────────────────────────────────────────────────────────────────

async function handleMethodPick(interaction: StringSelectMenuInteraction): Promise<unknown> {
  const method = interaction.values[0]!;
  const modal = new ModalBuilder()
    .setCustomId(encodeId("automm", "deposit_modal", method))
    .setTitle(`Deposit — ${METHOD_LABEL[method]?.label ?? method}`)
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("amount")
          .setLabel(`Amount in ${method}`)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("e.g. 0.005"),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("note")
          .setLabel("Note (optional)")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(500),
      ),
    );
  return interaction.showModal(modal);
}

// ──────────────────────────────────────────────────────────────────────────
// Step 3: modal submitted → post the public deposit embed in the ticket
// ──────────────────────────────────────────────────────────────────────────

async function handleDepositModal(interaction: ModalSubmitInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const { args } = decodeId(interaction.customId);
  const method = (args[0] ?? "").toUpperCase();
  const amountRaw = interaction.fields.getTextInputValue("amount").trim();
  const note = interaction.fields.getTextInputValue("note").trim();
  const amount = Number(amountRaw);
  if (!amountRaw || !Number.isFinite(amount) || amount <= 0) {
    return interaction.reply({ embeds: [errorEmbed("Invalid Amount", "Enter a positive number.")], ephemeral: true });
  }

  const guildId = interaction.guildId;
  const channel = interaction.channel as TextChannel | null;
  if (!channel || channel.type !== ChannelType.GuildText) {
    return interaction.reply({ embeds: [errorEmbed("Wrong Channel", "Use this in a ticket channel.")], ephemeral: true });
  }

  const [cfg] = await db.select().from(autommConfig).where(eq(autommConfig.guildId, guildId)).limit(1);
  if (!cfg) {
    return interaction.reply({ embeds: [errorEmbed("Not Configured", "Auto Middleman is not configured for this server.")], ephemeral: true });
  }
  const [addr] = await db
    .select()
    .from(autommAddresses)
    .where(and(eq(autommAddresses.guildId, guildId), eq(autommAddresses.method, method)))
    .limit(1);
  if (!addr || !addr.isActive) {
    return interaction.reply({ embeds: [errorEmbed("Address Missing", `No active wallet for ${method}.`)], ephemeral: true });
  }

  // Cancel any older sessions in this channel before opening a new one.
  await expireOpenDepositsForChannel(channel.id);

  // Snapshot current balance for delta-based detection (auto methods only).
  let initialBalance: number | null = null;
  let autoMonitor = false;
  if (AUTO_METHODS.has(method) && cfg.monitorEnabled) {
    const snap = await safeGetBalance(method, addr.address);
    if (snap) {
      initialBalance = snap.balance;
      autoMonitor = true;
    }
  }

  // Insert deposit row first so the monitor can pick it up.
  const expiresAt = new Date(Date.now() + cfg.expireMinutes * 60_000);
  const [dep] = await db
    .insert(autommDeposits)
    .values({
      guildId,
      ticketChannelId: channel.id,
      buyerId: interaction.user.id,
      method,
      address: addr.address,
      network: addr.network ?? null,
      expectedAmount: String(amount),
      autoMonitor,
      initialBalance: initialBalance !== null ? String(initialBalance) : null,
      expiresAt,
    })
    .returning();
  if (!dep) {
    return interaction.reply({ embeds: [errorEmbed("DB Error", "Could not create the deposit row.")], ephemeral: true });
  }

  // Acknowledge the modal so we can proceed to send the public embed.
  await interaction.deferReply({ ephemeral: true });

  // Render embed with substitutions and post publicly.
  const previewed = renderDepositPreview({
    embedConfig: cfg.embed,
    contentTemplate: cfg.contentTemplate,
    method,
    amount: amountRaw,
    address: addr.address,
    network: addr.network ?? null,
    buyerMention: `<@${interaction.user.id}>`,
    ticketMention: `<#${channel.id}>`,
  });

  const noteEmbed = note
    ? brandedEmbed({ kind: "info", title: `${EMOJI.edit} Buyer Note`, description: note })
    : null;
  const embeds: EmbedBuilder[] = [renderEmbedConfig(previewed.embed, "Deposit"), previewed.safetyEmbed];
  if (noteEmbed) embeds.splice(1, 0, noteEmbed);

  const buttonRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "confirm", String(dep.id)))
      .setLabel("Confirm")
      .setEmoji(EMOJI.success)
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "cancel_dep", String(dep.id)))
      .setLabel("Cancel")
      .setEmoji(EMOJI.cancel)
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(encodeId("automm", "recheck", String(dep.id)))
      .setLabel("Re-check")
      .setEmoji(EMOJI.loading)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(!autoMonitor),
  );

  const sent = await channel.send({
    content: previewed.content || `<@${interaction.user.id}>`,
    embeds,
    components: [buttonRow],
    allowedMentions: { users: [interaction.user.id] },
  });

  await db
    .update(autommDeposits)
    .set({ embedMessageId: sent.id, updatedAt: new Date() })
    .where(eq(autommDeposits.id, dep.id));

  await interaction.editReply({
    embeds: [
      successEmbed(
        "Deposit Posted",
        `Posted in <#${channel.id}>.\n` +
          (autoMonitor
            ? `On-chain monitoring is **enabled** for ${method}. The bot will notify you here when the deposit lands.`
            : `Auto-monitor is **off** for ${method}. A staff member will manually verify the deposit.`),
      ),
    ],
  });
}

// ──────────────────────────────────────────────────────────────────────────
// Step 4: Confirm / Cancel / Re-check buttons
// ──────────────────────────────────────────────────────────────────────────

function isStaff(member: GuildMember | null): boolean {
  if (!member) return false;
  return member.permissions.has("ManageChannels") || member.permissions.has("ManageGuild");
}

async function handleDepositButton(interaction: ButtonInteraction): Promise<unknown> {
  if (!interaction.inCachedGuild()) return;
  const { action, args } = decodeId(interaction.customId);
  const id = Number(args[0]);
  if (!id) return;
  const [dep] = await db.select().from(autommDeposits).where(eq(autommDeposits.id, id)).limit(1);
  if (!dep) {
    return interaction.reply({ embeds: [errorEmbed("Not Found", "This deposit no longer exists.")], ephemeral: true });
  }

  const isBuyer = interaction.user.id === dep.buyerId;
  const staff = isStaff(interaction.member as GuildMember);

  if (action === "confirm") {
    if (!isBuyer && !staff) {
      return interaction.reply({
        embeds: [errorEmbed("Not Allowed", "Only the buyer or staff can confirm.")],
        ephemeral: true,
      });
    }
    if (dep.status === "cancelled" || dep.status === "expired") {
      return interaction.reply({
        embeds: [errorEmbed("Closed", "This deposit is no longer active.")],
        ephemeral: true,
      });
    }
    await setDepositStatus(id, "confirmed", interaction.user.id);
    return interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "success",
          title: `${EMOJI.success} Deposit Confirmed`,
          description:
            `<@${interaction.user.id}> confirmed the deposit of **${dep.expectedAmount} ${dep.method}**.\n\n` +
            `**A human middleman will now release the goods.** The bot does not — and cannot — send funds.`,
        }),
      ],
    });
  }

  if (action === "cancel_dep") {
    if (!isBuyer && !staff) {
      return interaction.reply({
        embeds: [errorEmbed("Not Allowed", "Only the buyer or staff can cancel.")],
        ephemeral: true,
      });
    }
    await setDepositStatus(id, "cancelled", interaction.user.id);
    return interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "danger",
          title: `${EMOJI.cancel} Deposit Cancelled`,
          description:
            `<@${interaction.user.id}> cancelled the deposit of **${dep.expectedAmount} ${dep.method}**.\n\n` +
            `If a deposit was already sent, contact staff in this ticket — the bot will not refund or move funds.`,
        }),
      ],
    });
  }

  if (action === "recheck") {
    if (!isBuyer && !staff) {
      return interaction.reply({ embeds: [errorEmbed("Not Allowed", "Only the buyer or staff can re-check.")], ephemeral: true });
    }
    if (!dep.autoMonitor || !AUTO_METHODS.has(dep.method)) {
      return interaction.reply({ embeds: [errorEmbed("Manual Method", "Auto-check isn't available for this payment method.")], ephemeral: true });
    }
    await interaction.deferReply({ ephemeral: true });
    const snap = await safeGetBalance(dep.method, dep.address);
    if (!snap) {
      return interaction.editReply({ embeds: [errorEmbed("Lookup Failed", "Couldn't reach the chain explorer right now. Try again shortly.")] });
    }
    const initial = Number(dep.initialBalance ?? "0");
    const delta = snap.balance - initial;
    return interaction.editReply({
      embeds: [
        infoEmbed(
          "Current Status",
          `Address: \`${dep.address}\`\n` +
            `Balance now: **${snap.balance} ${dep.method}**\n` +
            `Detected since deposit: **${delta > 0 ? delta : 0} ${dep.method}**\n` +
            `Expected: **${dep.expectedAmount} ${dep.method}**\n\n` +
            `The background monitor checks every ~30s.`,
        ),
      ],
    });
  }
}

// ──────────────────────────────────────────────────────────────────────────
// Public router used by interaction.ts
// ──────────────────────────────────────────────────────────────────────────

export async function routeAutommDepositInteraction(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction,
): Promise<unknown> {
  try {
    if (interaction.isStringSelectMenu()) {
      const { action } = decodeId(interaction.customId);
      if (action === "method_pick") return handleMethodPick(interaction);
      return;
    }
    if (interaction.isModalSubmit()) {
      const { action } = decodeId(interaction.customId);
      if (action === "deposit_modal") return handleDepositModal(interaction);
      return;
    }
    if (interaction.isButton()) {
      const { action } = decodeId(interaction.customId);
      if (action === "confirm" || action === "cancel_dep" || action === "recheck") {
        return handleDepositButton(interaction);
      }
      if (action === "panel_method") {
        return handlePanelMethodClick(interaction);
      }
      return;
    }
  } catch (err) {
    logger.error({ err }, "automm deposit interaction failed");
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      try {
        await interaction.reply({ embeds: [errorEmbed("Error", err instanceof Error ? err.message : "Unknown")], ephemeral: true });
      } catch {
        // swallow
      }
    }
  }
}
