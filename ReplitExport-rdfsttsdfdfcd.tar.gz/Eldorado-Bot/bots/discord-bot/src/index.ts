import { logger } from "./logger.js";
import { createClient, type BotClient } from "./client.js";
import { registerReadyEvent } from "./events/ready.js";
import { registerInteractionEvent } from "./events/interaction.js";
import { registerMessageEvent } from "./events/message.js";
import { registerMemberJoinEvent } from "./events/member-join.js";
import { registerReactionEvent } from "./events/reaction.js";

import { embedCommand } from "./commands/embeds.js";
import { welcomeCommand } from "./commands/welcome.js";
import { customCommand } from "./commands/custom.js";
import { panelCommand } from "./commands/tickets.js";
import { giveawayCommand } from "./commands/giveaway.js";
import { reactionRoleCommand } from "./commands/reactionrole.js";
import { suggestCommand, suggestionsCommand } from "./commands/suggestion.js";
import { rankCommand, leaderboardCommand, levelingCommand } from "./commands/leveling.js";
import { moderationCommands } from "./commands/moderation.js";
import { configCommands } from "./commands/config.js";
import { utilityCommands } from "./commands/utility.js";
import { funCommands } from "./commands/fun.js";
import { autommCommand } from "./commands/automm.js";
import { giveCommand } from "./commands/give.js";
import { setCommand } from "./commands/set.js";
import { startAutoMiddlemanMonitor } from "./services/automm-monitor.js";

const TOKEN = process.env.DISCORD_TOKEN;
if (!TOKEN) {
  logger.fatal("Missing DISCORD_TOKEN environment variable.");
  process.exit(1);
}

const client = createClient();

function registerAll(bot: BotClient): void {
  const all = [
    embedCommand,
    welcomeCommand,
    customCommand,
    panelCommand,
    giveawayCommand,
    reactionRoleCommand,
    suggestCommand,
    suggestionsCommand,
    rankCommand,
    leaderboardCommand,
    levelingCommand,
    ...moderationCommands,
    ...configCommands,
    ...utilityCommands,
    ...funCommands,
    autommCommand,
    giveCommand,
    setCommand,
  ];
  for (const cmd of all) {
    bot.slash.set(cmd.data.name, cmd);
  }
  logger.info({ count: all.length }, "Slash commands registered in memory");
}

registerAll(client);
registerReadyEvent(client);
registerInteractionEvent(client);
registerMessageEvent(client);
registerMemberJoinEvent(client);
registerReactionEvent(client);

process.on("unhandledRejection", (err) => logger.error({ err }, "unhandledRejection"));
process.on("uncaughtException", (err) => logger.error({ err }, "uncaughtException"));

client.once("ready", () => {
  startAutoMiddlemanMonitor(client);
});

client.login(TOKEN).catch((err) => {
  logger.fatal({ err }, "Failed to log in to Discord");
  process.exit(1);
});
