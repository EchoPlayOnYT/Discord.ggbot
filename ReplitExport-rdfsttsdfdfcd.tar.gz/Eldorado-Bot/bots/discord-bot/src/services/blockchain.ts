/**
 * Read-only blockchain lookups for Auto Middleman deposit detection.
 *
 * IMPORTANT — SAFETY MODEL:
 *  - Every function in this file is READ-ONLY.
 *  - The bot never holds private keys, never signs, never broadcasts transactions.
 *  - We only check public balances / transactions of admin-provided addresses.
 *  - Funds are received and released by the human admin, not by the bot.
 *
 * Free public endpoints are used by default. Optional API keys can be set via env:
 *   - ETHERSCAN_API_KEY  (eth + erc20 USDT)
 */

import { logger } from "../logger.js";

export type SupportedChain = "BTC" | "LTC" | "ETH" | "USDT";

export type BalanceResult = {
  /** Confirmed balance in human units (BTC, LTC, ETH, USDT). */
  balance: number;
  /** Most recent confirmed tx hash, if any. */
  lastTxHash: string | null;
};

const FETCH_TIMEOUT_MS = 8_000;

async function fetchJson(url: string): Promise<unknown> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: { accept: "application/json" } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

// ──────────────── BTC (blockstream.info, no key required) ────────────────

export async function getBtcBalance(address: string): Promise<BalanceResult> {
  const data = (await fetchJson(`https://blockstream.info/api/address/${encodeURIComponent(address)}`)) as {
    chain_stats?: { funded_txo_sum?: number; spent_txo_sum?: number; tx_count?: number };
  };
  const funded = data.chain_stats?.funded_txo_sum ?? 0;
  const spent = data.chain_stats?.spent_txo_sum ?? 0;
  const sats = funded - spent;
  const balance = sats / 1e8;

  let lastTxHash: string | null = null;
  if ((data.chain_stats?.tx_count ?? 0) > 0) {
    try {
      const txs = (await fetchJson(`https://blockstream.info/api/address/${encodeURIComponent(address)}/txs`)) as Array<{ txid: string; status?: { confirmed?: boolean } }>;
      const confirmed = txs.find((t) => t.status?.confirmed);
      lastTxHash = confirmed?.txid ?? txs[0]?.txid ?? null;
    } catch {
      // best-effort
    }
  }
  return { balance, lastTxHash };
}

// ──────────────── LTC (blockchair.com, no key required, rate-limited) ────────────────

export async function getLtcBalance(address: string): Promise<BalanceResult> {
  const data = (await fetchJson(
    `https://api.blockchair.com/litecoin/dashboards/address/${encodeURIComponent(address)}?limit=1`,
  )) as {
    data?: Record<string, { address?: { balance?: number }; transactions?: string[] }>;
  };
  const entry = data.data?.[address];
  const litoshi = entry?.address?.balance ?? 0;
  const balance = litoshi / 1e8;
  const lastTxHash = entry?.transactions?.[0] ?? null;
  return { balance, lastTxHash };
}

// ──────────────── ETH (etherscan, requires ETHERSCAN_API_KEY) ────────────────

const ETHERSCAN_KEY = process.env.ETHERSCAN_API_KEY ?? "";

export function ethMonitorAvailable(): boolean {
  return Boolean(ETHERSCAN_KEY);
}

export async function getEthBalance(address: string): Promise<BalanceResult> {
  if (!ETHERSCAN_KEY) throw new Error("ETHERSCAN_API_KEY not set — ETH auto-monitor disabled");
  const balanceData = (await fetchJson(
    `https://api.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest&apikey=${ETHERSCAN_KEY}`,
  )) as { status: string; result: string };
  if (balanceData.status !== "1") throw new Error(`etherscan: ${balanceData.result}`);
  const wei = BigInt(balanceData.result);
  const balance = Number(wei) / 1e18;

  let lastTxHash: string | null = null;
  try {
    const txData = (await fetchJson(
      `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&page=1&offset=1&sort=desc&apikey=${ETHERSCAN_KEY}`,
    )) as { status: string; result: Array<{ hash: string }> };
    if (txData.status === "1" && txData.result.length) lastTxHash = txData.result[0]!.hash;
  } catch {
    // best-effort
  }
  return { balance, lastTxHash };
}

// USDT on Ethereum (ERC-20). Other chains (TRC-20, BEP-20) intentionally omitted unless the
// admin explicitly configures the network — the address format alone is ambiguous.
const USDT_ERC20_CONTRACT = "0xdAC17F958D2ee523a2206206994597C13D831ec7";

export async function getUsdtErc20Balance(address: string): Promise<BalanceResult> {
  if (!ETHERSCAN_KEY) throw new Error("ETHERSCAN_API_KEY not set — USDT auto-monitor disabled");
  const balanceData = (await fetchJson(
    `https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=${USDT_ERC20_CONTRACT}&address=${address}&tag=latest&apikey=${ETHERSCAN_KEY}`,
  )) as { status: string; result: string };
  if (balanceData.status !== "1") throw new Error(`etherscan: ${balanceData.result}`);
  const raw = BigInt(balanceData.result);
  // USDT has 6 decimals
  const balance = Number(raw) / 1e6;

  let lastTxHash: string | null = null;
  try {
    const txData = (await fetchJson(
      `https://api.etherscan.io/api?module=account&action=tokentx&contractaddress=${USDT_ERC20_CONTRACT}&address=${address}&page=1&offset=1&sort=desc&apikey=${ETHERSCAN_KEY}`,
    )) as { status: string; result: Array<{ hash: string }> };
    if (txData.status === "1" && txData.result.length) lastTxHash = txData.result[0]!.hash;
  } catch {
    // best-effort
  }
  return { balance, lastTxHash };
}

// ──────────────── Dispatcher ────────────────

export type MonitorAvailability = { method: SupportedChain; available: boolean; reason?: string };

export function getMonitorAvailability(): MonitorAvailability[] {
  return [
    { method: "BTC", available: true },
    { method: "LTC", available: true },
    { method: "ETH", available: ethMonitorAvailable(), reason: ethMonitorAvailable() ? undefined : "ETHERSCAN_API_KEY missing" },
    { method: "USDT", available: ethMonitorAvailable(), reason: ethMonitorAvailable() ? undefined : "ETHERSCAN_API_KEY missing (ERC-20)" },
  ];
}

export async function getBalance(method: string, address: string): Promise<BalanceResult> {
  switch (method.toUpperCase()) {
    case "BTC":
      return getBtcBalance(address);
    case "LTC":
      return getLtcBalance(address);
    case "ETH":
      return getEthBalance(address);
    case "USDT":
      return getUsdtErc20Balance(address);
    default:
      throw new Error(`Auto-monitor not supported for method ${method}`);
  }
}

/** Try a balance lookup; return null if it fails (safe for polling loops). */
export async function safeGetBalance(method: string, address: string): Promise<BalanceResult | null> {
  try {
    return await getBalance(method, address);
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : err, method, address }, "balance lookup failed");
    return null;
  }
}
