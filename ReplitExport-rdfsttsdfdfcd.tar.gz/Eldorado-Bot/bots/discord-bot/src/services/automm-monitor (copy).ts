/**
 * Auto Middleman background polling service.
 *
 * Every POLL_INTERVAL_MS we walk all `pending` deposits, check the address balance
 * via the read-only blockchain client, and update the embed when a matching deposit
 * is detected. The bot NEVER moves funds — it only notifies the parties.
 */

import type { Client, TextChannel } from "discord.js";
import { eq, and, lt, inArray } from "drizzle-orm";
import { db, autommDeposits, type AutoMmStatus } from "@workspace/db";
import { brandedEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { logger } from "../logger.js";
import { safeGetBalance } from "./blockchain.js";

const POLL_INTERVAL_MS = 30_000;
let timer: NodeJS.Timeout | null = null;

export function startAutoMiddlemanMonitor(client: Client): void {
  if (timer) return;
  logger.info({ intervalMs: POLL_INTERVAL_MS }, "Auto Middleman monitor started");
  timer = setInterval(() => {
    tick(client).catch((err) => logger.error({ err }, "automm tick failed"));
  }, POLL_INTERVAL_MS);
  // first run shortly after boot
  setTimeout(() => tick(client).catch(() => null), 5_000);
}

export function stopAutoMiddlemanMonitor(): void {
  if (timer) clearInterval(timer);
  timer = null;
}

async function tick(client: Client): Promise<void> {
  const now = new Date();

  // 1) Expire any pending deposits past their expiresAt.
  const expired = await db
    .update(autommDeposits)
    .set({ status: "expired", updatedAt: now })
    .where(and(eq(autommDeposits.status, "pending"), lt(autommDeposits.expiresAt, now)))
    .returning();
  for (const dep of expired) {
    await postUpdate(client, dep.guildId, dep.ticketChannelId, dep.embedMessageId, {
      kind: "warning",
      title: `${EMOJI.warn} Deposit Expired`,
      description: `The deposit window for **${dep.expectedAmount} ${dep.method}** expired. Use \`/give automm\` to start a new one.`,
    });
  }

  // 2) Poll active deposits whose method has auto-monitoring enabled.
  const active = await db
    .select()
    .from(autommDeposits)
    .where(and(eq(autommDeposits.status, "pending"), eq(autommDeposits.autoMonitor, true)));

  for (const dep of active) {
    const result = await safeGetBalance(dep.method, dep.address);
    await db
      .update(autommDeposits)
      .set({ lastCheckedAt: new Date() })
      .where(eq(autommDeposits.id, dep.id));
    if (!result) continue;

    const initial = Number(dep.initialBalance ?? "0");
    const delta = result.balance - initial;
    const expected = Number(dep.expectedAmount);
    if (!Number.isFinite(delta) || delta <= 0 || !Number.isFinite(expected)) continue;

    // Treat as "received" once delta >= (1 - tolerance) * expected.
    const tolerancePct = 2; // mirrors default in autommConfig; conservative
    const minReceive = expected * (1 - tolerancePct / 100);
    if (delta + 1e-9 < minReceive) continue;

    const sameTx = result.lastTxHash && result.lastTxHash === dep.txHash;
    if (sameTx) continue;

    await db
      .update(autommDeposits)
      .set({
        status: "received",
        receivedAmount: String(delta),
        txHash: result.lastTxHash,
        updatedAt: new Date(),
      })
      .where(eq(autommDeposits.id, dep.id));

    await postUpdate(client, dep.guildId, dep.ticketChannelId, dep.embedMessageId, {
      kind: "success",
      title: `${EMOJI.success} Deposit Detected`,
      description:
        `**${delta} ${dep.method}** received at \`${dep.address}\`.\n` +
        `Expected: \`${expected} ${dep.method}\`.\n` +
        (result.lastTxHash ? `Tx: \`${result.lastTxHash}\`\n\n` : "\n") +
        `<@${dep.buyerId}> please **Confirm** or **Cancel** above. ` +
        `A human middleman will release the goods — the bot never moves funds.`,
    });
  }
}

async function postUpdate(
  client: Client,
  _guildId: string,
  channelId: string,
  embedMessageId: string | null,
  embed: { kind: "success" | "warning" | "info"; title: string; description: string },
): Promise<void> {
  try {
    const channel = (await client.channels.fetch(channelId).catch(() => null)) as TextChannel | null;
    if (!channel?.isTextBased()) return;
    const opts = { embeds: [brandedEmbed(embed)] };
    if (embedMessageId) {
      await channel.send({ ...opts, reply: { messageReference: embedMessageId, failIfNotExists: false } }).catch(async () => {
        await channel.send(opts).catch(() => null);
      });
    } else {
      await channel.send(opts).catch(() => null);
    }
  } catch (err) {
    logger.warn({ err }, "automm postUpdate failed");
  }
}

/** Manual transition used by the Confirm/Cancel button handler. */
export async function setDepositStatus(
  id: number,
  status: AutoMmStatus,
  actorId: string,
): Promise<void> {
  const patch: Partial<typeof autommDeposits.$inferInsert> = { status, updatedAt: new Date() };
  if (status === "confirmed") patch.confirmedByUserId = actorId;
  if (status === "cancelled") patch.cancelledByUserId = actorId;
  await db.update(autommDeposits).set(patch).where(eq(autommDeposits.id, id));
}

/** Used by /give automm to ignore stale rows when a new session is started in the same channel. */
export async function expireOpenDepositsForChannel(channelId: string): Promise<void> {
  await db
    .update(autommDeposits)
    .set({ status: "cancelled", updatedAt: new Date() })
    .where(and(eq(autommDeposits.ticketChannelId, channelId), inArray(autommDeposits.status, ["pending", "received"])));
}
