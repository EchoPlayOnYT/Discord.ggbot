import { REST, Routes } from "discord.js";
import { logger } from "./logger.js";

import { embedCommand } from "./commands/embeds.js";
import { welcomeCommand } from "./commands/welcome.js";
import { customCommand } from "./commands/custom.js";
import { panelCommand } from "./commands/tickets.js";
import { giveawayCommand } from "./commands/giveaway.js";
import { reactionRoleCommand } from "./commands/reactionrole.js";
import { suggestCommand, suggestionsCommand } from "./commands/suggestion.js";
import { rankCommand, leaderboardCommand, levelingCommand } from "./commands/leveling.js";
import { moderationCommands } from "./commands/moderation.js";
import { configCommands } from "./commands/config.js";
import { utilityCommands } from "./commands/utility.js";
import { funCommands } from "./commands/fun.js";
import { autommCommand } from "./commands/automm.js";
import { giveCommand } from "./commands/give.js";
import { setCommand } from "./commands/set.js";

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const GUILD_ID = process.env.DISCORD_GUILD_ID;

if (!TOKEN || !CLIENT_ID) {
  logger.fatal("Missing DISCORD_TOKEN or DISCORD_CLIENT_ID environment variables.");
  process.exit(1);
}

const all = [
  embedCommand,
  welcomeCommand,
  customCommand,
  panelCommand,
  giveawayCommand,
  reactionRoleCommand,
  suggestCommand,
  suggestionsCommand,
  rankCommand,
  leaderboardCommand,
  levelingCommand,
  ...moderationCommands,
  ...configCommands,
  ...utilityCommands,
  ...funCommands,
  autommCommand,
  giveCommand,
  setCommand,
];

const body = all.map((c) => c.data.toJSON());

const rest = new REST({ version: "10" }).setToken(TOKEN);

async function main(): Promise<void> {
  try {
    if (GUILD_ID) {
      logger.info({ guild: GUILD_ID, count: body.length }, "Deploying guild slash commands…");
      const data = (await rest.put(Routes.applicationGuildCommands(CLIENT_ID!, GUILD_ID), { body })) as unknown[];
      logger.info({ deployed: data.length }, "Guild commands deployed.");
    } else {
      logger.info({ count: body.length }, "Deploying GLOBAL slash commands (may take up to an hour to propagate)…");
      const data = (await rest.put(Routes.applicationCommands(CLIENT_ID!), { body })) as unknown[];
      logger.info({ deployed: data.length }, "Global commands deployed.");
    }
  } catch (err) {
    logger.fatal({ err }, "Failed to deploy slash commands");
    process.exit(1);
  }
}

void main();
