import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  type TextChannel,
} from "discord.js";
import ms from "ms";
import { db, giveaways } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId } from "../utils/component-ids.js";

export const giveawayCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("Manage giveaways.")
    .addSubcommand((s) =>
      s
        .setName("start")
        .setDescription("Start a new giveaway.")
        .addStringOption((o) => o.setName("prize").setDescription("Prize").setRequired(true))
        .addStringOption((o) => o.setName("duration").setDescription("Duration (e.g. 1h, 2d)").setRequired(true))
        .addIntegerOption((o) => o.setName("winners").setDescription("Number of winners (default 1)").setMinValue(1).setMaxValue(20))
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel (default current)").addChannelTypes(ChannelType.GuildText),
        )
        .addStringOption((o) => o.setName("description").setDescription("Extra description")),
    )
    .addSubcommand((s) =>
      s
        .setName("end")
        .setDescription("End a giveaway early.")
        .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("reroll")
        .setDescription("Pick new winners for a finished giveaway.")
        .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true)),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "start") {
      const prize = interaction.options.getString("prize", true);
      const durationRaw = interaction.options.getString("duration", true);
      const winners = interaction.options.getInteger("winners") ?? 1;
      const channel = (interaction.options.getChannel("channel") ?? interaction.channel) as TextChannel;
      const description = interaction.options.getString("description");
      let durationMs: number;
      try {
        const v = ms(durationRaw);
        if (typeof v !== "number" || v < 10_000) throw new Error("min 10s");
        durationMs = v;
      } catch {
        return interaction.reply({ embeds: [errorEmbed("Invalid Duration", "Use values like `30m`, `1h`, `2d`. Min 10s.")], ephemeral: true });
      }
      const endsAt = new Date(Date.now() + durationMs);
      const embed = renderEmbedConfig({
        title: `${EMOJI.gift} ${prize}`,
        description: [
          description ? description + "\n" : "",
          `Click **Enter Giveaway** below to participate.`,
          ``,
          `**Winners:** ${winners}`,
          `**Ends:** <t:${Math.floor(endsAt.getTime() / 1000)}:R> (<t:${Math.floor(endsAt.getTime() / 1000)}:F>)`,
          `**Hosted by:** ${interaction.user}`,
        ].join("\n"),
        color: BRAND.primary,
        bannerUrl: BRAND.defaultBanner,
        footerText: BRAND.footerText,
        footerIconUrl: BRAND.footerIcon,
        timestamp: false,
      });
      const msg = await channel.send({
        embeds: [embed],
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(encodeId("giveaway", "enter")).setLabel("Enter Giveaway").setEmoji(EMOJI.gift).setStyle(ButtonStyle.Success),
          ),
        ],
      });
      await db.insert(giveaways).values({
        guildId: interaction.guildId,
        channelId: channel.id,
        messageId: msg.id,
        prize,
        description,
        winnersCount: winners,
        endsAt,
        hostId: interaction.user.id,
        entrants: [],
      });
      return interaction.reply({ embeds: [successEmbed("Giveaway Started", `Posted in ${channel}.`)], ephemeral: true });
    }

    if (sub === "end") {
      const id = interaction.options.getString("message_id", true);
      const [g] = await db
        .select()
        .from(giveaways)
        .where(and(eq(giveaways.guildId, interaction.guildId), eq(giveaways.messageId, id)))
        .limit(1);
      if (!g) return interaction.reply({ embeds: [errorEmbed("Not Found", "No giveaway with that message ID.")], ephemeral: true });
      await db.update(giveaways).set({ endsAt: new Date(0) }).where(eq(giveaways.id, g.id));
      return interaction.reply({ embeds: [successEmbed("Ending Soon", "Giveaway will end on the next tick.")], ephemeral: true });
    }

    if (sub === "reroll") {
      const id = interaction.options.getString("message_id", true);
      const [g] = await db
        .select()
        .from(giveaways)
        .where(and(eq(giveaways.guildId, interaction.guildId), eq(giveaways.messageId, id)))
        .limit(1);
      if (!g) return interaction.reply({ embeds: [errorEmbed("Not Found", "No giveaway with that message ID.")], ephemeral: true });
      if (!g.ended) return interaction.reply({ embeds: [errorEmbed("Not Ended", "Wait for the giveaway to end first.")], ephemeral: true });
      const eligible = g.entrants.filter((id) => !g.winners.includes(id));
      if (eligible.length === 0)
        return interaction.reply({ embeds: [errorEmbed("No Entrants", "Nobody else entered the giveaway.")], ephemeral: true });
      const newWinners = pickRandom(eligible, g.winnersCount);
      const channel = interaction.guild.channels.cache.get(g.channelId) as TextChannel | undefined;
      if (channel?.isTextBased())
        await channel.send({
          embeds: [
            brandedEmbed({
              kind: "primary",
              title: `${EMOJI.gift} Reroll — ${g.prize}`,
              description: `New winner${newWinners.length > 1 ? "s" : ""}: ${newWinners.map((w) => `<@${w}>`).join(", ")}`,
            }),
          ],
        });
      await db.update(giveaways).set({ winners: [...g.winners, ...newWinners] }).where(eq(giveaways.id, g.id));
      return interaction.reply({ embeds: [successEmbed("Rerolled", "New winners announced.")], ephemeral: true });
    }
  },
};

export function pickRandom<T>(arr: T[], n: number): T[] {
  const a = [...arr];
  const out: T[] = [];
  for (let i = 0; i < n && a.length > 0; i++) {
    const idx = Math.floor(Math.random() * a.length);
    out.push(a.splice(idx, 1)[0]!);
  }
  return out;
}
