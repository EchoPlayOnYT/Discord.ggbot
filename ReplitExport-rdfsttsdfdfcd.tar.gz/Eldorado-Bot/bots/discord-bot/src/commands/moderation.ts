import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  GuildMember,
  TextChannel,
  type Guild,
} from "discord.js";
import { db, warnings } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, moderationEmbed, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { hasPerms, outranks, PERM } from "../utils/permissions.js";
import { parseDuration, longTime } from "../utils/duration.js";
import { getGuildSettings } from "../utils/db-helpers.js";

async function logToModChannel(guild: Guild, embed: ReturnType<typeof moderationEmbed>): Promise<void> {
  const settings = await getGuildSettings(guild.id);
  if (!settings.modLogChannelId) return;
  const channel = guild.channels.cache.get(settings.modLogChannelId) as TextChannel | undefined;
  if (!channel?.isTextBased()) return;
  await channel.send({ embeds: [embed] }).catch(() => null);
}

async function targetMember(interaction: ChatInputCommandInteraction): Promise<{
  member: GuildMember | null;
  ok: boolean;
}> {
  const target = interaction.options.getUser("user", true);
  const member = await interaction.guild!.members.fetch(target.id).catch(() => null);
  if (!member) {
    await interaction.reply({
      embeds: [errorEmbed("Member Not Found", "That user isn't in this server.")],
      ephemeral: true,
    });
    return { member: null, ok: false };
  }
  const actor = interaction.member as GuildMember;
  if (!outranks(actor, member)) {
    await interaction.reply({
      embeds: [
        errorEmbed(
          "Role Hierarchy",
          "You can't moderate this user — their highest role is above or equal to yours.",
        ),
      ],
      ephemeral: true,
    });
    return { member: null, ok: false };
  }
  if (!outranks(interaction.guild!.members.me!, member)) {
    await interaction.reply({
      embeds: [
        errorEmbed(
          "Bot Hierarchy",
          "I can't moderate this user — their highest role is above or equal to mine.",
        ),
      ],
      ephemeral: true,
    });
    return { member: null, ok: false };
  }
  return { member, ok: true };
}

export const banCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member from the server.")
    .addUserOption((o) => o.setName("user").setDescription("Member to ban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the ban"))
    .addIntegerOption((o) =>
      o.setName("delete_days").setDescription("Days of messages to delete (0-7)").setMinValue(0).setMaxValue(7),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    if (!hasPerms(interaction.member, PERM.BanMembers))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Ban Members** to use this.")],
        ephemeral: true,
      });
    const { member, ok } = await targetMember(interaction);
    if (!ok || !member) return;
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    const days = interaction.options.getInteger("delete_days") ?? 0;
    await member.ban({ reason: `${interaction.user.tag}: ${reason}`, deleteMessageSeconds: days * 86400 });
    const embed = moderationEmbed({
      action: "Member Banned",
      emoji: EMOJI.ban,
      target: member.user,
      moderator: interaction.user,
      reason,
      kind: "danger",
    });
    await interaction.reply({ embeds: [embed] });
    await logToModChannel(interaction.guild, embed);
  },
};

export const kickCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server.")
    .addUserOption((o) => o.setName("user").setDescription("Member to kick").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    if (!hasPerms(interaction.member, PERM.KickMembers))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Kick Members** to use this.")],
        ephemeral: true,
      });
    const { member, ok } = await targetMember(interaction);
    if (!ok || !member) return;
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    await member.kick(`${interaction.user.tag}: ${reason}`);
    const embed = moderationEmbed({
      action: "Member Kicked",
      emoji: EMOJI.kick,
      target: member.user,
      moderator: interaction.user,
      reason,
      kind: "warning",
    });
    await interaction.reply({ embeds: [embed] });
    await logToModChannel(interaction.guild, embed);
  },
};

export const muteCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Timeout a member.")
    .addUserOption((o) => o.setName("user").setDescription("Member to mute").setRequired(true))
    .addStringOption((o) => o.setName("duration").setDescription("Duration (e.g. 10m, 1h, 1d)").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    if (!hasPerms(interaction.member, PERM.ModerateMembers))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Timeout Members** to use this.")],
        ephemeral: true,
      });
    const { member, ok } = await targetMember(interaction);
    if (!ok || !member) return;
    const duration = parseDuration(interaction.options.getString("duration", true));
    if (!duration || duration > 28 * 24 * 60 * 60 * 1000)
      return interaction.reply({
        embeds: [errorEmbed("Invalid Duration", "Provide a duration between 1 second and 28 days (e.g. `10m`, `1h`, `1d`).")],
        ephemeral: true,
      });
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    await member.timeout(duration, `${interaction.user.tag}: ${reason}`);
    const until = new Date(Date.now() + duration);
    const embed = moderationEmbed({
      action: "Member Muted",
      emoji: EMOJI.mute,
      target: member.user,
      moderator: interaction.user,
      reason,
      extra: [{ name: "Expires", value: longTime(until), inline: false }],
      kind: "warning",
    });
    await interaction.reply({ embeds: [embed] });
    await logToModChannel(interaction.guild, embed);
  },
};

export const unmuteCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("Remove a member's timeout.")
    .addUserOption((o) => o.setName("user").setDescription("Member to unmute").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    if (!hasPerms(interaction.member, PERM.ModerateMembers))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Timeout Members** to use this.")],
        ephemeral: true,
      });
    const { member, ok } = await targetMember(interaction);
    if (!ok || !member) return;
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    await member.timeout(null, `${interaction.user.tag}: ${reason}`);
    const embed = moderationEmbed({
      action: "Member Unmuted",
      emoji: EMOJI.unmute,
      target: member.user,
      moderator: interaction.user,
      reason,
      kind: "success",
    });
    await interaction.reply({ embeds: [embed] });
    await logToModChannel(interaction.guild, embed);
  },
};

export const warnCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member (logged in DB).")
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("Add a warning to a member.")
        .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
        .addStringOption((o) => o.setName("reason").setDescription("Reason").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("list")
        .setDescription("List a member's warnings.")
        .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("Remove a warning by ID.")
        .addIntegerOption((o) => o.setName("id").setDescription("Warning ID").setRequired(true)),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "add") {
      const { member, ok } = await targetMember(interaction);
      if (!ok || !member) return;
      const reason = interaction.options.getString("reason", true);
      const inserted = await db
        .insert(warnings)
        .values({
          guildId: interaction.guildId,
          userId: member.id,
          moderatorId: interaction.user.id,
          reason,
        })
        .returning();
      const total = await db
        .select()
        .from(warnings)
        .where(and(eq(warnings.guildId, interaction.guildId), eq(warnings.userId, member.id)));
      const embed = moderationEmbed({
        action: "Member Warned",
        emoji: EMOJI.warning,
        target: member.user,
        moderator: interaction.user,
        reason,
        extra: [
          { name: "Warning ID", value: `\`${inserted[0]!.id}\``, inline: true },
          { name: "Total Warnings", value: `\`${total.length}\``, inline: true },
        ],
        kind: "warning",
      });
      await interaction.reply({ embeds: [embed] });
      await logToModChannel(interaction.guild, embed);
      member.send({ embeds: [embed] }).catch(() => null);
    } else if (sub === "list") {
      const user = interaction.options.getUser("user", true);
      const rows = await db
        .select()
        .from(warnings)
        .where(and(eq(warnings.guildId, interaction.guildId), eq(warnings.userId, user.id)))
        .orderBy(desc(warnings.createdAt))
        .limit(15);
      if (rows.length === 0) {
        return interaction.reply({
          embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Warnings`, description: `${user} has no warnings.` })],
          ephemeral: true,
        });
      }
      const description = rows
        .map(
          (w) =>
            `\`#${w.id}\` • <t:${Math.floor(w.createdAt.getTime() / 1000)}:R> by <@${w.moderatorId}>\n> ${w.reason}`,
        )
        .join("\n\n");
      await interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "warning",
            title: `${EMOJI.warning} Warnings — ${user.tag}`,
            description,
            thumbnail: user.displayAvatarURL({ size: 256 }),
          }),
        ],
        ephemeral: true,
      });
    } else if (sub === "remove") {
      const id = interaction.options.getInteger("id", true);
      const removed = await db
        .delete(warnings)
        .where(and(eq(warnings.id, id), eq(warnings.guildId, interaction.guildId)))
        .returning();
      if (removed.length === 0)
        return interaction.reply({
          embeds: [errorEmbed("Not Found", `No warning with ID \`${id}\` in this server.`)],
          ephemeral: true,
        });
      await interaction.reply({
        embeds: [successEmbed("Warning Removed", `Warning \`#${id}\` deleted.`)],
        ephemeral: true,
      });
    }
  },
};

export const clearCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Bulk delete recent messages in this channel.")
    .addIntegerOption((o) =>
      o.setName("amount").setDescription("How many messages (1-100)").setMinValue(1).setMaxValue(100).setRequired(true),
    )
    .addUserOption((o) => o.setName("user").setDescription("Only delete from this user"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    if (!interaction.inCachedGuild() || !interaction.channel?.isTextBased()) return;
    if (!hasPerms(interaction.member, PERM.ManageMessages))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Manage Messages**.")],
        ephemeral: true,
      });
    const amount = interaction.options.getInteger("amount", true);
    const user = interaction.options.getUser("user");
    await interaction.deferReply({ ephemeral: true });
    const channel = interaction.channel as TextChannel;
    let messages = await channel.messages.fetch({ limit: 100 });
    if (user) messages = messages.filter((m) => m.author.id === user.id);
    const toDelete = messages.first(amount);
    const deleted = await channel.bulkDelete(toDelete, true);
    await interaction.editReply({
      embeds: [
        successEmbed(
          "Messages Cleared",
          `Deleted **${deleted.size}** messages${user ? ` from ${user}` : ""}.`,
        ),
      ],
    });
  },
};

export const unbanCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unban a user by ID.")
    .addStringOption((o) => o.setName("user_id").setDescription("User ID to unban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    if (!interaction.inCachedGuild()) return;
    if (!hasPerms(interaction.member, PERM.BanMembers))
      return interaction.reply({
        embeds: [errorEmbed("Missing Permission", "You need **Ban Members**.")],
        ephemeral: true,
      });
    const userId = interaction.options.getString("user_id", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    try {
      const ban = await interaction.guild.bans.fetch(userId);
      await interaction.guild.bans.remove(userId, `${interaction.user.tag}: ${reason}`);
      const embed = moderationEmbed({
        action: "User Unbanned",
        emoji: EMOJI.unban,
        target: ban.user,
        moderator: interaction.user,
        reason,
        kind: "success",
      });
      await interaction.reply({ embeds: [embed] });
      await logToModChannel(interaction.guild, embed);
    } catch {
      return interaction.reply({
        embeds: [errorEmbed("Not Banned", "That user isn't banned in this server.")],
        ephemeral: true,
      });
    }
  },
};

export const moderationCommands: SlashCommand[] = [
  banCommand,
  kickCommand,
  muteCommand,
  unmuteCommand,
  warnCommand,
  clearCommand,
  unbanCommand,
];
