import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ChannelType,
  type TextChannel,
} from "discord.js";
import { db, reactionRoles } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";

function parseEmojiId(input: string): string {
  // For custom emoji <:name:id> store the ID. For unicode, store as-is.
  const match = /^<a?:[^:]+:(\d+)>$/.exec(input.trim());
  if (match) return match[1]!;
  return input.trim();
}

export const reactionRoleCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("reactionrole")
    .setDescription("Manage reaction roles.")
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("Add a reaction role.")
        .addStringOption((o) => o.setName("message_id").setDescription("Message ID").setRequired(true))
        .addStringOption((o) => o.setName("emoji").setDescription("Emoji").setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("Role to assign").setRequired(true))
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel containing the message").addChannelTypes(ChannelType.GuildText),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("Remove a reaction role.")
        .addStringOption((o) => o.setName("message_id").setDescription("Message ID").setRequired(true))
        .addStringOption((o) => o.setName("emoji").setDescription("Emoji").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("List reaction roles in this server."))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "add") {
      const messageId = interaction.options.getString("message_id", true);
      const emojiInput = interaction.options.getString("emoji", true);
      const role = interaction.options.getRole("role", true);
      const channel = (interaction.options.getChannel("channel") ?? interaction.channel) as TextChannel;
      let msg;
      try {
        msg = await channel.messages.fetch(messageId);
      } catch {
        return interaction.reply({ embeds: [errorEmbed("Message Missing", "Couldn't fetch that message in this channel.")], ephemeral: true });
      }
      const emojiKey = parseEmojiId(emojiInput);
      try {
        await msg.react(emojiInput);
      } catch {
        return interaction.reply({ embeds: [errorEmbed("Invalid Emoji", "I couldn't react with that emoji.")], ephemeral: true });
      }
      await db
        .insert(reactionRoles)
        .values({
          guildId: interaction.guildId,
          channelId: channel.id,
          messageId,
          emoji: emojiKey,
          roleId: role.id,
        })
        .onConflictDoUpdate({
          target: [reactionRoles.messageId, reactionRoles.emoji],
          set: { roleId: role.id, channelId: channel.id, guildId: interaction.guildId },
        });
      return interaction.reply({
        embeds: [successEmbed("Reaction Role Added", `Reacting with ${emojiInput} on that message will now grant ${role}.`)],
      });
    }

    if (sub === "remove") {
      const messageId = interaction.options.getString("message_id", true);
      const emojiKey = parseEmojiId(interaction.options.getString("emoji", true));
      const removed = await db
        .delete(reactionRoles)
        .where(and(eq(reactionRoles.messageId, messageId), eq(reactionRoles.emoji, emojiKey)))
        .returning();
      if (removed.length === 0)
        return interaction.reply({ embeds: [errorEmbed("Not Found", "No matching reaction role.")], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed("Removed", "Reaction role removed.")] });
    }

    if (sub === "list") {
      const all = await db.select().from(reactionRoles).where(eq(reactionRoles.guildId, interaction.guildId));
      if (all.length === 0)
        return interaction.reply({
          embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Reaction Roles`, description: "Use `/reactionrole add`." })],
          ephemeral: true,
        });
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "primary",
            title: `${EMOJI.diamond} Reaction Roles`,
            description: all
              .map(
                (r) =>
                  `[Msg](https://discord.com/channels/${r.guildId}/${r.channelId}/${r.messageId}) — \`${r.emoji}\` → <@&${r.roleId}>`,
              )
              .join("\n"),
          }),
        ],
        ephemeral: true,
      });
    }
  },
};
