import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type GuildMember,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";

export const userInfoCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Show info about a user.")
    .addUserOption((o) => o.setName("user").setDescription("Target user")),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const user = interaction.options.getUser("user") ?? interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    const fields = [
      { name: "Username", value: `\`${user.tag}\``, inline: true },
      { name: "ID", value: `\`${user.id}\``, inline: true },
      { name: "Account Created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: false },
    ];
    if (member?.joinedTimestamp) {
      fields.push({
        name: "Joined Server",
        value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`,
        inline: false,
      });
    }
    if (member && member.roles.cache.size > 1) {
      const roles = member.roles.cache
        .filter((r) => r.id !== interaction.guildId)
        .sort((a, b) => b.position - a.position)
        .map((r) => `<@&${r.id}>`)
        .slice(0, 15)
        .join(" ");
      fields.push({ name: `Roles (${member.roles.cache.size - 1})`, value: roles || "_None_", inline: false });
    }
    await interaction.reply({
      embeds: [
        brandedEmbed({
          title: `${EMOJI.user} ${user.username}`,
          thumbnail: user.displayAvatarURL({ size: 512 }),
          fields,
          kind: "primary",
        }),
      ],
    });
  },
};

export const serverInfoCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("serverinfo").setDescription("Show info about this server."),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const g = interaction.guild;
    const owner = await g.fetchOwner().catch(() => null);
    const fields = [
      { name: "Owner", value: owner ? `${owner}` : "Unknown", inline: true },
      { name: "Members", value: `${g.memberCount}`, inline: true },
      { name: "Boost Tier", value: `Tier ${g.premiumTier} • ${g.premiumSubscriptionCount ?? 0} boosts`, inline: true },
      { name: "Channels", value: `${g.channels.cache.size}`, inline: true },
      { name: "Roles", value: `${g.roles.cache.size}`, inline: true },
      { name: "Created", value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
    ];
    await interaction.reply({
      embeds: [
        brandedEmbed({
          title: `${EMOJI.server} ${g.name}`,
          thumbnail: g.iconURL({ size: 512 }) ?? undefined,
          banner: g.bannerURL({ size: 1024 }) ?? undefined,
          fields,
          kind: "primary",
        }),
      ],
    });
  },
};

export const avatarCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("Show a user's avatar.")
    .addUserOption((o) => o.setName("user").setDescription("Target user")),
  async execute(interaction: ChatInputCommandInteraction) {
    const user = interaction.options.getUser("user") ?? interaction.user;
    const url = user.displayAvatarURL({ size: 1024 });
    await interaction.reply({
      embeds: [
        brandedEmbed({
          title: `${EMOJI.user} ${user.username}'s Avatar`,
          image: url,
          kind: "primary",
        }),
      ],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setLabel("Open Image").setStyle(ButtonStyle.Link).setURL(url),
        ),
      ],
    });
  },
};

export const pingCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("ping").setDescription("Show bot latency."),
  async execute(interaction: ChatInputCommandInteraction) {
    const sent = await interaction.reply({
      embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.ping} Pinging...` })],
      fetchReply: true,
    });
    const rtt = sent.createdTimestamp - interaction.createdTimestamp;
    await interaction.editReply({
      embeds: [
        brandedEmbed({
          kind: "success",
          title: `${EMOJI.ping} Pong!`,
          fields: [
            { name: "Roundtrip", value: `\`${rtt}ms\``, inline: true },
            { name: "Websocket", value: `\`${interaction.client.ws.ping}ms\``, inline: true },
          ],
        }),
      ],
    });
  },
};

export const sayCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("say")
    .setDescription("Send a message as the bot.")
    .addStringOption((o) => o.setName("message").setDescription("Message").setRequired(true))
    .addBooleanOption((o) => o.setName("embed").setDescription("Send as embed instead of plain text"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.channel?.isSendable())
      return interaction.reply({
        embeds: [errorEmbed("Cannot Send", "I can't send messages here.")],
        ephemeral: true,
      });
    const text = interaction.options.getString("message", true);
    const asEmbed = interaction.options.getBoolean("embed") ?? false;
    if (asEmbed) {
      await interaction.channel.send({ embeds: [brandedEmbed({ description: text, kind: "primary" })] });
    } else {
      await interaction.channel.send({ content: text });
    }
    await interaction.reply({ embeds: [brandedEmbed({ kind: "success", title: `${EMOJI.success} Sent` })], ephemeral: true });
  },
};

export const pollCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Create a poll.")
    .addStringOption((o) => o.setName("question").setDescription("The poll question").setRequired(true))
    .addStringOption((o) => o.setName("options").setDescription("Comma-separated options (max 10)").setRequired(true))
    .addStringOption((o) => o.setName("duration").setDescription("Duration like 1h, 1d (default 1d)")),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.channel?.isSendable()) return;
    const question = interaction.options.getString("question", true);
    const optionsRaw = interaction.options
      .getString("options", true)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (optionsRaw.length < 2 || optionsRaw.length > 10)
      return interaction.reply({
        embeds: [errorEmbed("Invalid Options", "Provide between 2 and 10 comma-separated options.")],
        ephemeral: true,
      });
    const durationStr = interaction.options.getString("duration") ?? "1d";
    let hours = 24;
    const match = durationStr.match(/^(\d+)([hmd])$/);
    if (match) {
      const n = Number(match[1]);
      const unit = match[2];
      if (unit === "h") hours = n;
      else if (unit === "d") hours = n * 24;
      else if (unit === "m") hours = Math.max(1, Math.ceil(n / 60));
    }
    hours = Math.min(Math.max(hours, 1), 32 * 24);
    await interaction.reply({
      poll: {
        question: { text: question },
        answers: optionsRaw.map((t) => ({ text: t })),
        allowMultiselect: false,
        duration: hours,
      },
    });
  },
};

export const helpCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("help").setDescription("Show what this bot can do."),
  async execute(interaction: ChatInputCommandInteraction) {
    const isStaff = (interaction.member as GuildMember | null)?.permissions.has(PermissionFlagsBits.ManageGuild);
    const fields = [
      {
        name: `${EMOJI.ban} Moderation`,
        value: "`/ban` `/kick` `/mute` `/unmute` `/unban` `/warn` `/clear`",
        inline: false,
      },
      {
        name: `${EMOJI.ticket} Tickets`,
        value: "`/panel create` `/panel edit` `/panel delete` `/panel send` `/panel list`",
        inline: false,
      },
      {
        name: `${EMOJI.edit} Embeds & Custom Commands`,
        value: "`/embed create` `/custom command create` `/custom command edit` `/custom command delete` `/custom command list`",
        inline: false,
      },
      {
        name: `${EMOJI.sparkle} Welcome & Engagement`,
        value: "`/welcome setup` `/welcome edit` `/welcome test` `/welcome disable`",
        inline: false,
      },
      {
        name: `${EMOJI.level} Leveling`,
        value: "`/rank` `/leaderboard` `/level enable` `/level disable` `/level reward add` `/level reward remove`",
        inline: false,
      },
      {
        name: `${EMOJI.giveaway} Giveaways`,
        value: "`/giveaway start` `/giveaway end` `/giveaway reroll` `/giveaway list`",
        inline: false,
      },
      {
        name: `${EMOJI.reaction} Reaction Roles & Suggestions`,
        value: "`/reactionrole create` `/reactionrole delete` `/suggest` `/suggestion setup`",
        inline: false,
      },
      {
        name: `${EMOJI.user} Utility & Fun`,
        value: "`/userinfo` `/serverinfo` `/avatar` `/ping` `/say` `/poll` `/coinflip` `/random` `/joke` `/rps`",
        inline: false,
      },
    ];
    if (isStaff) {
      fields.push({
        name: `${EMOJI.edit} Configuration`,
        value: "`/prefix` `/modlog set` `/modlog disable`",
        inline: false,
      });
    }
    await interaction.reply({
      embeds: [
        brandedEmbed({
          title: `${EMOJI.diamond} ${BRAND.name} Bot — Command Center`,
          description: `A premium, fully customizable Discord bot for ${BRAND.name} communities.\nEvery feature uses live builders, modal forms, and a unified branded design.`,
          fields,
          banner: BRAND.defaultBanner,
        }),
      ],
      ephemeral: true,
    });
  },
};

export const utilityCommands: SlashCommand[] = [
  userInfoCommand,
  serverInfoCommand,
  avatarCommand,
  pingCommand,
  sayCommand,
  pollCommand,
  helpCommand,
];
