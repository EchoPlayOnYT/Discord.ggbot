import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  type ChatInputCommandInteraction,
} from "discord.js";
import { eq, and } from "drizzle-orm";
import { db, autommAddresses, autommConfig } from "@workspace/db";
import type { SlashCommand } from "../client.js";
import { successEmbed } from "../embed.js";

const METHOD_CHOICES = [
  { name: "Bitcoin (BTC)", value: "BTC" },
  { name: "Litecoin (LTC)", value: "LTC" },
  { name: "Ethereum (ETH)", value: "ETH" },
  { name: "Tether (USDT)", value: "USDT" },
  { name: "Robux (manual)", value: "ROBUX" },
  { name: "Other (manual)", value: "OTHER" },
];

/**
 * `/set` is a small group of administrative shortcuts.
 * `/set address` mirrors `/automm address set` for the UX described in the spec.
 */
export const setCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("set")
    .setDescription("Quick-set various server settings.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName("address")
        .setDescription("Set the Auto Middleman wallet address for a payment method.")
        .addStringOption((o) =>
          o.setName("method").setDescription("Payment method").setRequired(true).addChoices(...METHOD_CHOICES),
        )
        .addStringOption((o) => o.setName("address").setDescription("Wallet address / handle").setRequired(true))
        .addStringOption((o) => o.setName("network").setDescription("Network (e.g. ERC-20, TRC-20)").setRequired(false))
        .addStringOption((o) => o.setName("label").setDescription("Friendly label").setRequired(false)),
    ),

  execute: async (interaction: ChatInputCommandInteraction) => {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === "address") {
      const method = interaction.options.getString("method", true).toUpperCase();
      const address = interaction.options.getString("address", true).trim();
      const network = interaction.options.getString("network", false)?.trim() || null;
      const label = interaction.options.getString("label", false)?.trim() || null;

      // ensure config row exists
      await db.insert(autommConfig).values({ guildId }).onConflictDoNothing();

      await db
        .insert(autommAddresses)
        .values({ guildId, method, address, network, label, isActive: true })
        .onConflictDoUpdate({
          target: [autommAddresses.guildId, autommAddresses.method],
          set: { address, network, label, isActive: true },
        });

      return interaction.reply({
        embeds: [
          successEmbed(
            "Address Saved",
            `**${method}** ${network ? `(${network}) ` : ""}→ \`${address}\`\n\n` +
              `> The bot only **reads** this address to detect deposits. It cannot send or hold funds.`,
          ),
        ],
        ephemeral: true,
      });
    }
  },
};
