import {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  ComponentType,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed } from "../embed.js";
import { EMOJI } from "../config.js";

const JOKES = [
  "Why don't scientists trust atoms? Because they make up everything.",
  "Why did the developer go broke? Because they used up all their cache.",
  "I told my computer I needed a break, and it said: 'No problem — I'll go to sleep.'",
  "Why don't programmers like nature? It has too many bugs.",
  "Parallel lines have so much in common… it's a shame they'll never meet.",
  "Why was the JavaScript developer sad? Because they didn't know how to 'null' their feelings.",
  "I would tell you a UDP joke, but you might not get it.",
  "Why did the gamer carry an umbrella? In case of rage drops.",
  "There are 10 kinds of people in the world: those who understand binary, and those who don't.",
];

export const coinflipCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("coinflip").setDescription("Flip a coin."),
  async execute(interaction: ChatInputCommandInteraction) {
    const r = Math.random() < 0.5 ? "Heads" : "Tails";
    await interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "primary",
          title: `${EMOJI.coin} Coin Flip`,
          description: `The coin landed on **${r}**.`,
        }),
      ],
    });
  },
};

export const randomCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("random")
    .setDescription("Pick a random number between two values.")
    .addIntegerOption((o) => o.setName("min").setDescription("Minimum").setRequired(true))
    .addIntegerOption((o) => o.setName("max").setDescription("Maximum").setRequired(true)),
  async execute(interaction: ChatInputCommandInteraction) {
    const min = interaction.options.getInteger("min", true);
    const max = interaction.options.getInteger("max", true);
    if (min >= max)
      return interaction.reply({ embeds: [errorEmbed("Invalid Range", "`min` must be less than `max`.")], ephemeral: true });
    const n = Math.floor(Math.random() * (max - min + 1)) + min;
    await interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "primary",
          title: `${EMOJI.dice} Random Number`,
          description: `Between **${min}** and **${max}** → **${n}**`,
        }),
      ],
    });
  },
};

export const jokeCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("joke").setDescription("Tell a random joke."),
  async execute(interaction: ChatInputCommandInteraction) {
    const j = JOKES[Math.floor(Math.random() * JOKES.length)]!;
    await interaction.reply({
      embeds: [brandedEmbed({ kind: "primary", title: `${EMOJI.joke} Joke`, description: j })],
    });
  },
};

const RPS_BEATS: Record<string, string> = { rock: "scissors", paper: "rock", scissors: "paper" };
const RPS_EMOJI: Record<string, string> = { rock: "🪨", paper: "📄", scissors: "✂️" };

export const rpsCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("rps").setDescription("Play rock-paper-scissors against the bot."),
  async execute(interaction: ChatInputCommandInteraction) {
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("rps:rock").setLabel("Rock").setEmoji("🪨").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("rps:paper").setLabel("Paper").setEmoji("📄").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("rps:scissors").setLabel("Scissors").setEmoji("✂️").setStyle(ButtonStyle.Secondary),
    );
    const msg = await interaction.reply({
      embeds: [brandedEmbed({ kind: "primary", title: `${EMOJI.rps} Rock · Paper · Scissors`, description: "Pick your move!" })],
      components: [row],
      fetchReply: true,
    });
    try {
      const click = await msg.awaitMessageComponent({
        componentType: ComponentType.Button,
        filter: (i) => i.user.id === interaction.user.id,
        time: 30_000,
      });
      const choice = click.customId.split(":")[1]!;
      const bot = ["rock", "paper", "scissors"][Math.floor(Math.random() * 3)]!;
      let result: string;
      let kind: "success" | "danger" | "info" = "info";
      if (choice === bot) result = "It's a draw!";
      else if (RPS_BEATS[choice] === bot) {
        result = "You win!";
        kind = "success";
      } else {
        result = "I win!";
        kind = "danger";
      }
      await click.update({
        embeds: [
          brandedEmbed({
            kind,
            title: `${EMOJI.rps} ${result}`,
            description: `You chose ${RPS_EMOJI[choice]} **${choice}** — I chose ${RPS_EMOJI[bot]} **${bot}**.`,
          }),
        ],
        components: [],
      });
    } catch {
      await interaction.editReply({
        embeds: [brandedEmbed({ kind: "warning", title: `${EMOJI.warn} Timed out`, description: "You took too long to choose." })],
        components: [],
      });
    }
  },
};

export const funCommands: SlashCommand[] = [coinflipCommand, randomCommand, jokeCommand, rpsCommand];
