import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ChannelType,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { getGuildSettings, updateGuildSettings } from "../utils/db-helpers.js";

const ALLOWED_PREFIXES = ["-", "+", "?", "!", ",", ".", ";", "$", "%", ">"];

export const prefixCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("prefix")
    .setDescription("Manage the bot's text command prefixes for this server.")
    .addSubcommand((s) => s.setName("list").setDescription("Show current prefixes."))
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("Add a prefix.")
        .addStringOption((o) => o.setName("symbol").setDescription("Prefix symbol").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("Remove a prefix.")
        .addStringOption((o) => o.setName("symbol").setDescription("Prefix symbol").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("reset").setDescription("Reset to default prefixes."))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    const settings = await getGuildSettings(interaction.guildId);
    if (sub === "list") {
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "info",
            title: `${EMOJI.info} Active Prefixes`,
            description: settings.prefixes.map((p) => `\`${p}\``).join(" • ") || "_No prefixes._",
          }),
        ],
      });
    }
    if (sub === "add") {
      const sym = interaction.options.getString("symbol", true);
      if (sym.length > 3 || !/^[\S]+$/.test(sym))
        return interaction.reply({
          embeds: [errorEmbed("Invalid Prefix", "Prefix must be 1-3 non-whitespace characters.")],
          ephemeral: true,
        });
      if (settings.prefixes.includes(sym))
        return interaction.reply({
          embeds: [errorEmbed("Already Set", `\`${sym}\` is already a prefix.`)],
          ephemeral: true,
        });
      const next = [...settings.prefixes, sym];
      await updateGuildSettings(interaction.guildId, { prefixes: next });
      return interaction.reply({ embeds: [successEmbed("Prefix Added", `\`${sym}\` is now a prefix.`)] });
    }
    if (sub === "remove") {
      const sym = interaction.options.getString("symbol", true);
      const next = settings.prefixes.filter((p) => p !== sym);
      if (next.length === settings.prefixes.length)
        return interaction.reply({ embeds: [errorEmbed("Not Found", `\`${sym}\` isn't a prefix.`)], ephemeral: true });
      await updateGuildSettings(interaction.guildId, { prefixes: next });
      return interaction.reply({ embeds: [successEmbed("Prefix Removed", `\`${sym}\` removed.`)] });
    }
    if (sub === "reset") {
      await updateGuildSettings(interaction.guildId, { prefixes: ALLOWED_PREFIXES.slice(0, 5) });
      return interaction.reply({
        embeds: [successEmbed("Prefixes Reset", "Restored to default: `-` `+` `?` `!` `,`")],
      });
    }
  },
};

export const modlogCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("modlog")
    .setDescription("Configure the moderation log channel.")
    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("Set the mod log channel.")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) => s.setName("disable").setDescription("Disable mod log."))
    .addSubcommand((s) => s.setName("show").setDescription("Show current mod log channel."))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "set") {
      const channel = interaction.options.getChannel("channel", true);
      await updateGuildSettings(interaction.guildId, { modLogChannelId: channel.id });
      return interaction.reply({ embeds: [successEmbed("Mod Log Set", `Mod log will be sent to ${channel}.`)] });
    }
    if (sub === "disable") {
      await updateGuildSettings(interaction.guildId, { modLogChannelId: null });
      return interaction.reply({ embeds: [successEmbed("Mod Log Disabled", "Mod log entries will no longer be posted.")] });
    }
    const settings = await getGuildSettings(interaction.guildId);
    return interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "info",
          title: `${EMOJI.info} Mod Log`,
          description: settings.modLogChannelId ? `Active in <#${settings.modLogChannelId}>.` : "Not configured.",
        }),
      ],
    });
  },
};

export const configCommands: SlashCommand[] = [prefixCommand, modlogCommand];
