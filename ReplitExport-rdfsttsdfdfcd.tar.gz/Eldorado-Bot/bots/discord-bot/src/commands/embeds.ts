import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, renderEmbedConfig } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId } from "../utils/component-ids.js";
import { setEmbedDraft } from "../handlers/embed-builder.js";

export const embedCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("embed")
    .setDescription("Build and send a custom embed.")
    .addSubcommand((s) =>
      s
        .setName("create")
        .setDescription("Open the interactive embed builder.")
        .addChannelOption((o) =>
          o
            .setName("channel")
            .setDescription("Where to send the embed (default: this channel)")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
        ),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const channel = interaction.options.getChannel("channel") ?? interaction.channel;
    const targetId = channel?.id ?? interaction.channelId;
    setEmbedDraft(interaction.user.id, {
      title: "Untitled Embed",
      description: "Click **Edit Title & Description** to start.",
      color: BRAND.primary,
      bannerUrl: BRAND.defaultBanner,
      footerText: BRAND.footerText,
      footerIconUrl: BRAND.footerIcon,
      timestamp: true,
    });
    await interaction.reply({
      ephemeral: true,
      embeds: [
        brandedEmbed({
          kind: "info",
          title: `${EMOJI.edit} Embed Builder`,
          description: `Use the buttons below to build your embed. The preview updates live.\nDestination: <#${targetId}>`,
        }),
        renderEmbedConfig({
          title: "Untitled Embed",
          description: "Click **Edit Title & Description** to start.",
          color: BRAND.primary,
          bannerUrl: BRAND.defaultBanner,
        }),
      ],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId(encodeId("embed", "edit_basics"))
            .setLabel("Edit Title & Description")
            .setEmoji(EMOJI.edit)
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(encodeId("embed", "edit_visuals"))
            .setLabel("Edit Visuals")
            .setEmoji(EMOJI.preview)
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(encodeId("embed", "edit_footer"))
            .setLabel("Edit Footer & Author")
            .setEmoji(EMOJI.edit)
            .setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId(encodeId("embed", "send", targetId))
            .setLabel("Send")
            .setEmoji(EMOJI.success)
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(encodeId("embed", "cancel"))
            .setLabel("Cancel")
            .setEmoji(EMOJI.cancel)
            .setStyle(ButtonStyle.Danger),
        ),
      ],
    });
  },
};
