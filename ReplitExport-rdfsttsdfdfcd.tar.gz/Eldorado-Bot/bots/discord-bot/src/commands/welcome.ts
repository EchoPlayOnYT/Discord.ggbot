import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type TextChannel,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, successEmbed, renderEmbedConfig, applyPlaceholders } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { getGuildSettings, updateGuildSettings } from "../utils/db-helpers.js";
import { encodeId } from "../utils/component-ids.js";

export const welcomeCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("welcome")
    .setDescription("Configure the welcome system.")
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("Quickly set the welcome channel and enable the system.")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Welcome channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) => s.setName("edit").setDescription("Open the interactive welcome editor."))
    .addSubcommand((s) => s.setName("test").setDescription("Send a test welcome message for yourself."))
    .addSubcommand((s) => s.setName("disable").setDescription("Disable welcome messages."))
    .addSubcommand((s) =>
      s
        .setName("autorole")
        .setDescription("Add or remove a role automatically given to new members.")
        .addStringOption((o) => o.setName("action").setDescription("Action").setChoices({ name: "add", value: "add" }, { name: "remove", value: "remove" }, { name: "clear", value: "clear" }).setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("Role")),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    const settings = await getGuildSettings(interaction.guildId);

    if (sub === "setup") {
      const ch = interaction.options.getChannel("channel", true);
      await updateGuildSettings(interaction.guildId, {
        welcomeEnabled: true,
        welcomeChannelId: ch.id,
        welcomeEmbed: settings.welcomeEmbed ?? {
          title: `Welcome to {server}!`,
          description: `Hey {user}, you're member **#{memberCount}**.\nMake yourself at home — we're glad you joined.`,
          color: BRAND.primary,
          bannerUrl: BRAND.defaultBanner,
          thumbnailUrl: null,
          footerText: BRAND.footerText,
          footerIconUrl: BRAND.footerIcon,
          timestamp: true,
        },
      });
      return interaction.reply({
        embeds: [
          successEmbed(
            "Welcome System Enabled",
            `New members will be greeted in ${ch}. Use \`/welcome edit\` to customize the embed.`,
          ),
        ],
      });
    }

    if (sub === "disable") {
      await updateGuildSettings(interaction.guildId, { welcomeEnabled: false });
      return interaction.reply({ embeds: [successEmbed("Welcome Disabled", "New members will no longer be greeted.")] });
    }

    if (sub === "autorole") {
      const action = interaction.options.getString("action", true);
      const role = interaction.options.getRole("role");
      if (action === "clear") {
        await updateGuildSettings(interaction.guildId, { welcomeAutoRoleIds: [] });
        return interaction.reply({ embeds: [successEmbed("Auto-Roles Cleared", "No roles will be auto-assigned.")] });
      }
      if (!role)
        return interaction.reply({ embeds: [errorEmbed("Missing Role", "Provide a role.")], ephemeral: true });
      if (action === "add") {
        if (settings.welcomeAutoRoleIds.includes(role.id))
          return interaction.reply({ embeds: [errorEmbed("Already Set", `${role} is already auto-assigned.`)], ephemeral: true });
        await updateGuildSettings(interaction.guildId, {
          welcomeAutoRoleIds: [...settings.welcomeAutoRoleIds, role.id],
        });
        return interaction.reply({ embeds: [successEmbed("Auto-Role Added", `${role} will be assigned to new members.`)] });
      }
      // remove
      await updateGuildSettings(interaction.guildId, {
        welcomeAutoRoleIds: settings.welcomeAutoRoleIds.filter((id) => id !== role.id),
      });
      return interaction.reply({ embeds: [successEmbed("Auto-Role Removed", `${role} no longer auto-assigned.`)] });
    }

    if (sub === "test") {
      if (!settings.welcomeChannelId || !settings.welcomeEnabled)
        return interaction.reply({
          embeds: [errorEmbed("Not Configured", "Run `/welcome setup` first.")],
          ephemeral: true,
        });
      const ch = interaction.guild.channels.cache.get(settings.welcomeChannelId) as TextChannel | undefined;
      if (!ch?.isTextBased())
        return interaction.reply({
          embeds: [errorEmbed("Channel Missing", "Welcome channel no longer exists.")],
          ephemeral: true,
        });
      const cfg = settings.welcomeEmbed;
      const ctx = {
        user: interaction.user,
        userMention: interaction.user.toString(),
        userTag: interaction.user.tag,
        serverName: interaction.guild.name,
        memberCount: interaction.guild.memberCount,
      };
      const e = renderEmbedConfig(cfg);
      if (cfg?.title) e.setTitle(applyPlaceholders(cfg.title, ctx));
      if (cfg?.description) e.setDescription(applyPlaceholders(cfg.description, ctx));
      const content = settings.welcomeMessageContent
        ? applyPlaceholders(settings.welcomeMessageContent, ctx)
        : undefined;
      await ch.send({ content, embeds: [e] });
      return interaction.reply({ embeds: [successEmbed("Test Sent", `Posted in ${ch}.`)], ephemeral: true });
    }

    if (sub === "edit") {
      // Open the editor panel
      const cfg = settings.welcomeEmbed;
      const preview = renderEmbedConfig(cfg ?? {
        title: `Welcome to {server}!`,
        description: `Hey {user}, you're member **#{memberCount}**.`,
        color: BRAND.primary,
        bannerUrl: BRAND.defaultBanner,
      });
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "edit_basics"))
          .setLabel("Edit Title & Description")
          .setEmoji(EMOJI.edit)
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "edit_visuals"))
          .setLabel("Edit Visuals")
          .setEmoji(EMOJI.preview)
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "edit_message"))
          .setLabel("Plain Message Above Embed")
          .setEmoji(EMOJI.edit)
          .setStyle(ButtonStyle.Secondary),
      );
      const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "set_channel"))
          .setLabel("Set Channel")
          .setEmoji("📺")
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "toggle"))
          .setLabel(settings.welcomeEnabled ? "Disable" : "Enable")
          .setEmoji(settings.welcomeEnabled ? EMOJI.cancel : EMOJI.success)
          .setStyle(settings.welcomeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(encodeId("welcome", "test"))
          .setLabel("Send Test")
          .setEmoji(EMOJI.preview)
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.reply({
        ephemeral: true,
        embeds: [
          brandedEmbed({
            kind: "info",
            title: `${EMOJI.sparkle} Welcome System Editor`,
            description: [
              `**Status:** ${settings.welcomeEnabled ? `${EMOJI.success} Enabled` : `${EMOJI.cancel} Disabled`}`,
              `**Channel:** ${settings.welcomeChannelId ? `<#${settings.welcomeChannelId}>` : "_not set_"}`,
              `**Auto-Roles:** ${settings.welcomeAutoRoleIds.length ? settings.welcomeAutoRoleIds.map((r) => `<@&${r}>`).join(" ") : "_none_"}`,
              ``,
              `Placeholders: \`{user}\` \`{user.tag}\` \`{user.name}\` \`{server}\` \`{memberCount}\``,
            ].join("\n"),
          }),
          preview,
        ],
        components: [row, row2],
      });
    }
  },
};
