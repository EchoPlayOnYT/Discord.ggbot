import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
} from "discord.js";
import type { SlashCommand } from "../client.js";
import { startAutommDeposit } from "../handlers/automm-deposit.js";

export const giveCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("give")
    .setDescription("Initiate a marketplace action inside a ticket.")
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName("automm")
        .setDescription("Start an Auto Middleman deposit. Must be used inside a ticket channel."),
    ),

  execute: async (interaction: ChatInputCommandInteraction) => {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand(true);
    if (sub === "automm") {
      await startAutommDeposit(interaction);
    }
  },
};
