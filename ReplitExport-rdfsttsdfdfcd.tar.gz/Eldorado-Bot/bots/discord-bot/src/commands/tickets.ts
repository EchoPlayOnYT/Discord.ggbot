import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  type TextChannel,
} from "discord.js";
import { db, ticketPanels, ticketPanelOptions, type EmbedConfig } from "@workspace/db";
import { eq, asc, and } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId } from "../utils/component-ids.js";
import { setPanelDraft, openPanelEditor } from "../handlers/panel-builder.js";
import { buildPanelMessage } from "../handlers/ticket-actions.js";

export const panelCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("panel")
    .setDescription("Manage interactive ticket panels.")
    .addSubcommand((s) =>
      s
        .setName("create")
        .setDescription("Open the interactive panel builder.")
        .addStringOption((o) => o.setName("name").setDescription("Internal panel name").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("edit")
        .setDescription("Edit an existing ticket panel.")
        .addIntegerOption((o) => o.setName("id").setDescription("Panel ID (from /panel list)").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("send")
        .setDescription("Send the panel to a channel.")
        .addIntegerOption((o) => o.setName("id").setDescription("Panel ID").setRequired(true))
        .addChannelOption((o) =>
          o
            .setName("channel")
            .setDescription("Channel to post the panel in")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("delete")
        .setDescription("Delete a ticket panel.")
        .addIntegerOption((o) => o.setName("id").setDescription("Panel ID").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("List all ticket panels in this server."))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "list") {
      const panels = await db
        .select()
        .from(ticketPanels)
        .where(eq(ticketPanels.guildId, interaction.guildId))
        .orderBy(asc(ticketPanels.id));
      if (panels.length === 0)
        return interaction.reply({
          embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Panels`, description: "Create one with `/panel create`." })],
          ephemeral: true,
        });
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "primary",
            title: `${EMOJI.ticket} Ticket Panels (${panels.length})`,
            description: panels
              .map(
                (p) =>
                  `\`#${p.id}\` — **${p.name}** ${p.channelId ? `(posted in <#${p.channelId}>)` : "_(not posted yet)_"}`,
              )
              .join("\n"),
          }),
        ],
        ephemeral: true,
      });
    }

    if (sub === "delete") {
      const id = interaction.options.getInteger("id", true);
      const removed = await db
        .delete(ticketPanels)
        .where(and(eq(ticketPanels.id, id), eq(ticketPanels.guildId, interaction.guildId)))
        .returning();
      if (removed.length === 0)
        return interaction.reply({ embeds: [errorEmbed("Not Found", `No panel \`#${id}\`.`)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed("Deleted", `Panel \`#${id}\` removed.`)] });
    }

    if (sub === "send") {
      const id = interaction.options.getInteger("id", true);
      const channel = interaction.options.getChannel("channel", true) as TextChannel;
      const [panel] = await db
        .select()
        .from(ticketPanels)
        .where(and(eq(ticketPanels.id, id), eq(ticketPanels.guildId, interaction.guildId)))
        .limit(1);
      if (!panel) return interaction.reply({ embeds: [errorEmbed("Not Found", `No panel \`#${id}\`.`)], ephemeral: true });
      const options = await db
        .select()
        .from(ticketPanelOptions)
        .where(eq(ticketPanelOptions.panelId, id))
        .orderBy(asc(ticketPanelOptions.position));
      if (options.length === 0)
        return interaction.reply({
          embeds: [errorEmbed("No Options", "Add at least one ticket option using `/panel edit`.")],
          ephemeral: true,
        });
      const message = await buildPanelMessage(panel, options);
      const sent = await channel.send(message);
      await db
        .update(ticketPanels)
        .set({ channelId: channel.id, messageId: sent.id, updatedAt: new Date() })
        .where(eq(ticketPanels.id, id));
      return interaction.reply({ embeds: [successEmbed("Panel Posted", `Sent panel \`#${id}\` to ${channel}.`)] });
    }

    if (sub === "create") {
      const name = interaction.options.getString("name", true);
      // Insert a starter panel + show editor
      const [created] = await db
        .insert(ticketPanels)
        .values({
          guildId: interaction.guildId,
          name,
          embed: {
            title: `${BRAND.name} Support`,
            description: `Need help with an order, account or product? Open a ticket below and our staff will assist you shortly.`,
            color: BRAND.primary,
            bannerUrl: BRAND.defaultBanner,
            footerText: BRAND.footerText,
            footerIconUrl: BRAND.footerIcon,
            timestamp: true,
          },
          layout: "buttons",
        })
        .returning();
      setPanelDraft(interaction.user.id, created!.id);
      await openPanelEditor(interaction, created!.id);
      return;
    }

    if (sub === "edit") {
      const id = interaction.options.getInteger("id", true);
      const [panel] = await db
        .select()
        .from(ticketPanels)
        .where(and(eq(ticketPanels.id, id), eq(ticketPanels.guildId, interaction.guildId)))
        .limit(1);
      if (!panel) return interaction.reply({ embeds: [errorEmbed("Not Found", `No panel \`#${id}\`.`)], ephemeral: true });
      setPanelDraft(interaction.user.id, id);
      await openPanelEditor(interaction, id);
      return;
    }
  },
};
