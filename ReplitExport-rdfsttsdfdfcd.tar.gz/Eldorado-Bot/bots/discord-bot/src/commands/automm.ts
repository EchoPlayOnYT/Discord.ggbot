import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  type ChatInputCommandInteraction,
  type TextChannel,
} from "discord.js";
import { eq, and, desc } from "drizzle-orm";
import { db, autommConfig, autommAddresses } from "@workspace/db";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, infoEmbed, successEmbed, renderEmbedConfig } from "../embed.js";
import { EMOJI } from "../config.js";
import { openAutommBuilder } from "../handlers/automm-builder.js";
import { renderDepositPreview, buildAutommPanelMessage } from "../handlers/automm-deposit.js";
import { getMonitorAvailability } from "../services/blockchain.js";

const METHOD_CHOICES = [
  { name: "Bitcoin (BTC)", value: "BTC" },
  { name: "Litecoin (LTC)", value: "LTC" },
  { name: "Ethereum (ETH)", value: "ETH" },
  { name: "Tether (USDT)", value: "USDT" },
  { name: "Robux (manual)", value: "ROBUX" },
  { name: "Other (manual)", value: "OTHER" },
];

async function ensureConfig(guildId: string): Promise<typeof autommConfig.$inferSelect> {
  const [row] = await db.select().from(autommConfig).where(eq(autommConfig.guildId, guildId)).limit(1);
  if (row) return row;
  const [created] = await db.insert(autommConfig).values({ guildId }).returning();
  return created!;
}

export const autommCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("automm")
    .setDescription("Auto Middleman: configure the deposit embed and wallet addresses.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addSubcommand((s) => s.setName("embed").setDescription("Open the embed builder for the Auto Middleman deposit message."))
    .addSubcommandGroup((g) =>
      g
        .setName("address")
        .setDescription("Manage wallet addresses used by Auto Middleman.")
        .addSubcommand((s) =>
          s
            .setName("set")
            .setDescription("Set or update the wallet address for a payment method.")
            .addStringOption((o) =>
              o.setName("method").setDescription("Payment method").setRequired(true).addChoices(...METHOD_CHOICES),
            )
            .addStringOption((o) => o.setName("address").setDescription("Wallet address / handle").setRequired(true))
            .addStringOption((o) =>
              o.setName("network").setDescription("Network (e.g. ERC-20, TRC-20). Optional."),
            )
            .addStringOption((o) => o.setName("label").setDescription("Friendly label").setRequired(false)),
        )
        .addSubcommand((s) =>
          s
            .setName("remove")
            .setDescription("Remove the wallet address for a payment method.")
            .addStringOption((o) =>
              o.setName("method").setDescription("Payment method").setRequired(true).addChoices(...METHOD_CHOICES),
            ),
        )
        .addSubcommand((s) => s.setName("list").setDescription("List configured wallet addresses.")),
    )
    .addSubcommand((s) =>
      s
        .setName("methods")
        .setDescription("Toggle which payment methods buyers can choose.")
        .addBooleanOption((o) => o.setName("btc").setDescription("Enable BTC"))
        .addBooleanOption((o) => o.setName("ltc").setDescription("Enable LTC"))
        .addBooleanOption((o) => o.setName("eth").setDescription("Enable ETH"))
        .addBooleanOption((o) => o.setName("usdt").setDescription("Enable USDT"))
        .addBooleanOption((o) => o.setName("robux").setDescription("Enable Robux (manual)"))
        .addBooleanOption((o) => o.setName("other").setDescription("Enable Other (manual)")),
    )
    .addSubcommand((s) =>
      s
        .setName("config")
        .setDescription("Auto Middleman behaviour settings.")
        .addBooleanOption((o) => o.setName("monitor").setDescription("Enable on-chain auto-monitoring"))
        .addIntegerOption((o) =>
          o.setName("expire_minutes").setDescription("Minutes before a pending deposit expires").setMinValue(5).setMaxValue(720),
        )
        .addIntegerOption((o) =>
          o.setName("amount_tolerance_pct").setDescription("Allowed under-pay percentage (0–10)").setMinValue(0).setMaxValue(10),
        ),
    )
    .addSubcommand((s) => s.setName("status").setDescription("Show the current Auto Middleman configuration & monitor status."))
    .addSubcommand((s) =>
      s
        .setName("preview")
        .setDescription("Preview the deposit embed with sample values.")
        .addStringOption((o) =>
          o.setName("method").setDescription("Payment method").setRequired(true).addChoices(...METHOD_CHOICES),
        )
        .addStringOption((o) => o.setName("amount").setDescription("Amount to preview").setRequired(true)),
    )
    .addSubcommandGroup((g) =>
      g
        .setName("panel")
        .setDescription("Post & manage the Auto Middleman panel (like /panel for tickets).")
        .addSubcommand((s) =>
          s
            .setName("editor")
            .setDescription("Open the Auto Middleman panel editor (embed, visuals, message)."),
        )
        .addSubcommand((s) =>
          s
            .setName("send")
            .setDescription("Post the Auto Middleman panel to a channel with method buttons.")
            .addChannelOption((o) =>
              o
                .setName("channel")
                .setDescription("Channel to post the panel in")
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true),
            ),
        )
        .addSubcommand((s) =>
          s.setName("show").setDescription("Show an ephemeral preview of the panel as users will see it."),
        ),
    ),

  execute: async (interaction: ChatInputCommandInteraction) => {
    if (!interaction.inCachedGuild()) return;
    const guildId = interaction.guildId;
    const sub = interaction.options.getSubcommand(true);
    const group = interaction.options.getSubcommandGroup(false);

    await ensureConfig(guildId);

    if (group === "address") {
      if (sub === "set") {
        const method = interaction.options.getString("method", true).toUpperCase();
        const address = interaction.options.getString("address", true).trim();
        const network = interaction.options.getString("network", false)?.trim() || null;
        const label = interaction.options.getString("label", false)?.trim() || null;
        await db
          .insert(autommAddresses)
          .values({ guildId, method, address, network, label, isActive: true })
          .onConflictDoUpdate({
            target: [autommAddresses.guildId, autommAddresses.method],
            set: { address, network, label, isActive: true },
          });
        return interaction.reply({
          embeds: [
            successEmbed(
              "Address Saved",
              `**${method}** ${network ? `(${network}) ` : ""}→ \`${address}\`\n\n` +
                `> The bot only **reads** this address to detect deposits. It cannot move funds.`,
            ),
          ],
          ephemeral: true,
        });
      }
      if (sub === "remove") {
        const method = interaction.options.getString("method", true).toUpperCase();
        const removed = await db
          .delete(autommAddresses)
          .where(and(eq(autommAddresses.guildId, guildId), eq(autommAddresses.method, method)))
          .returning();
        if (!removed.length) {
          return interaction.reply({ embeds: [errorEmbed("Not Found", `No address configured for ${method}.`)], ephemeral: true });
        }
        return interaction.reply({ embeds: [successEmbed("Address Removed", `**${method}** address removed.`)], ephemeral: true });
      }
      if (sub === "list") {
        const rows = await db
          .select()
          .from(autommAddresses)
          .where(eq(autommAddresses.guildId, guildId))
          .orderBy(desc(autommAddresses.createdAt));
        if (!rows.length) {
          return interaction.reply({
            embeds: [infoEmbed("No Addresses", "Use `/automm address set` to add one.")],
            ephemeral: true,
          });
        }
        const description = rows
          .map((r) => `**${r.method}** ${r.network ? `(${r.network}) ` : ""}\n\`${r.address}\`${r.label ? ` — ${r.label}` : ""}`)
          .join("\n\n");
        return interaction.reply({
          embeds: [
            brandedEmbed({
              kind: "info",
              title: `${EMOJI.diamond} Auto Middleman Addresses`,
              description,
            }),
          ],
          ephemeral: true,
        });
      }
    }

    if (sub === "embed") {
      await openAutommBuilder(interaction);
      return;
    }

    if (sub === "methods") {
      const cfg = await ensureConfig(guildId);
      const next = new Set(cfg.enabledMethods);
      const all: { key: string; opt: string }[] = [
        { key: "BTC", opt: "btc" },
        { key: "LTC", opt: "ltc" },
        { key: "ETH", opt: "eth" },
        { key: "USDT", opt: "usdt" },
        { key: "ROBUX", opt: "robux" },
        { key: "OTHER", opt: "other" },
      ];
      let touched = false;
      for (const { key, opt } of all) {
        const v = interaction.options.getBoolean(opt, false);
        if (v === null) continue;
        touched = true;
        if (v) next.add(key);
        else next.delete(key);
      }
      if (!touched) {
        return interaction.reply({
          embeds: [infoEmbed("Enabled Methods", `Currently enabled: \`${[...next].join(", ") || "none"}\``)],
          ephemeral: true,
        });
      }
      await db
        .update(autommConfig)
        .set({ enabledMethods: [...next], updatedAt: new Date() })
        .where(eq(autommConfig.guildId, guildId));
      return interaction.reply({
        embeds: [successEmbed("Methods Updated", `Enabled: \`${[...next].join(", ") || "none"}\``)],
        ephemeral: true,
      });
    }

    if (sub === "config") {
      const monitor = interaction.options.getBoolean("monitor", false);
      const expire = interaction.options.getInteger("expire_minutes", false);
      const tol = interaction.options.getInteger("amount_tolerance_pct", false);
      const patch: Partial<typeof autommConfig.$inferInsert> = { updatedAt: new Date() };
      if (monitor !== null) patch.monitorEnabled = monitor;
      if (expire !== null) patch.expireMinutes = expire;
      if (tol !== null) patch.amountTolerancePct = tol;
      if (Object.keys(patch).length === 1) {
        const cfg = await ensureConfig(guildId);
        return interaction.reply({
          embeds: [
            brandedEmbed({
              kind: "info",
              title: `${EMOJI.info} Auto Middleman Config`,
              fields: [
                { name: "Monitor", value: cfg.monitorEnabled ? "✅ On" : "❌ Off", inline: true },
                { name: "Expire (min)", value: String(cfg.expireMinutes), inline: true },
                { name: "Tolerance (%)", value: String(cfg.amountTolerancePct), inline: true },
              ],
            }),
          ],
          ephemeral: true,
        });
      }
      await db.update(autommConfig).set(patch).where(eq(autommConfig.guildId, guildId));
      return interaction.reply({ embeds: [successEmbed("Config Updated", "Auto Middleman settings saved.")], ephemeral: true });
    }

    if (sub === "status") {
      const cfg = await ensureConfig(guildId);
      const addresses = await db.select().from(autommAddresses).where(eq(autommAddresses.guildId, guildId));
      const avail = getMonitorAvailability();
      const availFmt = avail
        .map((a) => `\`${a.method}\` ${a.available ? "✅" : "❌"}${a.reason ? ` — ${a.reason}` : ""}`)
        .join("\n");
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "info",
            title: `${EMOJI.diamond} Auto Middleman Status`,
            description:
              `**Embed configured:** ${cfg.embed ? "✅" : "❌ — run \`/automm embed\`"}\n` +
              `**Monitor:** ${cfg.monitorEnabled ? "✅ On" : "❌ Off"}\n` +
              `**Enabled methods:** \`${cfg.enabledMethods.join(", ") || "none"}\`\n` +
              `**Configured addresses:** ${addresses.length}\n\n` +
              `**Auto-monitoring availability:**\n${availFmt}\n\n` +
              `> The bot only **reads** balances. It never sends or holds funds — a human releases the goods after confirming.`,
          }),
        ],
        ephemeral: true,
      });
    }

    if (sub === "preview") {
      const method = interaction.options.getString("method", true).toUpperCase();
      const amount = interaction.options.getString("amount", true);
      const cfg = await ensureConfig(guildId);
      const [addr] = await db
        .select()
        .from(autommAddresses)
        .where(and(eq(autommAddresses.guildId, guildId), eq(autommAddresses.method, method)))
        .limit(1);
      const previewEmbed = renderDepositPreview({
        embedConfig: cfg.embed,
        contentTemplate: cfg.contentTemplate,
        method,
        amount,
        address: addr?.address ?? "<not-configured>",
        network: addr?.network ?? null,
        buyerMention: `<@${interaction.user.id}>`,
      });
      return interaction.reply({
        content: previewEmbed.content || undefined,
        embeds: [renderEmbedConfig(previewEmbed.embed, "Deposit"), previewEmbed.safetyEmbed],
        ephemeral: true,
      });
    }

    if (group === "panel") {
      if (sub === "editor") {
        await openAutommBuilder(interaction);
        return;
      }

      const cfg = await ensureConfig(guildId);
      const addresses = await db.select().from(autommAddresses).where(eq(autommAddresses.guildId, guildId));
      const enabled = (cfg.enabledMethods ?? []).filter((m) => addresses.some((a) => a.method === m && a.isActive));
      if (!enabled.length) {
        return interaction.reply({
          embeds: [
            errorEmbed(
              "Not Ready",
              "Enable methods with `/automm methods` and add wallet addresses with `/set address` (or `/automm address set`) before posting a panel.",
            ),
          ],
          ephemeral: true,
        });
      }
      const payload = buildAutommPanelMessage(cfg, enabled);

      if (sub === "send") {
        const channel = interaction.options.getChannel("channel", true) as TextChannel;
        if (!channel || channel.type !== ChannelType.GuildText) {
          return interaction.reply({ embeds: [errorEmbed("Invalid Channel", "Pick a text channel.")], ephemeral: true });
        }
        try {
          await channel.send(payload);
        } catch {
          return interaction.reply({
            embeds: [errorEmbed("Couldn't Post", "Make sure I have permission to send messages in that channel.")],
            ephemeral: true,
          });
        }
        return interaction.reply({
          embeds: [
            successEmbed(
              "Panel Posted",
              `Auto Middleman panel posted in ${channel}. Members can click a method button to start a deposit.`,
            ),
          ],
          ephemeral: true,
        });
      }

      if (sub === "show") {
        return interaction.reply({ ...payload, ephemeral: true });
      }
    }
  },
};
