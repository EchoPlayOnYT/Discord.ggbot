import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { db, customCommands, type CustomCommandAction } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId } from "../utils/component-ids.js";
import { setCustomDraft } from "../handlers/custom-builder.js";

export const customCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("custom")
    .setDescription("Manage custom server commands.")
    .addSubcommandGroup((g) =>
      g
        .setName("command")
        .setDescription("Manage commands")
        .addSubcommand((s) =>
          s
            .setName("create")
            .setDescription("Open the custom command builder.")
            .addStringOption((o) => o.setName("name").setDescription("Command name (no spaces)").setRequired(true)),
        )
        .addSubcommand((s) =>
          s
            .setName("edit")
            .setDescription("Edit an existing custom command.")
            .addStringOption((o) => o.setName("name").setDescription("Command name").setRequired(true)),
        )
        .addSubcommand((s) =>
          s
            .setName("delete")
            .setDescription("Delete a custom command.")
            .addStringOption((o) => o.setName("name").setDescription("Command name").setRequired(true)),
        )
        .addSubcommand((s) => s.setName("list").setDescription("List all custom commands.")),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "list") {
      const all = await db.select().from(customCommands).where(eq(customCommands.guildId, interaction.guildId));
      if (all.length === 0)
        return interaction.reply({
          embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Custom Commands`, description: "Create one with `/custom command create`." })],
          ephemeral: true,
        });
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "primary",
            title: `${EMOJI.diamond} Custom Commands (${all.length})`,
            description: all.map((c) => `\`${c.name}\` — ${c.action.type}`).join("\n"),
          }),
        ],
        ephemeral: true,
      });
    }

    if (sub === "delete") {
      const name = interaction.options.getString("name", true).toLowerCase();
      const removed = await db
        .delete(customCommands)
        .where(and(eq(customCommands.guildId, interaction.guildId), eq(customCommands.name, name)))
        .returning();
      if (removed.length === 0)
        return interaction.reply({ embeds: [errorEmbed("Not Found", `No command named \`${name}\`.`)], ephemeral: true });
      return interaction.reply({ embeds: [successEmbed("Deleted", `Custom command \`${name}\` removed.`)] });
    }

    // create or edit → open builder
    const name = interaction.options.getString("name", true).toLowerCase();
    if (!/^[a-z0-9_-]{1,32}$/.test(name))
      return interaction.reply({
        embeds: [errorEmbed("Invalid Name", "Use 1-32 lowercase letters, numbers, dashes or underscores.")],
        ephemeral: true,
      });
    const existing = await db
      .select()
      .from(customCommands)
      .where(and(eq(customCommands.guildId, interaction.guildId), eq(customCommands.name, name)))
      .limit(1);

    if (sub === "create" && existing[0]) {
      return interaction.reply({
        embeds: [errorEmbed("Already Exists", `\`${name}\` already exists. Use \`/custom command edit\`.`)],
        ephemeral: true,
      });
    }
    if (sub === "edit" && !existing[0]) {
      return interaction.reply({
        embeds: [errorEmbed("Not Found", `No command named \`${name}\`. Create it first.`)],
        ephemeral: true,
      });
    }

    const draftAction: CustomCommandAction = existing[0]?.action ?? {
      type: "embed",
      embed: {
        title: `Untitled`,
        description: `Edit me with the buttons below.`,
        color: BRAND.primary,
        bannerUrl: BRAND.defaultBanner,
        footerText: BRAND.footerText,
        footerIconUrl: BRAND.footerIcon,
        timestamp: true,
      },
    };
    setCustomDraft(interaction.user.id, { name, action: draftAction });

    const select = new StringSelectMenuBuilder()
      .setCustomId(encodeId("custom", "type"))
      .setPlaceholder("Action type")
      .addOptions(
        { label: "Send Embed", value: "embed", emoji: EMOJI.edit, default: draftAction.type === "embed" },
        { label: "Send Plain Message", value: "message", emoji: "💬", default: draftAction.type === "message" },
        { label: "Redirect to URL", value: "url", emoji: EMOJI.arrow, default: draftAction.type === "url" },
        { label: "Interactive Buttons", value: "buttons", emoji: "🔘", default: draftAction.type === "buttons" },
      );
    const editRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "edit_payload"))
        .setLabel("Edit Content")
        .setEmoji(EMOJI.edit)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "manage_buttons"))
        .setLabel("Manage Buttons")
        .setEmoji("🔘")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "preview"))
        .setLabel("Preview")
        .setEmoji(EMOJI.preview)
        .setStyle(ButtonStyle.Secondary),
    );
    const saveRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "save"))
        .setLabel("Save")
        .setEmoji(EMOJI.save)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(encodeId("custom", "cancel"))
        .setLabel("Cancel")
        .setEmoji(EMOJI.cancel)
        .setStyle(ButtonStyle.Danger),
    );

    await interaction.reply({
      ephemeral: true,
      embeds: [
        brandedEmbed({
          kind: "info",
          title: `${EMOJI.diamond} Custom Command Builder — \`${name}\``,
          description: [
            `**Type:** \`${draftAction.type}\``,
            ``,
            `1. Pick an action type below.`,
            `2. Click **Edit Content** to fill in the message, embed, URL, or button details.`,
            `3. Click **Save** when ready.`,
            ``,
            `Once saved, anyone can run this with any prefix:\n${BRAND ? "" : ""}\`-${name}\` \`+${name}\` \`?${name}\` \`!${name}\` \`,${name}\``,
          ].join("\n"),
        }),
      ],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
        editRow,
        saveRow,
      ],
    });
  },
};
