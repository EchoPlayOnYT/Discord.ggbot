import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type TextChannel,
} from "discord.js";
import { db, suggestions } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, renderEmbedConfig, successEmbed } from "../embed.js";
import { EMOJI, BRAND } from "../config.js";
import { encodeId } from "../utils/component-ids.js";
import { getGuildSettings, updateGuildSettings } from "../utils/db-helpers.js";

export const suggestCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("suggest")
    .setDescription("Submit a suggestion.")
    .addStringOption((o) => o.setName("suggestion").setDescription("Your suggestion").setRequired(true).setMaxLength(1500)),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const settings = await getGuildSettings(interaction.guildId);
    if (!settings.suggestionsChannelId)
      return interaction.reply({
        embeds: [errorEmbed("Not Configured", "An admin must run `/suggestions setup` first.")],
        ephemeral: true,
      });
    const channel = interaction.guild.channels.cache.get(settings.suggestionsChannelId) as TextChannel | undefined;
    if (!channel?.isTextBased())
      return interaction.reply({ embeds: [errorEmbed("Channel Missing", "Suggestion channel no longer exists.")], ephemeral: true });
    const text = interaction.options.getString("suggestion", true);
    const embed = renderEmbedConfig({
      title: `${EMOJI.lightbulb} Suggestion`,
      description: text,
      color: BRAND.primary,
      bannerUrl: null,
      thumbnailUrl: interaction.user.displayAvatarURL(),
      authorName: interaction.user.tag,
      authorIconUrl: interaction.user.displayAvatarURL(),
      footerText: BRAND.footerText,
      footerIconUrl: BRAND.footerIcon,
      timestamp: true,
    });
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(encodeId("sugg", "up")).setEmoji(EMOJI.upvote).setLabel("0").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(encodeId("sugg", "down")).setEmoji(EMOJI.downvote).setLabel("0").setStyle(ButtonStyle.Danger),
    );
    const msg = await channel.send({ embeds: [embed], components: [row] });
    await db.insert(suggestions).values({
      guildId: interaction.guildId,
      channelId: channel.id,
      messageId: msg.id,
      authorId: interaction.user.id,
      content: text,
    });
    return interaction.reply({ embeds: [successEmbed("Submitted", `Your suggestion is live in ${channel}.`)], ephemeral: true });
  },
};

export const suggestionsCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("suggestions")
    .setDescription("Configure the suggestion channel.")
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("Set the suggestions channel.")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) => s.setName("disable").setDescription("Disable suggestions."))
    .addSubcommand((s) =>
      s
        .setName("approve")
        .setDescription("Approve a suggestion.")
        .addStringOption((o) => o.setName("message_id").setDescription("Suggestion message ID").setRequired(true))
        .addStringOption((o) => o.setName("reason").setDescription("Reason / response")),
    )
    .addSubcommand((s) =>
      s
        .setName("deny")
        .setDescription("Deny a suggestion.")
        .addStringOption((o) => o.setName("message_id").setDescription("Suggestion message ID").setRequired(true))
        .addStringOption((o) => o.setName("reason").setDescription("Reason / response")),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "setup") {
      const ch = interaction.options.getChannel("channel", true);
      await updateGuildSettings(interaction.guildId, { suggestionsChannelId: ch.id });
      return interaction.reply({ embeds: [successEmbed("Suggestions Enabled", `Suggestions will be posted in ${ch}.`)] });
    }
    if (sub === "disable") {
      await updateGuildSettings(interaction.guildId, { suggestionsChannelId: null });
      return interaction.reply({ embeds: [successEmbed("Disabled", "Suggestions are now disabled.")] });
    }
    if (sub === "approve" || sub === "deny") {
      const id = interaction.options.getString("message_id", true);
      const reason = interaction.options.getString("reason");
      const [s] = await db
        .select()
        .from(suggestions)
        .where(and(eq(suggestions.guildId, interaction.guildId), eq(suggestions.messageId, id)))
        .limit(1);
      if (!s) return interaction.reply({ embeds: [errorEmbed("Not Found", "No suggestion with that message ID.")], ephemeral: true });
      const newStatus = sub === "approve" ? "approved" : "denied";
      await db.update(suggestions).set({ status: newStatus }).where(eq(suggestions.id, s.id));
      const channel = interaction.guild.channels.cache.get(s.channelId) as TextChannel | undefined;
      if (channel?.isTextBased()) {
        try {
          const msg = await channel.messages.fetch(s.messageId);
          const original = msg.embeds[0]?.toJSON() ?? {};
          original.color = newStatus === "approved" ? 0x22c55e : 0xef4444;
          original.fields = [
            ...(original.fields ?? []),
            {
              name: newStatus === "approved" ? `${EMOJI.success} Approved` : `${EMOJI.cancel} Denied`,
              value: `${reason ? reason + "\n" : ""}— ${interaction.user}`,
            },
          ];
          await msg.edit({ embeds: [original] });
        } catch {
          // ignore
        }
      }
      return interaction.reply({ embeds: [successEmbed("Updated", `Suggestion marked **${newStatus}**.`)] });
    }
  },
};
