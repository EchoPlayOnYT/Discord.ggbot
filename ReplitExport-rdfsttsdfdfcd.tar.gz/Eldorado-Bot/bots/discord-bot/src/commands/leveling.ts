import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChatInputCommandInteraction,
  AttachmentBuilder,
} from "discord.js";
import { db, levelXp, levelRoles } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import type { SlashCommand } from "../client.js";
import { brandedEmbed, errorEmbed, successEmbed } from "../embed.js";
import { EMOJI } from "../config.js";
import { getGuildSettings, updateGuildSettings } from "../utils/db-helpers.js";
import { xpForLevel, levelFromXp } from "../utils/leveling.js";

export const rankCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("Show your level and XP.")
    .addUserOption((o) => o.setName("user").setDescription("User")),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const target = interaction.options.getUser("user") ?? interaction.user;
    const [row] = await db
      .select()
      .from(levelXp)
      .where(and(eq(levelXp.guildId, interaction.guildId), eq(levelXp.userId, target.id)))
      .limit(1);
    const xp = row?.xp ?? 0;
    const level = levelFromXp(xp);
    const cur = xpForLevel(level);
    const next = xpForLevel(level + 1);
    const progress = xp - cur;
    const total = next - cur;
    const bar = renderBar(progress, total);
    return interaction.reply({
      embeds: [
        brandedEmbed({
          kind: "primary",
          title: `${EMOJI.diamond} Rank — ${target.username}`,
          description: [
            `**Level:** \`${level}\``,
            `**XP:** \`${xp.toLocaleString()}\``,
            `**Next level in:** \`${(next - xp).toLocaleString()} XP\``,
            ``,
            `${bar} \`${progress}/${total}\``,
          ].join("\n"),
        }).setThumbnail(target.displayAvatarURL()),
      ],
    });
  },
};

function renderBar(value: number, total: number, width = 14): string {
  const filled = Math.max(0, Math.min(width, Math.round((value / total) * width)));
  return `\`[${"█".repeat(filled)}${"░".repeat(width - filled)}]\``;
}

export const leaderboardCommand: SlashCommand = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("Top XP earners in the server."),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const top = await db
      .select()
      .from(levelXp)
      .where(eq(levelXp.guildId, interaction.guildId))
      .orderBy(desc(levelXp.xp))
      .limit(10);
    if (top.length === 0)
      return interaction.reply({
        embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Data Yet`, description: "Chat to start earning XP!" })],
      });
    const lines = top.map((r, i) => `**${i + 1}.** <@${r.userId}> — Level \`${levelFromXp(r.xp)}\` (\`${r.xp.toLocaleString()} XP\`)`);
    return interaction.reply({
      embeds: [brandedEmbed({ kind: "primary", title: `${EMOJI.diamond} Leaderboard`, description: lines.join("\n") })],
    });
  },
};

export const levelingCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("leveling")
    .setDescription("Configure the leveling system.")
    .addSubcommand((s) =>
      s
        .setName("toggle")
        .setDescription("Enable or disable the leveling system.")
        .addBooleanOption((o) => o.setName("enabled").setDescription("Enabled").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("levelup_channel")
        .setDescription("Set channel where level-up announcements are posted (or 'current').")
        .addChannelOption((o) => o.setName("channel").setDescription("Channel (omit to use the message channel)")),
    )
    .addSubcommand((s) =>
      s
        .setName("addrole")
        .setDescription("Award a role at a level.")
        .addIntegerOption((o) => o.setName("level").setDescription("Level").setMinValue(1).setMaxValue(500).setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("removerole")
        .setDescription("Remove a level reward.")
        .addIntegerOption((o) => o.setName("level").setDescription("Level").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("rewards").setDescription("List configured level rewards."))
    .addSubcommand((s) =>
      s
        .setName("setxp")
        .setDescription("Set a user's XP (admin).")
        .addUserOption((o) => o.setName("user").setDescription("User").setRequired(true))
        .addIntegerOption((o) => o.setName("xp").setDescription("XP value").setMinValue(0).setRequired(true)),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inCachedGuild()) return;
    const sub = interaction.options.getSubcommand();
    if (sub === "toggle") {
      const enabled = interaction.options.getBoolean("enabled", true);
      await updateGuildSettings(interaction.guildId, { levelingEnabled: enabled });
      return interaction.reply({ embeds: [successEmbed("Leveling Updated", enabled ? "Members will now earn XP." : "Leveling disabled.")] });
    }
    if (sub === "levelup_channel") {
      const ch = interaction.options.getChannel("channel");
      await updateGuildSettings(interaction.guildId, { levelUpChannelId: ch?.id ?? null });
      return interaction.reply({
        embeds: [successEmbed("Updated", ch ? `Level-up messages will be posted in ${ch}.` : "Level-up messages will be posted in the same channel as the trigger.")],
      });
    }
    if (sub === "addrole") {
      const level = interaction.options.getInteger("level", true);
      const role = interaction.options.getRole("role", true);
      await db
        .insert(levelRoles)
        .values({ guildId: interaction.guildId, level, roleId: role.id })
        .onConflictDoUpdate({ target: [levelRoles.guildId, levelRoles.level], set: { roleId: role.id } });
      return interaction.reply({ embeds: [successEmbed("Reward Added", `Level **${level}** → ${role}`)] });
    }
    if (sub === "removerole") {
      const level = interaction.options.getInteger("level", true);
      await db.delete(levelRoles).where(and(eq(levelRoles.guildId, interaction.guildId), eq(levelRoles.level, level)));
      return interaction.reply({ embeds: [successEmbed("Removed", `Level ${level} reward removed.`)] });
    }
    if (sub === "rewards") {
      const all = await db.select().from(levelRoles).where(eq(levelRoles.guildId, interaction.guildId));
      if (all.length === 0)
        return interaction.reply({
          embeds: [brandedEmbed({ kind: "info", title: `${EMOJI.info} No Rewards`, description: "Use `/leveling addrole`." })],
          ephemeral: true,
        });
      return interaction.reply({
        embeds: [
          brandedEmbed({
            kind: "primary",
            title: `${EMOJI.diamond} Level Rewards`,
            description: all
              .sort((a, b) => a.level - b.level)
              .map((r) => `Level **${r.level}** → <@&${r.roleId}>`)
              .join("\n"),
          }),
        ],
      });
    }
    if (sub === "setxp") {
      const user = interaction.options.getUser("user", true);
      const xp = interaction.options.getInteger("xp", true);
      await db
        .insert(levelXp)
        .values({ guildId: interaction.guildId, userId: user.id, xp })
        .onConflictDoUpdate({ target: [levelXp.guildId, levelXp.userId], set: { xp } });
      return interaction.reply({ embeds: [successEmbed("XP Set", `${user} now has \`${xp.toLocaleString()} XP\` (level ${levelFromXp(xp)}).`)] });
    }
  },
};
