import {
  GuildMember,
  PermissionResolvable,
  PermissionFlagsBits,
} from "discord.js";

/**
 * Returns true if `actor` outranks `target` (highest role of actor is strictly above
 * the highest role of target). Guild owner always wins.
 */
export function outranks(actor: GuildMember, target: GuildMember): boolean {
  if (actor.id === actor.guild.ownerId) return true;
  if (target.id === target.guild.ownerId) return false;
  return actor.roles.highest.comparePositionTo(target.roles.highest) > 0;
}

/** True if member has all of the listed permissions in the guild context. */
export function hasPerms(member: GuildMember, ...perms: PermissionResolvable[]): boolean {
  return perms.every((p) => member.permissions.has(p));
}

export const PERM = PermissionFlagsBits;
