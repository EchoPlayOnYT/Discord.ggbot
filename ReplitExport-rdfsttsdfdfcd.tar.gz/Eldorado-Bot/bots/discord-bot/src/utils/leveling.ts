// XP curve: classic Mee6-style. Total XP to reach `level` = 5/6 * level * (2*level^2 + 27*level + 91)
export function xpForLevel(level: number): number {
  if (level <= 0) return 0;
  return Math.floor((5 / 6) * level * (2 * level * level + 27 * level + 91));
}

export function levelFromXp(xp: number): number {
  let level = 0;
  while (xpForLevel(level + 1) <= xp) level++;
  return level;
}
