import { db, guildSettings } from "@workspace/db";
import { eq } from "drizzle-orm";
import type { EmbedBuilder, Guild, TextChannel } from "discord.js";
import { DEFAULT_PREFIXES } from "../config.js";

type GuildSettings = typeof guildSettings.$inferSelect;

const cache = new Map<string, GuildSettings>();

/** Get (or lazily create) per-guild settings, with a small in-memory cache. */
export async function getGuildSettings(guildId: string): Promise<GuildSettings> {
  const hit = cache.get(guildId);
  if (hit) return hit;
  const rows = await db.select().from(guildSettings).where(eq(guildSettings.guildId, guildId)).limit(1);
  if (rows[0]) {
    cache.set(guildId, rows[0]);
    return rows[0];
  }
  const inserted = await db
    .insert(guildSettings)
    .values({ guildId, prefixes: DEFAULT_PREFIXES })
    .returning();
  cache.set(guildId, inserted[0]!);
  return inserted[0]!;
}

/** Update part of guild settings and refresh cache. */
export async function updateGuildSettings(
  guildId: string,
  values: Partial<typeof guildSettings.$inferInsert>,
): Promise<GuildSettings> {
  await getGuildSettings(guildId); // ensure exists
  const updated = await db
    .update(guildSettings)
    .set({ ...values, updatedAt: new Date() })
    .where(eq(guildSettings.guildId, guildId))
    .returning();
  cache.set(guildId, updated[0]!);
  return updated[0]!;
}

export function invalidateGuildSettings(guildId: string): void {
  cache.delete(guildId);
}

/** Send an embed to the configured mod-log channel for a guild, if any. */
export async function sendModLog(guild: Guild, embed: EmbedBuilder): Promise<void> {
  const settings = await getGuildSettings(guild.id);
  if (!settings.modLogChannelId) return;
  const channel = guild.channels.cache.get(settings.modLogChannelId) as TextChannel | undefined;
  if (!channel?.isTextBased()) return;
  await channel.send({ embeds: [embed] }).catch(() => null);
}
