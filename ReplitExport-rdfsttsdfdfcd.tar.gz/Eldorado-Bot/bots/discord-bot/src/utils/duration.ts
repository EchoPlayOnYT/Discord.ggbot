import ms from "ms";

/** Parse a human-readable duration string (e.g. "10m", "1h", "1d") into milliseconds. */
export function parseDuration(input: string): number | null {
  if (!input) return null;
  try {
    const v = ms(input);
    if (typeof v === "number" && v > 0) return v;
  } catch {
    return null;
  }
  return null;
}

/** Format an ISO date in Discord relative time. */
export function relativeTime(d: Date): string {
  return `<t:${Math.floor(d.getTime() / 1000)}:R>`;
}

/** Format an ISO date in Discord long date/time. */
export function longTime(d: Date): string {
  return `<t:${Math.floor(d.getTime() / 1000)}:F>`;
}
