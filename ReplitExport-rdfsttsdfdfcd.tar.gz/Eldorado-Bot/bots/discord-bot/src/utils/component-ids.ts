/**
 * Centralized custom ID encoder/decoder for buttons / selects / modals.
 * Format: "namespace:action:arg1:arg2..."
 */
export function encodeId(namespace: string, action: string, ...args: (string | number)[]): string {
  return [namespace, action, ...args.map(String)].join(":");
}

export function decodeId(id: string): { namespace: string; action: string; args: string[] } {
  const [namespace = "", action = "", ...args] = id.split(":");
  return { namespace, action, args };
}
