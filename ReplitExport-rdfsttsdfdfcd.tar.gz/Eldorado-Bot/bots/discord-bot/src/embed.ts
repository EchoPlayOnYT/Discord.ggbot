import {
  EmbedBuilder,
  type APIEmbed,
  type ColorResolvable,
  type User,
} from "discord.js";
import type { EmbedConfig } from "@workspace/db";
import { BRAND, EMOJI } from "./config.js";

export type EmbedKind = "primary" | "success" | "danger" | "warning" | "info" | "neutral";

const KIND_COLOR: Record<EmbedKind, number> = {
  primary: BRAND.primary,
  success: BRAND.success,
  danger: BRAND.danger,
  warning: BRAND.warning,
  info: BRAND.info,
  neutral: BRAND.neutral,
};

interface BrandedEmbedInput {
  title?: string;
  description?: string;
  kind?: EmbedKind;
  color?: ColorResolvable;
  fields?: { name: string; value: string; inline?: boolean }[];
  thumbnail?: string;
  image?: string;
  banner?: string;
  author?: { name: string; iconURL?: string };
  footer?: { text?: string; iconURL?: string };
  timestamp?: boolean;
  url?: string;
}

/** Build a unified, premium-style branded embed used across the bot. */
export function brandedEmbed(input: BrandedEmbedInput = {}): EmbedBuilder {
  const kind = input.kind ?? "primary";
  const color = (input.color ?? KIND_COLOR[kind]) as ColorResolvable;
  const e = new EmbedBuilder().setColor(color);

  if (input.title) e.setTitle(input.title);
  if (input.description) e.setDescription(input.description);
  if (input.url) e.setURL(input.url);
  if (input.fields?.length) e.addFields(input.fields);
  if (input.thumbnail) e.setThumbnail(input.thumbnail);
  // banner = top image, image = bottom image. If both provided, prefer explicit image, else use banner
  if (input.image) e.setImage(input.image);
  else if (input.banner) e.setImage(input.banner);

  if (input.author) e.setAuthor({ name: input.author.name, iconURL: input.author.iconURL });

  e.setFooter({
    text: input.footer?.text ?? BRAND.footerText,
    iconURL: input.footer?.iconURL ?? BRAND.footerIcon,
  });

  if (input.timestamp ?? true) e.setTimestamp(new Date());

  return e;
}

/** Quick success embed. */
export function successEmbed(title: string, description?: string): EmbedBuilder {
  return brandedEmbed({ kind: "success", title: `${EMOJI.success} ${title}`, description });
}

/** Quick error embed. */
export function errorEmbed(title: string, description?: string): EmbedBuilder {
  return brandedEmbed({ kind: "danger", title: `${EMOJI.error} ${title}`, description });
}

/** Quick warning embed. */
export function warningEmbed(title: string, description?: string): EmbedBuilder {
  return brandedEmbed({ kind: "warning", title: `${EMOJI.warn} ${title}`, description });
}

/** Quick info embed. */
export function infoEmbed(title: string, description?: string): EmbedBuilder {
  return brandedEmbed({ kind: "info", title: `${EMOJI.info} ${title}`, description });
}

/** Build a moderation log embed. */
export function moderationEmbed(input: {
  action: string;
  emoji: string;
  target: User;
  moderator: User;
  reason?: string;
  extra?: { name: string; value: string; inline?: boolean }[];
  kind?: EmbedKind;
}): EmbedBuilder {
  const fields = [
    { name: "User", value: `${input.target} \`${input.target.tag}\`\n\`${input.target.id}\``, inline: true },
    { name: "Moderator", value: `${input.moderator} \`${input.moderator.tag}\``, inline: true },
    { name: "Reason", value: input.reason ?? "_No reason provided._", inline: false },
    ...(input.extra ?? []),
  ];
  return brandedEmbed({
    kind: input.kind ?? "warning",
    title: `${input.emoji} ${input.action}`,
    fields,
    thumbnail: input.target.displayAvatarURL({ size: 256 }),
  });
}

/**
 * Render a user-defined EmbedConfig (from welcome/custom/ticket panel storage) into an EmbedBuilder.
 * Empty fields are skipped. The brand banner is used as a fallback for visual consistency.
 */
export function renderEmbedConfig(cfg: EmbedConfig | null | undefined, fallbackTitle?: string): EmbedBuilder {
  const e = new EmbedBuilder();
  e.setColor((cfg?.color ?? BRAND.primary) as ColorResolvable);
  if (cfg?.title) e.setTitle(cfg.title);
  else if (fallbackTitle) e.setTitle(fallbackTitle);
  if (cfg?.description) e.setDescription(cfg.description);
  if (cfg?.thumbnailUrl) e.setThumbnail(cfg.thumbnailUrl);
  if (cfg?.imageUrl) e.setImage(cfg.imageUrl);
  else if (cfg?.bannerUrl) e.setImage(cfg.bannerUrl);
  if (cfg?.authorName) e.setAuthor({ name: cfg.authorName, iconURL: cfg.authorIconUrl ?? undefined });
  e.setFooter({
    text: cfg?.footerText ?? BRAND.footerText,
    iconURL: cfg?.footerIconUrl ?? BRAND.footerIcon,
  });
  if (cfg?.timestamp !== false) e.setTimestamp(new Date());
  return e;
}

/** Convert a Discord embed to an APIEmbed for live previews in modals. */
export function toAPIEmbed(builder: EmbedBuilder): APIEmbed {
  return builder.toJSON();
}

/** Substitute common placeholders like {user}, {server}, {memberCount}. */
export function applyPlaceholders(
  text: string | null | undefined,
  ctx: {
    user?: User;
    userMention?: string;
    userTag?: string;
    serverName?: string;
    memberCount?: number;
  },
): string {
  if (!text) return "";
  return text
    .replaceAll("{user}", ctx.userMention ?? ctx.user?.toString() ?? "")
    .replaceAll("{user.mention}", ctx.userMention ?? ctx.user?.toString() ?? "")
    .replaceAll("{user.tag}", ctx.userTag ?? ctx.user?.tag ?? "")
    .replaceAll("{user.name}", ctx.user?.username ?? "")
    .replaceAll("{user.id}", ctx.user?.id ?? "")
    .replaceAll("{server}", ctx.serverName ?? "")
    .replaceAll("{server.name}", ctx.serverName ?? "")
    .replaceAll("{memberCount}", String(ctx.memberCount ?? ""))
    .replaceAll("{members}", String(ctx.memberCount ?? ""));
}
